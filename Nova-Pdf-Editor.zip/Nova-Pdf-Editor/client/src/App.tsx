import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
// Wouter Route ComponentType için doğru type cast
import ErrorPage from "@/pages/ErrorPage";
import type { RouteComponentProps } from "wouter";
import AuthPage from "@/pages/auth-page";
import PDFEditPage from "@/pages/PDFEditPage";
import MobileHomePage from "@/pages/MobileHomePage";
import ImagesToPDFPage from "@/pages/ImagesToPDFPage";
import PDFComparePage from "@/pages/PDFComparePage";
import PDFMergePage from "@/pages/PDFMergePage";
import PDFSplitPage from "@/pages/PDFSplitPage";
import PDFViewerPage from "@/pages/PDFViewerPage";
import PDFCompressPage from "@/pages/PDFCompressPage";
import NativeCapabilitiesPage from "@/pages/NativeCapabilitiesPage";
import TranslationPage from "@/pages/TranslationPage";
import PDFAnimationDemo from "@/pages/PDFAnimationDemo";
import ConvertCenterPage from "@/pages/ConvertCenterPage";
import { ThemeProvider, ThemeToggleProvider } from "@/components/ui/theme-provider";
import { useEffect, useState } from "react";
import i18n from "./lib/i18n";
import { useIsMobile } from "@/hooks/use-mobile";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckIcon, Star } from "lucide-react";
import BackButton from "@/components/ui/back-button";
import { useToast } from "@/hooks/use-toast";

// Not: i18n başlatılması main.tsx dosyasında yapılmıştır

function Router() {
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  
  return (
    <Switch>
      {/* Ana sayfa için mobil veya masaüstü görünümünü otomatik olarak belirle */}
      <Route path="/" component={isMobile ? MobileHomePage : Home} />
      
      {/* Diğer sayfalar her iki görünümde de aynı */}
      <Route path="/pdf-edit" component={PDFEditPage} />
      <Route path="/images-to-pdf" component={ImagesToPDFPage} />
      <Route path="/convert-center" component={ConvertCenterPage} />
      <Route path="/pdf-compare" component={PDFComparePage} />
      <Route path="/pdf-merge" component={PDFMergePage} />
      <Route path="/pdf-split" component={PDFSplitPage} />
      <Route path="/pdf-view" component={PDFViewerPage} />
      <Route path="/pdf-compress" component={PDFCompressPage} />
      <Route path="/translation" component={TranslationPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/error">
        {() => <ErrorPage />}
      </Route>
      
      {/* Premium özellikler için bilgilendirme sayfası */}
      <Route path="/pricing" component={() => (
        <div className="container mx-auto py-10 px-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center mb-6">
              <BackButton target={isMobile ? "/mobile" : "/"} variant="outline" className="mr-4" />
              <h1 className="text-2xl font-bold">Premium Özellikler</h1>
            </div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Bu özellik premium abonelik gerektirir</h2>
              <p className="mb-4">PDF Böl, Birleştir, Dönüştür, OCR ve PDF Karşılaştır özellikleri Nova PDF Editor'ün premium özellikleridir.</p>
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <Card className="p-4 border-primary">
                  <h3 className="font-medium mb-2">Half-Pro Paket</h3>
                  <p className="text-2xl font-bold mb-2">29.99 TL<span className="text-sm font-normal text-gray-500">/ay</span></p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center"><CheckIcon className="mr-2 h-4 w-4" />PDF OCR</li>
                    <li className="flex items-center"><CheckIcon className="mr-2 h-4 w-4" />PDF Dönüştürme</li>
                  </ul>
                  <Button className="w-full" variant="outline">Satın Al</Button>
                </Card>
                <Card className="p-4 bg-primary/5 border-primary">
                  <h3 className="font-medium mb-2">Pro Paket</h3>
                  <p className="text-2xl font-bold mb-2">49.99 TL<span className="text-sm font-normal text-gray-500">/ay</span></p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center"><CheckIcon className="mr-2 h-4 w-4" />Tüm Half-Pro özellikleri</li>
                    <li className="flex items-center"><CheckIcon className="mr-2 h-4 w-4" />PDF Böl ve Birleştir</li>
                    <li className="flex items-center"><CheckIcon className="mr-2 h-4 w-4" />PDF Karşılaştırma</li>
                  </ul>
                  <Button className="w-full">Satın Al</Button>
                </Card>
              </div>
              <p className="text-sm text-gray-500">Daha fazla bilgi için lütfen müşteri hizmetleri ile iletişime geçin.</p>
            </Card>
          </div>
        </div>
      )} />
      
      {/* Değerlendirme sayfası */}
      <Route path="/rate" component={() => (
        <div className="container mx-auto py-10 px-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center mb-6">
              <BackButton target={isMobile ? "/mobile" : "/"} variant="outline" className="mr-4" />
              <h1 className="text-2xl font-bold">Uygulamayı Değerlendir</h1>
            </div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Geri Bildiriminiz Bizim İçin Önemli</h2>
              <p className="mb-6">Nova PDF Editor'ü kullanarak nasıl bir deneyim yaşadığınızı bizimle paylaşır mısınız?</p>
              
              <div className="flex justify-center space-x-2 mb-6">
                {[1, 2, 3, 4, 5].map(star => (
                  <Button key={star} variant="ghost" size="icon" className="h-10 w-10 text-yellow-400 hover:text-yellow-500">
                    <Star className="h-8 w-8" fill="currentColor" />
                  </Button>
                ))}
              </div>
              
              <div className="space-y-4 mb-6">
                <label className="text-sm font-medium">Görüşleriniz</label>
                <textarea 
                  className="w-full border rounded-md p-3 min-h-[150px]" 
                  placeholder="Uygulamayla ilgili görüşlerinizi yazın..."
                />
              </div>
              
              <Button onClick={() => {
                toast({
                  title: "Teşekkürler!",
                  description: "Değerlendirmeniz için teşekkür ederiz. Geri bildiriminiz başarıyla gönderildi.",
                  duration: 5000,
                });
                setTimeout(() => setLocation(isMobile ? "/mobile" : "/"), 2000);
              }} className="w-full">Değerlendirmeyi Gönder</Button>
            </Card>
          </div>
        </div>
      )} />
      
      {/* Yeni mobil görünüm için ekstra yollar */}
      <Route path="/mobile" component={MobileHomePage} />
      <Route path="/desktop" component={Home} />
      
      {/* Telefon özellikleri sayfası */}
      <Route path="/native-capabilities" component={NativeCapabilitiesPage} />
      
      {/* Çeviri ve Dil Araçları sayfası */}
      <Route path="/translation" component={TranslationPage} />
      
      {/* PDF Sayfa Geçiş Animasyonları */}
      <Route path="/pdf-animation" component={PDFAnimationDemo} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Başlangıçta dil ayarını localStorage'dan al
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language");
    if (savedLanguage) {
      i18n.changeLanguage(savedLanguage);
    }
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system" attribute="class">
        <ThemeToggleProvider>
          <Router />
          <Toaster />
        </ThemeToggleProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
