import { useState, useCallback, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { PdfOperation, PdfOperationType } from "@shared/schema";

export type PageText = {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize: number;
  fontFamily: string;
  color: string;
};

export type PDFPage = {
  pageNumber: number;
  width: number;
  height: number;
  textItems: PageText[];
};

export type PDFDocument = {
  numPages: number;
  pages: PDFPage[];
};

export function usePDF() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentPdfId, setCurrentPdfId] = useState<number | null>(null);
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [pdfDocument, setPdfDocument] = useState<PDFDocument | null>(null);
  const [pdfBuffer, setPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [operations, setOperations] = useState<PdfOperation[]>([]);
  const [pdfTextElements, setPdfTextElements] = useState<Array<{
    text: string;
    x: number;
    y: number;
    width: number;
    height: number;
    fontSize?: number;
    fontFamily?: string;
    id: string;
  }>>([]);
  const [loadingTextElements, setLoadingTextElements] = useState(false);

  // Query for loading PDF metadata
  const {
    data: pdfMetadata,
    isLoading: isLoadingMetadata,
    error: metadataError,
  } = useQuery({
    queryKey: ["/api/pdf", currentPdfId],
    enabled: !!currentPdfId,
  });

  // Upload PDF mutation
  const uploadPdfMutation = useMutation({
    mutationFn: async (file: File) => {
      // Dosya boyutu kontrolü (30MB'dan büyük dosyaları reddet)
      const MAX_FILE_SIZE = 30 * 1024 * 1024; // 30 MB
      if (file.size > MAX_FILE_SIZE) {
        throw new Error(`Dosya boyutu çok büyük. Maksimum 30MB olmalıdır. Mevcut boyut: ${(file.size / (1024 * 1024)).toFixed(2)}MB`);
      }

      // Dosyayı küçük parçalara ayırmak yerine doğrudan yükleme yapacağız
      // ancak biraz optimizasyon yapabiliriz
      const formData = new FormData();
      formData.append("pdf", file);
      
      try {
        console.log("PDF yükleme başladı:", file.name);
        const response = await fetch("/api/pdf/upload", {
          method: "POST",
          body: formData,
          credentials: "include",
        });
        
        if (!response.ok) {
          // Hata durumunu JSON olarak almaya çalış
          try {
            const errorData = await response.json();
            throw new Error(errorData.message || "PDF yükleme başarısız oldu");
          } catch (jsonError) {
            // JSON ayrıştırılamazsa, HTTP durum koduyla birlikte genel bir hata fırlat
            throw new Error(`PDF yükleme başarısız oldu (${response.status})`);
          }
        }
        
        console.log("PDF yükleme başarılı");
        return response.json();
      } catch (error) {
        console.error("PDF yükleme hatası:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      setCurrentPdfId(data.id);
      setCurrentPageIndex(0);
      setZoomLevel(100);
      setOperations([]);
      queryClient.invalidateQueries({ queryKey: ["/api/pdf", data.id] });
      toast({
        title: "PDF başarıyla yüklendi",
        description: `Dosya: ${data.originalFilename}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Yükleme başarısız",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Save edits mutation
  const saveEditsMutation = useMutation({
    mutationFn: async ({ pdfId, operations }: { pdfId: number; operations: PdfOperation[] }) => {
      const response = await apiRequest("POST", `/api/pdf/${pdfId}/edit`, { operations });
      return response.json();
    },
    onSuccess: () => {
      if (currentPdfId) {
        queryClient.invalidateQueries({ queryKey: ["/api/pdf", currentPdfId] });
        toast({
          title: "Changes saved",
          description: "Your edits have been saved successfully.",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save changes",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // PDF buffer'ını yükle (OCR için gerekli)
  useEffect(() => {
    if (currentPdfId) {
      // PDF dosyasını ArrayBuffer olarak yükle (OCR için kullanılacak)
      (async () => {
        try {
          const response = await fetch(`/api/pdf/${currentPdfId}/file`);
          if (!response.ok) {
            throw new Error(`PDF dosyasını yüklerken hata oluştu: ${response.status}`);
          }
          
          const blob = await response.blob();
          const arrayBuffer = await blob.arrayBuffer();
          setPdfBuffer(arrayBuffer);
          
          // PDF'deki mevcut metinleri çıkar - Basitleştirilmiş yaklaşım kullanarak
          setLoadingTextElements(true);
          try {
            // Doğrudan metin çıkarmak için PDF.js kullanmak yerine PDF içeriğini içe aktar
            // Not: PDF.js versiyonu uyumsuzluğu nedeniyle bu geçici bir çözüm
            setPdfTextElements([
              {
                id: `text-manual-${Date.now()}`,
                text: "Bu PDF'deki metinler PDF.js versiyon uyumsuzluğundan dolayı gösterilemiyor",
                x: 100,
                y: 100,
                width: 300,
                height: 20,
                fontSize: 12,
                fontFamily: "sans-serif"
              }
            ]);
          } catch (textError) {
            console.error('Metin çıkarma hatası:', textError);
            toast({
              title: "Metin çıkarma hatası",
              description: "PDF içeriğindeki metinler çıkarılırken bir hata oluştu. PDF.js versiyonu uyumsuzluğu olabilir.",
              variant: "destructive",
            });
          } finally {
            setLoadingTextElements(false);
          }
        } catch (error) {
          console.error('PDF buffer yükleme hatası:', error);
          setPdfBuffer(null);
          toast({
            title: "PDF yükleme hatası",
            description: error instanceof Error ? error.message : "Beklenmeyen bir hata oluştu",
            variant: "destructive",
          });
        }
      })();
    } else {
      setPdfBuffer(null);
      setPdfTextElements([]);
    }
  }, [currentPdfId, currentPageIndex, toast]);

  // Download edited PDF
  const downloadPdf = useCallback(async () => {
    if (!currentPdfId) {
      toast({
        title: "No PDF loaded",
        description: "Please upload a PDF document first.",
        variant: "destructive",
      });
      return;
    }

    try {
      // First save any pending operations
      if (operations.length > 0) {
        await saveEditsMutation.mutateAsync({
          pdfId: currentPdfId,
          operations,
        });
      }

      // Then download the edited PDF
      const link = document.createElement("a");
      link.href = `/api/pdf/${currentPdfId}/edited`;
      link.download = `edited_${pdfMetadata?.originalFilename || "document.pdf"}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      toast({
        title: "Download failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  }, [currentPdfId, operations, pdfMetadata, saveEditsMutation, toast]);

  // Handle PDF upload
  const handleFileUpload = useCallback(
    (file: File) => {
      if (file.type !== "application/pdf") {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF file.",
          variant: "destructive",
        });
        return;
      }

      uploadPdfMutation.mutate(file);
    },
    [toast, uploadPdfMutation]
  );

  // Navigation functions
  const goToNextPage = useCallback(() => {
    if (pdfDocument && currentPageIndex < pdfDocument.numPages - 1) {
      setCurrentPageIndex(currentPageIndex + 1);
    }
  }, [currentPageIndex, pdfDocument]);

  const goToPrevPage = useCallback(() => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex(currentPageIndex - 1);
    }
  }, [currentPageIndex]);

  // Zoom functions
  const zoomIn = useCallback(() => {
    if (zoomLevel < 200) {
      setZoomLevel(zoomLevel + 25);
    }
  }, [zoomLevel]);

  const zoomOut = useCallback(() => {
    if (zoomLevel > 50) {
      setZoomLevel(zoomLevel - 25);
    }
  }, [zoomLevel]);

  // Add text operation
  const addTextOperation = useCallback(
    (text: string, pageNumber: number, position: { x: number; y: number }, options?: { fontSize?: number; fontColor?: string }) => {
      // Yeni metin elementi oluştur (UI için)
      const newElement = {
        id: `text-${Date.now()}`,
        text: text,
        x: position.x,
        y: position.y,
        width: text.length * 8, // Tahmini genişlik
        height: 20,
        fontSize: options?.fontSize || 12,
        fontFamily: "sans-serif",
        color: options?.fontColor || "#000000"
      };
      
      // Mevcut listeye ekleme
      setPdfTextElements(prev => [...prev, newElement]);
      
      // Operasyon kaydı (Backend için)
      const newOperation: PdfOperation = {
        type: PdfOperationType.ADD_TEXT,
        pageNumber,
        content: text,
        position,
        fontSize: options?.fontSize,
        fontColor: options?.fontColor
      };

      setOperations([...operations, newOperation]);
    },
    [operations, setPdfTextElements]
  );

  // Save changes
  const saveChanges = useCallback(() => {
    if (!currentPdfId || operations.length === 0) {
      toast({
        title: "No changes to save",
        description: "Make some changes first.",
        variant: "destructive",
      });
      return;
    }

    saveEditsMutation.mutate({
      pdfId: currentPdfId,
      operations,
    });
  }, [currentPdfId, operations, saveEditsMutation, toast]);

  // Reset/clear the current PDF and state
  const resetPdf = useCallback(() => {
    setCurrentPdfId(null);
    setPdfDocument(null);
    setCurrentPageIndex(0);
    setZoomLevel(100);
    setOperations([]);
  }, []);

  // Mevcut metni güncelle
  const updateTextOperation = useCallback(
    async (textId: string, newText: string, options?: { fontSize?: number; fontColor?: string }) => {
      if (!pdfBuffer) {
        toast({
          title: "PDF yüklenemedi",
          description: "Önce bir PDF dosyası yükleyin.",
          variant: "destructive",
        });
        return;
      }
      
      try {
        // PDF.js versiyon uyumsuzluğu nedeniyle gerçek güncelleme yapmıyoruz
        // Bunun yerine simüle edilmiş bir güncelleme yapıyoruz
        
        // Metinlerin listesini güncelle
        const updatedElements = pdfTextElements.map(el => {
          if (el.id === textId) {
            return {
              ...el,
              text: newText,
              fontSize: options?.fontSize || el.fontSize,
            };
          }
          return el;
        });
        
        setPdfTextElements(updatedElements);
        
        // Gerçekte PDF.js ve pdf-lib ile güncelleme yapılacaktı, ancak versiyon uyumsuzluğu nedeniyle
        // bu özelliği şu an için kaldırdık
        
        toast({
          title: "Metin güncellendi",
          description: "PDF içerisindeki metin başarıyla güncellendi. (Not: PDF.js versiyon uyumsuzluğu nedeniyle sadece görsel güncelleme yapıldı)",
        });
      } catch (error) {
        console.error("Metin güncelleme hatası:", error);
        toast({
          title: "Metin güncellenemedi",
          description: error instanceof Error ? error.message : "Beklenmeyen bir hata oluştu",
          variant: "destructive",
        });
      }
    },
    [currentPageIndex, pdfBuffer, pdfTextElements, toast]
  );
  
  // Metni sil
  const deleteTextOperation = useCallback(
    async (textId: string) => {
      if (!pdfBuffer) {
        toast({
          title: "PDF yüklenemedi",
          description: "Önce bir PDF dosyası yükleyin.",
          variant: "destructive",
        });
        return;
      }
      
      try {
        // PDF.js versiyon uyumsuzluğu nedeniyle gerçek silme yapmıyoruz
        // Bunun yerine metni listeden kaldırıyoruz
        
        // Metni listeden kaldır
        const updatedElements = pdfTextElements.filter(el => el.id !== textId);
        setPdfTextElements(updatedElements);
        
        toast({
          title: "Metin silindi",
          description: "PDF içerisindeki metin başarıyla silindi. (Not: PDF.js versiyon uyumsuzluğu nedeniyle sadece görsel silme yapıldı)",
        });
      } catch (error) {
        console.error("Metin silme hatası:", error);
        toast({
          title: "Metin silinemedi",
          description: error instanceof Error ? error.message : "Beklenmeyen bir hata oluştu",
          variant: "destructive",
        });
      }
    },
    [pdfBuffer, pdfTextElements, toast]
  );

  // Görüntü ekleme fonksiyonu
  const addImageOperation = useCallback(
    (imageFile: File, pageNumber: number, position: { x: number; y: number }) => {
      // Optimizasyon için dosya boyutuna bakalım
      const maxFileSize = 5 * 1024 * 1024; // 5MB
      
      if (imageFile.size > maxFileSize) {
        toast({
          title: "Dosya çok büyük",
          description: "Görüntü dosyası 5MB'dan küçük olmalıdır. Lütfen daha küçük bir görüntü seçin.",
          variant: "destructive"
        });
        return;
      }
      
      // Resim dosyasını base64'e çevirip işleme alma
      const reader = new FileReader();
      reader.onloadend = () => {
        // Base64 formatında resim verisi
        const base64Image = reader.result as string;
        
        // Görüntüyü önizlemek için önce boyutlarını almak gerekiyor
        const img = new Image();
        img.onload = () => {
          // Görüntü boyutunu optimize et
          const maxWidth = 800; // Daha geniş bir maksimum genişlik
          const maxHeight = 600; // Maksimum yükseklik
          
          let width = img.width;
          let height = img.height;
          
          // Genişlik veya yükseklik sınırları aşıyorsa oranı koru
          if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width = Math.floor(width * ratio);
            height = Math.floor(height * ratio);
          }
          
          // Canvas kullanarak görüntüyü yeniden boyutlandır
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            
            // Optimum kalite ve boyut için WebP formatı kullan
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            
            // Operasyon kaydet
            const newOperation: PdfOperation = {
              type: PdfOperationType.ADD_IMAGE,
              pageNumber,
              content: imageFile.name, // İçerik olarak dosya adını koy
              position,
              imageData: compressedBase64,
              imageWidth: width,
              imageHeight: height
            };
            
            setOperations([...operations, newOperation]);
            
            // Başarı bildirimi
            toast({
              title: "Görüntü eklendi",
              description: "Görüntü başarıyla PDF'e eklendi.",
            });
          } else {
            toast({
              title: "Görüntü işlenemedi",
              description: "Görüntüyü işlerken bir hata oluştu. Lütfen tekrar deneyin.",
              variant: "destructive"
            });
          }
        };
        // Base64 string'ini image source olarak atayarak yükle
        img.src = base64Image;
      };
      
      // Dosyayı okumayı başlat
      reader.readAsDataURL(imageFile);
    },
    [operations, toast]
  );

  return {
    currentPdfId,
    pdfMetadata,
    isLoadingMetadata,
    metadataError,
    pdfDocument,
    setPdfDocument,
    pdfBuffer,
    setPdfBuffer,
    currentPageIndex,
    setCurrentPageIndex,
    zoomLevel,
    operations,
    pdfTextElements,
    setPdfTextElements,
    loadingTextElements,
    isUploading: uploadPdfMutation.isPending,
    isSaving: saveEditsMutation.isPending,
    handleFileUpload,
    goToNextPage,
    goToPrevPage,
    zoomIn,
    zoomOut,
    addTextOperation,
    addImageOperation,
    updateTextOperation,
    deleteTextOperation,
    saveChanges,
    downloadPdf,
    resetPdf,
  };
}
