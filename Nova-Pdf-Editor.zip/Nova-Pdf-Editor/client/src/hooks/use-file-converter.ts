import { useState, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from 'jspdf';

interface ConversionOptions {
  maxPageWidth?: number;  // milimetre cinsinden
  maxPageHeight?: number; // milimetre cinsinden
  margin?: number;        // milimetre cinsinden
  quality?: number;       // 0-1 arası değer
}

export interface ConversionResult {
  blob: Blob;
  url: string;
  size: number;
  pageCount: number;
}

export function useFileConverter() {
  const [isConverting, setIsConverting] = useState(false);
  const { toast } = useToast();

  /**
   * Görsel dosyalarını PDF'e dönüştürür
   */
  const convertImagesToPdf = useCallback(async (
    files: File[], 
    options: ConversionOptions = {}
  ): Promise<ConversionResult | null> => {
    if (files.length === 0) return null;
    
    setIsConverting(true);
    
    try {
      // A4 boyutunda bir PDF oluştur
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      
      const margin = options.margin || 10; // Varsayılan 10mm kenar boşluğu
      const maxWidth = options.maxPageWidth || pageWidth - (margin * 2);
      const maxHeight = options.maxPageHeight || pageHeight - (margin * 2);
      
      // Her görsel için işlem yap
      for (let i = 0; i < files.length; i++) {
        // İlk sayfa dışında yeni sayfa ekle
        if (i > 0) {
          doc.addPage();
        }
        
        const file = files[i];
        
        // Görsel dosyasını base64 formatına dönüştür
        const imageBase64 = await readFileAsDataURL(file);
        
        // PDF sayfasına resmi ekle (sayfaya sığdırarak)
        doc.addImage(
          imageBase64, 
          'JPEG', 
          margin,           // x pozisyonu
          margin,           // y pozisyonu
          maxWidth,         // genişlik
          maxHeight,        // yükseklik
          undefined,        // alias
          'FAST',           // kompresyon
          0                 // döndürme açısı
        );
      }
      
      // PDF'i blob olarak döndür
      const pdfBlob = doc.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      
      return {
        blob: pdfBlob,
        url,
        size: pdfBlob.size,
        pageCount: files.length
      };
    } catch (error) {
      console.error('Dönüştürme hatası:', error);
      toast({
        title: "Dönüştürme Hatası",
        description: "Dosyalar PDF'e dönüştürülürken bir hata oluştu.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsConverting(false);
    }
  }, [toast]);
  
  /**
   * Office belgelerini PDF'e dönüştürebilen basit bir mock fonksiyon
   * Not: Gerçek uygulamada sunucu tarafında düzgün dönüştürme gerekir
   */
  const convertDocumentToPdf = useCallback(async (
    file: File,
    options: ConversionOptions = {}
  ): Promise<ConversionResult | null> => {
    setIsConverting(true);
    
    try {
      // A4 boyutunda bir PDF oluştur
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const margin = options.margin || 20; // Office belgeleri için daha fazla margin
      
      // Dosya bilgilerini PDF'e ekle (basit bir metin görünümü)
      doc.setFontSize(16);
      doc.text(`Belge: ${file.name}`, margin, margin + 10);
      
      doc.setFontSize(12);
      doc.text(`Tür: ${file.type}`, margin, margin + 20);
      doc.text(`Boyut: ${formatFileSize(file.size)}`, margin, margin + 30);
      
      if (file.type.includes('excel') || file.type.includes('spreadsheet')) {
        doc.text("Excel tablosu içeriği burada görüntülenecek", margin, margin + 50);
        doc.line(margin, margin + 55, 190 - margin, margin + 55); // Yatay çizgi
        
        // Excel-benzeri tablo çiz
        const tableY = margin + 65;
        for (let row = 0; row < 10; row++) {
          for (let col = 0; col < 5; col++) {
            const cellX = margin + (col * 35);
            const cellY = tableY + (row * 10);
            
            // Hücre çerçevesi
            doc.rect(cellX, cellY, 35, 10);
            
            // Hücre içeriği (sadece örnek)
            if (row === 0) {
              doc.setFont('helvetica', 'bold');
              doc.text(`Sütun ${col+1}`, cellX + 2, cellY + 6);
              doc.setFont('helvetica', 'normal');
            } else {
              // Basit içerik örnekleri
              doc.text(`Hücre ${row},${col}`, cellX + 2, cellY + 6);
            }
          }
        }
      } else if (file.type.includes('word') || file.type.includes('document')) {
        doc.text("Word belgesi içeriği burada görüntülenecek", margin, margin + 50);
        
        // Belge içeriği simülasyonu
        const paragraphs = [
          "Bu bir Word belgesi simülasyonudur. Gerçek belgede içerik farklı olabilir.",
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec felis nec ligula blandit elementum.",
          "Suspendisse potenti. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.",
          "Aenean ullamcorper, tortor sed faucibus malesuada, nibh odio convallis ex, a ultrices nunc nunc ac massa."
        ];
        
        let yPos = margin + 60;
        paragraphs.forEach(paragraph => {
          const lines = doc.splitTextToSize(paragraph, 190 - (margin * 2));
          doc.text(lines, margin, yPos);
          yPos += 10 * lines.length;
        });
      } else if (file.type.includes('presentation')) {
        doc.text("PowerPoint sunumu içeriği burada görüntülenecek", margin, margin + 50);
        
        // Slayt içeriği simülasyonu
        doc.setFillColor(240, 240, 240);
        doc.rect(margin, margin + 60, 170, 100, 'F');
        
        doc.setFontSize(14);
        doc.text("Slayt Başlığı", margin + 85, margin + 80, { align: 'center' });
        
        doc.setFontSize(12);
        doc.text("• Madde 1", margin + 20, margin + 100);
        doc.text("• Madde 2", margin + 20, margin + 110);
        doc.text("• Madde 3", margin + 20, margin + 120);
        
        doc.setFontSize(10);
        doc.text("Sunum Sahibi", margin + 160, margin + 150, { align: 'right' });
      } else {
        // Diğer belge türleri için genel içerik
        doc.text("Bu belge içeriği burada görüntülenecek", margin, margin + 50);
        
        // Basit metin içeriği
        const content = "Bu belge içeriği otomatik olarak oluşturulmuştur. Gerçek içerik farklı olabilir.";
        const lines = doc.splitTextToSize(content, 190 - (margin * 2));
        doc.text(lines, margin, margin + 60);
      }
      
      // Not ekle
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(
        "Not: Bu PDF, istemci tarafında oluşturulmuştur ve belgenin tam içeriğini içermeyebilir.",
        margin, 
        270
      );
      
      // PDF'i blob olarak döndür
      const pdfBlob = doc.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      
      return {
        blob: pdfBlob,
        url,
        size: pdfBlob.size,
        pageCount: 1
      };
    } catch (error) {
      console.error('Dönüştürme hatası:', error);
      toast({
        title: "Dönüştürme Hatası",
        description: "Belge PDF'e dönüştürülürken bir hata oluştu.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsConverting(false);
    }
  }, [toast]);
  
  /**
   * Dosya türüne göre dönüştürme işlemini gerçekleştirir
   */
  const convertFileToPdf = useCallback(async (
    file: File,
    options: ConversionOptions = {}
  ): Promise<ConversionResult | null> => {
    const imageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp', 'image/tiff'];
    
    if (imageTypes.includes(file.type)) {
      return convertImagesToPdf([file], options);
    } else {
      return convertDocumentToPdf(file, options);
    }
  }, [convertImagesToPdf, convertDocumentToPdf]);
  
  /**
   * Birden fazla dosyayı tek bir PDF'e dönüştürür
   */
  const convertFilesToPdf = useCallback(async (
    files: File[],
    options: ConversionOptions = {}
  ): Promise<ConversionResult | null> => {
    if (files.length === 0) return null;
    
    // Tüm dosyalar görsel ise, tek seferde dönüştür
    const imageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp', 'image/tiff'];
    const allImages = files.every(file => imageTypes.includes(file.type));
    
    if (allImages) {
      return convertImagesToPdf(files, options);
    }
    
    // Karışık dosya türleri için birbirini takip eden işlemler
    setIsConverting(true);
    
    try {
      // A4 boyutunda bir PDF oluştur
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      // Her dosya için işlem yap
      for (let i = 0; i < files.length; i++) {
        // İlk sayfa dışında yeni sayfa ekle
        if (i > 0) {
          doc.addPage();
        }
        
        const file = files[i];
        
        // Dosya türüne göre dönüştürme
        const result = await convertFileToPdf(file, options);
        
        if (!result) {
          toast({
            title: "Dosya Hatası",
            description: `${file.name} dönüştürülemedi.`,
            variant: "destructive",
          });
          continue;
        }
        
        // Dönüştürülen PDF'i ana PDF'e ekle
        // Not: Bu basit bir simülasyondur
        doc.setFontSize(16);
        doc.text(`Dosya: ${file.name}`, 20, 30);
        doc.setFontSize(12);
        doc.text(`Tür: ${file.type}`, 20, 40);
        doc.text(`Boyut: ${formatFileSize(file.size)}`, 20, 50);
        doc.text(`Sayfalar: ${result.pageCount}`, 20, 60);
      }
      
      // PDF'i blob olarak döndür
      const pdfBlob = doc.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      
      return {
        blob: pdfBlob,
        url,
        size: pdfBlob.size,
        pageCount: files.length
      };
    } catch (error) {
      console.error('Çoklu dönüştürme hatası:', error);
      toast({
        title: "Dönüştürme Hatası",
        description: "Dosyalar PDF'e dönüştürülürken bir hata oluştu.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsConverting(false);
    }
  }, [convertImagesToPdf, convertFileToPdf, toast]);

  return {
    isConverting,
    convertImagesToPdf,
    convertDocumentToPdf,
    convertFileToPdf,
    convertFilesToPdf
  };
}

// Yardımcı fonksiyonlar
function readFileAsDataURL(file: File): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  else return (bytes / 1048576).toFixed(1) + ' MB';
}