import { createWorker, Worker, RecognizeResult } from 'tesseract.js';
import * as pdfjs from 'pdfjs-dist';

// Tesseract.js için tip tanımları
interface TesseractProgressReport {
  status: string;
  progress: number;
}

/**
 * PDF sayfasını resme dönüştüren yardımcı fonksiyon
 * @param pdfData PDF dosyasının ArrayBuffer verisi
 * @param pageNum Sayfa numarası
 * @param scale Ölçek faktörü (kalite için)
 * @returns Sayfa görüntüsünün base64 kodlu data URL'i
 */
export async function convertPdfPageToImage(pdfData: ArrayBuffer, pageNum: number, scale: number = 2.0): Promise<string> {
  try {
    // PDF dokümanını yükle
    const loadingTask = pdfjs.getDocument({ data: pdfData });
    const pdf = await loadingTask.promise;
    
    // İstenen sayfayı al
    const page = await pdf.getPage(pageNum);
    
    // Sayfanın viewport'unu ayarla
    const viewport = page.getViewport({ scale });
    
    // Görüntü oluştur
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    if (!context) {
      throw new Error('Canvas context oluşturulamadı');
    }
    
    canvas.height = viewport.height;
    canvas.width = viewport.width;
    
    // Sayfayı canvas'a çiz
    const renderContext = {
      canvasContext: context,
      viewport: viewport,
    };
    
    await page.render(renderContext).promise;
    
    // Canvas'tan base64 görüntü elde et
    return canvas.toDataURL('image/png');
  } catch (error) {
    console.error('PDF sayfası resme dönüştürülürken hata oluştu:', error);
    throw error;
  }
}

/**
 * PDF sayfasındaki görsellerden metin çıkaran OCR fonksiyonu
 * @param imageDataUrl OCR için kullanılacak resmin data URL'i
 * @param language Tesseract dil paketi (varsayılan: 'tur+eng')
 * @param progressCallback İlerleme durumu bildirimi için callback fonksiyonu
 * @returns Çıkarılan metin
 */
export async function performOCR(
  imageDataUrl: string, 
  language: string = 'tur+eng', 
  progressCallback?: (progress: number) => void
): Promise<string> {
  try {
    // Tesseract worker'ı başlat
    const worker = await createWorker();
    
    if (progressCallback) {
      worker.setProgressHandler((m: TesseractProgressReport) => {
        if (m.status === 'recognizing text') {
          progressCallback(m.progress);
        }
      });
    }
    
    // Dili yükle ve OCR işlemini başlat
    await worker.loadLanguage(language);
    await worker.initialize(language);
    
    // OCR işlemi
    const result = await worker.recognize(imageDataUrl) as RecognizeResult;
    
    // Worker'ı sonlandır
    await worker.terminate();
    
    return result.data.text;
  } catch (error) {
    console.error('OCR işlemi sırasında hata oluştu:', error);
    throw error;
  }
}

/**
 * Tam PDF dosyasını OCR ile tarar ve metinleri sayfa sayfa çıkarır
 * @param pdfData PDF dosyasının ArrayBuffer verisi
 * @param progressCallback İlerleme durumu bildirimi için callback fonksiyonu
 * @returns Her sayfanın çıkarılan metnini içeren bir dizi
 */
export async function scanPdfWithOCR(
  pdfData: ArrayBuffer,
  progressCallback?: (page: number, totalPages: number, pageProgress: number) => void
): Promise<string[]> {
  try {
    // PDF dokümanını yükle
    const loadingTask = pdfjs.getDocument({ data: pdfData });
    const pdf = await loadingTask.promise;
    
    const totalPages = pdf.numPages;
    const pageTexts: string[] = [];
    
    // Her sayfayı tara
    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      // Sayfayı görüntüye dönüştür
      const imageDataUrl = await convertPdfPageToImage(pdfData, pageNum);
      
      // OCR ile metni çıkar
      const pageText = await performOCR(
        imageDataUrl, 
        'tur+eng', 
        progressCallback 
          ? (progress) => progressCallback(pageNum, totalPages, progress)
          : undefined
      );
      
      pageTexts.push(pageText);
    }
    
    return pageTexts;
  } catch (error) {
    console.error('PDF OCR taraması sırasında hata oluştu:', error);
    throw error;
  }
}