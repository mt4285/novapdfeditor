import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Çeviriler
const resources = {
  en: {
    translation: {
      // Genel
      "app_title": "PDF Editor",
      "loading": "Loading...",
      "save": "Save",
      "cancel": "Cancel",
      "reset": "Reset",
      "download": "Download",
      "error": "Error",
      "success": "Success",
      "help": "Help",
      
      // Giriş sayfası
      "login": "Login",
      "register": "Register",
      "email": "Email",
      "password": "Password",
      "username": "Username",
      "welcome": "Welcome to PDF Editor",
      "welcome_subtitle": "Edit your PDF documents easily and securely",
      "login_button": "Login",
      "register_button": "Register",
      "forgot_password": "Forgot password?",
      "no_account": "Don't have an account?",
      "have_account": "Already have an account?",
      
      // Ana sayfa
      "pdf_preview": "PDF Preview",
      "pdf_upload": "PDF Upload",
      "file_select": "Select File",
      "drop_files": "Drop your PDF file here",
      "or": "or",
      "edit_tools": "Editing Tools",
      "text_edit": "Text Editing",
      "add_text": "Add Text",
      "text_to_add": "Text to add...",
      "add_button": "Add",
      "page_nav": "Page Navigation",
      "previous": "Previous",
      "next": "Next",
      "bold": "Bold",
      "italic": "Italic",
      "underline": "Underline",
      "text_color": "Text Color",
      "download_edited": "Download Edited PDF",
      "reset_button": "Reset",
      "position_selected": "Position selected. Now you can enter text.",
      
      // Yardım Modalı
      "help_title": "PDF Editor Help",
      "help_subtitle": "Information about how to edit PDF files",
      "how_to_use": "How to Use?",
      "limitations": "Limitations",
      "understood": "Got it",
      
      // Yardım içeriği
      "help_step1": "Upload a PDF file by clicking on the \"Select File\" button or by dragging and dropping onto the area.",
      "help_step2": "The uploaded PDF will be displayed in the preview area.",
      "help_step3": "Click on the text on the page to edit it.",
      "help_step4": "Use the \"Add Text\" field to add new text.",
      "help_step5": "When you're done, click on the \"Download Edited PDF\" button to download your document.",
      
      "limit1": "This application only supports basic text editing operations.",
      "limit2": "Complex formatting, tables, or images may not be editable.",
      "limit3": "Large PDF files may take longer to upload."
    }
  },
  tr: {
    translation: {
      // Genel
      "app_title": "PDF Düzenleyici",
      "loading": "Yükleniyor...",
      "save": "Kaydet",
      "cancel": "İptal",
      "reset": "Sıfırla",
      "download": "İndir",
      "error": "Hata",
      "success": "Başarılı",
      "help": "Yardım",
      
      // Giriş sayfası
      "login": "Giriş",
      "register": "Kayıt Ol",
      "email": "E-posta",
      "password": "Şifre",
      "username": "Kullanıcı Adı",
      "welcome": "PDF Düzenleyici'ye Hoş Geldiniz",
      "welcome_subtitle": "PDF belgelerinizi kolayca ve güvenle düzenleyin",
      "login_button": "Giriş Yap",
      "register_button": "Kayıt Ol",
      "forgot_password": "Şifremi unuttum?",
      "no_account": "Hesabınız yok mu?",
      "have_account": "Zaten hesabınız var mı?",
      
      // Ana sayfa
      "pdf_preview": "PDF Önizleme",
      "pdf_upload": "PDF Yükleme",
      "file_select": "Dosya Seç",
      "drop_files": "PDF dosyanızı sürükleyip bırakın",
      "or": "veya",
      "edit_tools": "Düzenleme Araçları",
      "text_edit": "Metin Düzenleme",
      "add_text": "Metin Ekle",
      "text_to_add": "Eklenecek metin...",
      "add_button": "Ekle",
      "page_nav": "Sayfa Navigasyonu",
      "previous": "Önceki",
      "next": "Sonraki",
      "bold": "Kalın",
      "italic": "İtalik",
      "underline": "Altı Çizili",
      "text_color": "Metin Rengi",
      "download_edited": "Düzenlenmiş PDF'i İndir",
      "reset_button": "Sıfırla",
      "position_selected": "Metin eklemek için bir konum seçildi. Şimdi metni girebilirsiniz.",
      
      // Yardım Modalı
      "help_title": "PDF Düzenleyici Yardım",
      "help_subtitle": "PDF dosyalarını nasıl düzenleyeceğiniz hakkında bilgiler",
      "how_to_use": "Nasıl Kullanılır?",
      "limitations": "Sınırlamalar",
      "understood": "Anladım",
      
      // Yardım içeriği
      "help_step1": "\"Dosya Seç\" butonuna tıklayarak veya alanın üzerine sürükleyerek bir PDF dosyası yükleyin.",
      "help_step2": "Yüklenen PDF önizleme alanında görüntülenecektir.",
      "help_step3": "Sayfa üzerindeki metinlere tıklayarak düzenleme yapabilirsiniz.",
      "help_step4": "Yeni metin eklemek için \"Metin Ekle\" alanını kullanabilirsiniz.",
      "help_step5": "İşiniz bittiğinde \"Düzenlenmiş PDF'i İndir\" butonuna tıklayarak belgenizi indirebilirsiniz.",
      
      "limit1": "Bu uygulama yalnızca temel metin düzenleme işlemlerini desteklemektedir.",
      "limit2": "Karmaşık formatlamalar, tablolar veya görüntüler düzenlenemeyebilir.",
      "limit3": "Büyük boyutlu PDF dosyaları yüklenirken daha uzun sürebilir."
    }
  }
};

// i18next'i yapılandırma ve başlatma
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'tr',
    lng: localStorage.getItem('i18nextLng') || 'tr', // Açıkça dil ayarını belirt
    interpolation: {
      escapeValue: false // React zaten XSS koruması sağladığı için
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
      lookupLocalStorage: 'i18nextLng'
    }
  });

export default i18n;