import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
// TypeScript için PDF.js global tanımlaması
declare global {
  interface Window {
    pdfjsLib: any;
  }
}

// PDF.js worker'ını yapılandır - CDN kullanıyoruz artık
// CDN'den yükleme için worker URL'ini ayarlıyoruz
// Worker URL'i index.html'de CDN ile tanımlanıyor

// Function to load a PDF file
export async function loadPDF(file: File): Promise<any> {
  const arrayBuffer = await file.arrayBuffer();
  return window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
}

// Function to load a PDF from a URL
export async function loadPDFFromUrl(url: string): Promise<any> {
  return window.pdfjsLib.getDocument(url).promise;
}

// Function to render a PDF page to canvas
export async function renderPage(
  pdf: any,
  pageNumber: number,
  canvas: HTMLCanvasElement,
  scale: number = 1.0
): Promise<void> {
  const page = await pdf.getPage(pageNumber);
  const viewport = page.getViewport({ scale });

  canvas.height = viewport.height;
  canvas.width = viewport.width;

  const renderContext = {
    canvasContext: canvas.getContext('2d')!,
    viewport,
  };

  await page.render(renderContext).promise;
}

// Function to extract text content from a PDF page
/**
 * PDF'den mevcut metin içeriğini pozisyon, boyut ve stil bilgileriyle birlikte çıkarır
 * 
 * @param pdfData PDF dosyasının ArrayBuffer verisi
 * @param pageNum Sayfa numarası
 * @returns Sayfa üzerindeki metin öğeleri ve konumları
 */
export async function extractTextElements(pdfData: ArrayBuffer, pageNum: number = 1): Promise<Array<{
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize?: number;
  fontFamily?: string;
  id: string;
}>> {
  try {
    // Worker'ı yapılandır
    if (typeof window.pdfjsLib === 'undefined') {
      console.error("PDF.js kütüphanesi yüklenemedi");
      return [];
    }
    
    // PDF yükle
    const loadingTask = window.pdfjsLib.getDocument({ data: pdfData });
    const pdf = await loadingTask.promise;
    
    // Sayfa yükle
    const page = await pdf.getPage(pageNum);
    
    // Metni çıkar
    const textContent = await page.getTextContent();
    const viewport = page.getViewport({ scale: 1.0 });
    
    // Metin öğelerini işle
    const textItems = textContent.items.map((item: any, index: number) => {
      const tx = window.pdfjsLib.Util.transform(
        viewport.transform,
        item.transform
      );
      
      const fontHeight = Math.sqrt((tx[2] * tx[2]) + (tx[3] * tx[3]));
      const angle = Math.atan2(tx[2], tx[3]);
      
      // PDF koordinat sistemi ile ekran koordinat sistemi farklıdır, dönüşüm yapılmalı
      return {
        text: item.str,
        x: tx[4], // x pozisyonu
        y: viewport.height - tx[5], // y pozisyonu (PDF koordinat sisteminde y ekseni tersine çalışır)
        width: item.width || fontHeight * item.str.length * 0.5, // tahmini genişlik
        height: fontHeight, // tahmini yükseklik
        fontSize: fontHeight, // tahmini font boyutu
        fontFamily: item.fontName || "sans-serif",
        id: `text-${pageNum}-${index}-${Date.now()}` // benzersiz ID
      };
    });
    
    console.log(`PDF'den ${textItems.length} metin öğesi çıkarıldı:`, textItems);
    return textItems;
    
  } catch (error) {
    console.error("Metin çıkarma hatası:", error);
    return [];
  }
}

/**
 * PDF'den belirli bir metin öğesini siler
 * 
 * @param pdfBuffer PDF dosyasının ArrayBuffer verisi
 * @param pageNum Sayfa numarası
 * @param textId Silinecek metin öğesinin ID'si
 * @returns Güncellenmiş PDF'in ArrayBuffer verisi
 */
export async function deleteTextFromPDF(
  pdfBuffer: ArrayBuffer,
  pageNum: number,
  textId: string
): Promise<ArrayBuffer> {
  try {
    // PDF'i yükle
    const { PDFDocument } = await import('pdf-lib');
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    
    // Burada gerçek bir silme işlemi için, metni beyaz bir dikdörtgen ile kapatıyoruz
    // Daha gelişmiş bir çözüm için, metnin konumunu bilip üzerine beyaz bir dikdörtgen çizebiliriz
    const pages = pdfDoc.getPages();
    const page = pages[pageNum - 1]; // Sayfa numarası 1'den başlar
    
    // Tüm metinleri çıkar
    const textElements = await extractTextElements(pdfBuffer, pageNum);
    
    // Silinecek metni bul
    const textToDelete = textElements.find(item => item.id === textId);
    
    if (textToDelete) {
      // Metnin üzerine beyaz bir dikdörtgen çiz
      page.drawRectangle({
        x: textToDelete.x,
        y: page.getHeight() - textToDelete.y - textToDelete.height, // PDF koordinat sistemine göre dönüştür
        width: textToDelete.width,
        height: textToDelete.height,
        color: { r: 1, g: 1, b: 1 }, // Beyaz
        opacity: 1
      });
      
      console.log(`"${textToDelete.text}" metni silindi`);
    } else {
      console.warn(`ID: ${textId} ile eşleşen metin bulunamadı`);
    }
    
    // Güncellenmiş PDF'i döndür
    const modifiedPdfBytes = await pdfDoc.save();
    return modifiedPdfBytes.buffer;
    
  } catch (error) {
    console.error("PDF metin silme hatası:", error);
    throw error;
  }
}

/**
 * PDF'deki mevcut bir metni günceller
 * 
 * @param pdfBuffer PDF dosyasının ArrayBuffer verisi
 * @param pageNum Sayfa numarası
 * @param textId Güncellenecek metin öğesinin ID'si
 * @param newText Yeni metin içeriği
 * @param options Metin stili seçenekleri (renk, boyut vb.)
 * @returns Güncellenmiş PDF'in ArrayBuffer verisi
 */
export async function updateTextInPDF(
  pdfBuffer: ArrayBuffer,
  pageNum: number,
  textId: string,
  newText: string,
  options?: {
    fontSize?: number;
    fontColor?: string;
    fontFamily?: string;
  }
): Promise<ArrayBuffer> {
  try {
    // PDF'i yükle
    const { PDFDocument, rgb } = await import('pdf-lib');
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    
    // Önce metni sil (üzerine beyaz dikdörtgen çizerek)
    const intermediateBuffer = await deleteTextFromPDF(pdfBuffer, pageNum, textId);
    const updatedDoc = await PDFDocument.load(intermediateBuffer);
    
    // Tüm metinleri çıkar
    const textElements = await extractTextElements(pdfBuffer, pageNum);
    
    // Güncellenecek metni bul
    const textToUpdate = textElements.find(item => item.id === textId);
    
    if (textToUpdate) {
      // İlgili sayfayı al
      const pages = updatedDoc.getPages();
      const page = pages[pageNum - 1];
      
      // Metin stilini belirle
      const fontSize = options?.fontSize || textToUpdate.fontSize || 12;
      const fontColor = options?.fontColor || "#000000";
      
      // Renk değerlerini RGB formatına dönüştür (hex -> rgb)
      const color = fontColor.replace('#', '');
      const r = parseInt(color.substr(0, 2), 16) / 255;
      const g = parseInt(color.substr(2, 2), 16) / 255;
      const b = parseInt(color.substr(4, 2), 16) / 255;
      
      // Metni güncelle
      page.drawText(newText, {
        x: textToUpdate.x,
        y: page.getHeight() - textToUpdate.y - textToUpdate.height, // PDF koordinat sistemine göre dönüştür
        size: fontSize,
        color: rgb(r, g, b),
      });
      
      console.log(`"${textToUpdate.text}" metni "${newText}" olarak güncellendi`);
    } else {
      console.warn(`ID: ${textId} ile eşleşen metin bulunamadı`);
    }
    
    // Güncellenmiş PDF'i döndür
    const modifiedPdfBytes = await updatedDoc.save();
    return modifiedPdfBytes.buffer;
    
  } catch (error) {
    console.error("PDF metin güncelleme hatası:", error);
    throw error;
  }
}

export async function extractTextContent(
  pdf: any,
  pageNumber: number
): Promise<any> {
  const page = await pdf.getPage(pageNumber);
  return page.getTextContent();
}

// Function to add text to a PDF document
export async function addTextToPDF(
  pdfBuffer: ArrayBuffer,
  text: string,
  pageNumber: number,
  x: number,
  y: number,
  fontSize: number = 12,
  color: { r: number; g: number; b: number } = { r: 0, g: 0, b: 0 }
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(pdfBuffer);
  const pages = pdfDoc.getPages();
  
  // Ensure page number is valid
  if (pageNumber < 1 || pageNumber > pages.length) {
    throw new Error(`Invalid page number: ${pageNumber}. Document has ${pages.length} pages.`);
  }
  
  const page = pages[pageNumber - 1];
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  
  page.drawText(text, {
    x,
    y: page.getHeight() - y, // PDF coordinates start from bottom-left
    size: fontSize,
    font,
    color: rgb(color.r, color.g, color.b),
  });
  
  return pdfDoc.save();
}

// Function to modify text in a PDF (simplified placeholder)
// Note: Modifying existing text in PDFs is complex and may require more advanced techniques
export async function modifyTextInPDF(
  pdfBuffer: ArrayBuffer,
  pageNumber: number,
  oldText: string,
  newText: string
): Promise<Uint8Array | null> {
  // This is a simplified placeholder function
  // In a real implementation, modifying existing text would require
  // more complex handling, possibly involving removing content and adding new content
  console.warn('Text modification in PDFs is a complex operation and may not work in all cases');
  
  const pdfDoc = await PDFDocument.load(pdfBuffer);
  // Actual implementation would be more complex
  
  return pdfDoc.save();
}

// Helper function to convert PDF coordinates
export function convertPdfCoordinates(
  pdfPageHeight: number,
  x: number,
  y: number
): { pdfX: number; pdfY: number } {
  // PDF coordinates start from bottom-left, while browser coordinates
  // start from top-left, so we need to flip the y-coordinate
  return {
    pdfX: x,
    pdfY: pdfPageHeight - y,
  };
}
