import { jsPDF } from 'jspdf';
import { pdfjs } from '@/lib/pdf-config';

// PDF'teki metin öğelerinin koordinat ve içerik bilgilerini tutan arayüz
export interface PDFTextItem {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  pageNumber: number;
  itemIndex: number;
  
  // Metin biçimlendirme özellikleri
  fontSize?: number;
  fontFamily?: string;
  fontColor?: string;
  textAlign?: 'left' | 'center' | 'right' | 'justify';
  fontWeight?: 'normal' | 'bold';
  fontStyle?: 'normal' | 'italic';
  textDecoration?: 'none' | 'underline';
}

// Belirli bir PDF sayfasındaki tüm metin öğelerini çıkarma
export async function extractTextFromPage(pdfUrl: string, pageNumber: number): Promise<PDFTextItem[]> {
  try {
    // PDF dosyasını yükle
    const loadingTask = pdfjs.getDocument(pdfUrl);
    const pdf = await loadingTask.promise;
    
    // Sayfayı al
    const page = await pdf.getPage(pageNumber);
    
    // Sayfadan metin içeriğini çıkar
    const textContent = await page.getTextContent();
    
    // Metin öğelerini dönüştür
    const viewport = page.getViewport({ scale: 1.0 });
    const textItems: PDFTextItem[] = [];
    
    // Her metin öğesi için
    textContent.items.forEach((item: any, index: number) => {
      // Metin öğesi koordinatlarını dönüştür
      const transform = pdfjs.Util.transform(viewport.transform, item.transform);
      
      // Genişlik ve yükseklik hesapla (yaklaşık)
      const fontHeight = Math.sqrt((transform[2] * transform[2]) + (transform[3] * transform[3]));
      // Metin genişliğini karakter sayısına göre yaklaşık hesapla
      // pdfjs.Util.getUnicodeWidth() fonksiyonu bulunamadığından, basit bir hesaplama yöntemi kullanıyoruz
      const textWidth = item.str.length * fontHeight * 0.5;
      
      // Metin öğesini ekle
      textItems.push({
        text: item.str,
        x: transform[4],
        y: transform[5],
        width: textWidth,
        height: fontHeight,
        pageNumber,
        itemIndex: index
      });
    });
    
    return textItems;
    
  } catch (error) {
    console.error('PDF metin çıkarma hatası:', error);
    return [];
  }
}

// Düzenlenmiş metinle yeni PDF oluşturma
export async function createEditedPDF(
  pdfUrl: string, 
  editedTextItems: PDFTextItem[],
  fileName: string = 'edited-document.pdf'
): Promise<Blob> {
  try {
    // Orijinal PDF'i yükle
    const loadingTask = pdfjs.getDocument(pdfUrl);
    const pdf = await loadingTask.promise;
    
    // Toplam sayfa sayısını al
    const numPages = pdf.numPages;
    
    // Düzenlenmiş metinleri sayfalara göre grupla
    const textItemsByPage: { [pageNumber: number]: PDFTextItem[] } = {};
    
    editedTextItems.forEach(item => {
      if (!textItemsByPage[item.pageNumber]) {
        textItemsByPage[item.pageNumber] = [];
      }
      textItemsByPage[item.pageNumber].push(item);
    });
    
    // Yeni PDF oluştur
    const doc = new jsPDF();
    
    // Her sayfa için işlem yap
    for (let pageNumber = 1; pageNumber <= numPages; pageNumber++) {
      if (pageNumber > 1) {
        doc.addPage();
      }
      
      // Sayfayı al
      const page = await pdf.getPage(pageNumber);
      const viewport = page.getViewport({ scale: 1.0 });
      
      // Orijinal sayfayı arka plan olarak ekle (bu adım gelişmiş bir uygulamada canvas ile yapılabilir)
      // Bu örnek için basitleştirilmiş bir yaklaşım kullanıyoruz
      
      // Bu sayfadaki düzenlenmiş metinleri ekle
      const pageTextItems = textItemsByPage[pageNumber] || [];
      pageTextItems.forEach(item => {
        // PDF koordinat sistemine dönüştür (dikkat: jsPDF ve PDF.js koordinat sistemleri farklıdır)
        // jsPDF için y koordinatı aşağıdan yukarıya, PDF.js için yukarıdan aşağıyadır
        const x = item.x;
        const y = viewport.height - item.y; // Y koordinatını dönüştür
        
        // Font stilini ayarla
        if (item.fontSize) {
          doc.setFontSize(item.fontSize);
        }
        
        // Font ailesini ayarla (eğer destekleniyorsa)
        if (item.fontFamily) {
          try {
            doc.setFont(item.fontFamily.toLowerCase());
          } catch (e) {
            // Eğer font desteklenmiyorsa, default font kullan
            console.warn(`Font not supported: ${item.fontFamily}, using default`);
          }
        }
        
        // Font rengini ayarla
        if (item.fontColor) {
          // Hex renk değerini RGB'ye çevir
          const hex = item.fontColor.replace('#', '');
          const r = parseInt(hex.substring(0, 2), 16) / 255;
          const g = parseInt(hex.substring(2, 4), 16) / 255;
          const b = parseInt(hex.substring(4, 6), 16) / 255;
          doc.setTextColor(r * 255, g * 255, b * 255);
        }
        
        // Font stillerini ayarla
        let fontStyle = '';
        if (item.fontWeight === 'bold') fontStyle += 'bold';
        if (item.fontStyle === 'italic') fontStyle += 'italic';
        if (fontStyle) {
          doc.setFont(item.fontFamily?.toLowerCase() || 'helvetica', fontStyle);
        }
        
        // Text align ayarla (jsPDF'in desteklediği şekilde)
        let align: 'left' | 'center' | 'right' | 'justify' = 'left';
        if (item.textAlign && ['left', 'center', 'right', 'justify'].includes(item.textAlign)) {
          align = item.textAlign as 'left' | 'center' | 'right' | 'justify';
        }
        
        // Metni ekle
        doc.text(item.text, x, y, { align });
        
        // Altı çizili metin için
        if (item.textDecoration === 'underline') {
          const textWidth = doc.getTextWidth(item.text);
          const lineHeight = 0.5; // Çizgi kalınlığı
          doc.line(x, y + lineHeight, x + textWidth, y + lineHeight);
        }
      });
    }
    
    // PDF'i blob olarak döndür
    return doc.output('blob');
    
  } catch (error) {
    console.error('PDF düzenleme hatası:', error);
    throw error;
  }
}

// TextFormatting tipi (TextEditor ile uyumlu)
export interface TextFormatting {
  fontSize?: number;
  fontFamily?: string;
  fontColor?: string;
  textAlign?: 'left' | 'center' | 'right' | 'justify';
  fontWeight?: 'normal' | 'bold';
  fontStyle?: 'normal' | 'italic';
  textDecoration?: 'none' | 'underline';
}

// Metin öğelerinin içeriğini ve biçimlendirmesini güncelleme
export function updateTextItem(
  textItems: PDFTextItem[], 
  itemIndex: number, 
  newText: string, 
  formatting?: TextFormatting
): PDFTextItem[] {
  return textItems.map(item => {
    if (item.itemIndex === itemIndex) {
      return {
        ...item,
        text: newText,
        ...(formatting && {
          fontSize: formatting.fontSize,
          fontFamily: formatting.fontFamily,
          fontColor: formatting.fontColor,
          textAlign: formatting.textAlign,
          fontWeight: formatting.fontWeight,
          fontStyle: formatting.fontStyle,
          textDecoration: formatting.textDecoration
        })
      };
    }
    return item;
  });
}