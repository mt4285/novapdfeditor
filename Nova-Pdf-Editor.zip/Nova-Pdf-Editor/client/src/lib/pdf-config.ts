import { pdfjs } from 'react-pdf';

// Burada tüm PDF.js worker yapılandırmasını tek yerde yapıyoruz
// ve tüm projede bunu kullanıyoruz
console.log("PDF.js yapılandırılıyor. Mevcut versiyon:", pdfjs.version);

// Kullanıcının belirttiği sürüme göre (pdfjs-dist@3.11.174) worker'ı ayarlıyoruz
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js`;

console.log("Worker URL:", pdfjs.GlobalWorkerOptions.workerSrc);

export { pdfjs };