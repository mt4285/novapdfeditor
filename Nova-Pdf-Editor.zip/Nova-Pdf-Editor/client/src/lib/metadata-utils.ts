import { PDFDocument } from 'pdf-lib';

/**
 * PDF metaveri bilgilerini temsil eden interface
 */
export interface PDFMetadata {
  title?: string;
  author?: string;
  subject?: string;
  keywords?: string;
  creator?: string;
  producer?: string;
  creationDate?: Date;
  modificationDate?: Date;
}

/**
 * PDF dosyasından metaveri bilgilerini okuyan fonksiyon
 * 
 * @param pdfBuffer PDF dosyasının ArrayBuffer verisi
 * @returns Metaveri bilgilerini içeren nesne
 */
export async function readPDFMetadata(pdfBuffer: ArrayBuffer): Promise<PDFMetadata> {
  try {
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    
    // Mevcut metaveri bilgilerini al
    const title = pdfDoc.getTitle() || undefined;
    const author = pdfDoc.getAuthor() || undefined;
    const subject = pdfDoc.getSubject() || undefined;
    const keywords = pdfDoc.getKeywords() || undefined;
    const creator = pdfDoc.getCreator() || undefined;
    const producer = pdfDoc.getProducer() || undefined;
    
    // Tarih bilgilerini al (varsa)
    const creationDate = pdfDoc.getCreationDate() || undefined;
    const modificationDate = pdfDoc.getModificationDate() || undefined;
    
    return {
      title,
      author,
      subject,
      keywords,
      creator,
      producer,
      creationDate,
      modificationDate
    };
  } catch (error) {
    console.error('PDF metaveri okuma hatası:', error);
    throw new Error('PDF dosyasından metaveriler okunamadı');
  }
}

/**
 * PDF dosyasının metaveri bilgilerini güncelleyen fonksiyon
 * 
 * @param pdfBuffer PDF dosyasının ArrayBuffer verisi
 * @param metadata Güncellenecek metaveri bilgileri
 * @returns Güncellenmiş PDF dosyasının Uint8Array verisi
 */
export async function updatePDFMetadata(
  pdfBuffer: ArrayBuffer,
  metadata: PDFMetadata
): Promise<Uint8Array> {
  try {
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    
    // Metaveri bilgilerini güncelle
    if (metadata.title !== undefined) {
      pdfDoc.setTitle(metadata.title);
    }
    
    if (metadata.author !== undefined) {
      pdfDoc.setAuthor(metadata.author);
    }
    
    if (metadata.subject !== undefined) {
      pdfDoc.setSubject(metadata.subject);
    }
    
    if (metadata.keywords !== undefined) {
      // PDF-lib expects an array for keywords, while we're storing as a single string
      // keywords string'ini virgülle ayırarak array'e çeviriyoruz
      const keywordsArray = metadata.keywords.split(',').map(k => k.trim());
      pdfDoc.setKeywords(keywordsArray);
    }
    
    if (metadata.creator !== undefined) {
      pdfDoc.setCreator(metadata.creator);
    }
    
    if (metadata.producer !== undefined) {
      pdfDoc.setProducer(metadata.producer);
    }
    
    // Tarih bilgilerini güncelle
    if (metadata.creationDate instanceof Date) {
      pdfDoc.setCreationDate(metadata.creationDate);
    }
    
    if (metadata.modificationDate instanceof Date) {
      pdfDoc.setModificationDate(metadata.modificationDate);
    } else {
      // Modifikasyon tarihi belirtilmemişse, şu anki zaman ile güncelle
      pdfDoc.setModificationDate(new Date());
    }
    
    // Güncellenen PDF'i kaydet
    return await pdfDoc.save();
  } catch (error) {
    console.error('PDF metaveri güncelleme hatası:', error);
    throw new Error('PDF dosyasının metaverileri güncellenemedi');
  }
}

/**
 * PDF dosyasının başlığını kontrol eden yardımcı fonksiyon
 * 
 * @param metadata Metaveri bilgileri
 * @param filename Dosya adı (başlık mevcut değilse kullanılır)
 * @returns Formatlanmış başlık
 */
export function getFormattedTitle(metadata: PDFMetadata, filename: string): string {
  if (metadata.title && metadata.title.trim() !== '') {
    return metadata.title;
  }
  
  // Başlık yoksa dosya adını kullan (uzantısız)
  return filename.replace(/\.[^/.]+$/, '');
}