import React, { useState, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Download, Save, ChevronUp, ChevronDown, X, Plus } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import ImageUpload from '@/components/ImageUpload';
import MobileActionBar from '@/components/MobileActionBar';
import { jsPDF } from 'jspdf';
import BackButton from '@/components/ui/back-button';

const ImagesToPDFPage: React.FC = () => {
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  // Resim seçildiğinde bu fonksiyon çağrılır
  const handleImagesSelected = useCallback((files: File[]) => {
    setSelectedImages(prev => [...prev, ...files]);
    
    // Seçilen resimlerin önizlemesini oluştur
    const newPreviewUrls = files.map(file => URL.createObjectURL(file));
    setPreviewUrls(prev => [...prev, ...newPreviewUrls]);
    
    toast({
      title: "Resimler Eklendi",
      description: `${files.length} adet resim başarıyla eklendi.`,
      duration: 3000,
    });
  }, [toast]);

  // Seçili resimleri temizle
  const handleReset = useCallback(() => {
    // Önizleme URL'lerini serbest bırak
    previewUrls.forEach(url => URL.revokeObjectURL(url));
    setPreviewUrls([]);
    setSelectedImages([]);
  }, [previewUrls]);
  
  // Belirli bir resmi kaldır
  const removeImage = useCallback((index: number) => {
    URL.revokeObjectURL(previewUrls[index]);
    
    setPreviewUrls(prev => prev.filter((_, i) => i !== index));
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    
    toast({
      title: "Resim Kaldırıldı",
      description: "Seçilen resim başarıyla kaldırıldı.",
      duration: 1500,
    });
  }, [previewUrls, toast]);
  
  // Resmin sırasını değiştir (yukarı taşı)
  const moveImageUp = useCallback((index: number) => {
    if (index <= 0) return;
    
    setSelectedImages(prev => {
      const newImages = [...prev];
      [newImages[index - 1], newImages[index]] = [newImages[index], newImages[index - 1]];
      return newImages;
    });
    
    setPreviewUrls(prev => {
      const newUrls = [...prev];
      [newUrls[index - 1], newUrls[index]] = [newUrls[index], newUrls[index - 1]];
      return newUrls;
    });
  }, []);
  
  // Resmin sırasını değiştir (aşağı taşı)
  const moveImageDown = useCallback((index: number) => {
    if (index >= selectedImages.length - 1) return;
    
    setSelectedImages(prev => {
      const newImages = [...prev];
      [newImages[index], newImages[index + 1]] = [newImages[index + 1], newImages[index]];
      return newImages;
    });
    
    setPreviewUrls(prev => {
      const newUrls = [...prev];
      [newUrls[index], newUrls[index + 1]] = [newUrls[index + 1], newUrls[index]];
      return newUrls;
    });
  }, [selectedImages.length]);

  // Resimleri PDF'e dönüştür
  const handleCreatePDF = useCallback(async () => {
    if (selectedImages.length === 0) {
      toast({
        title: "Hata",
        description: "Lütfen en az bir resim seçin.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    setIsProcessing(true);

    try {
      // A4 boyutunda bir PDF oluştur
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      
      // Her resim için işlem yap
      for (let i = 0; i < selectedImages.length; i++) {
        // İlk sayfa dışında yeni sayfa ekle
        if (i > 0) {
          doc.addPage();
        }
        
        const image = selectedImages[i];
        
        // Resmi base64 formatına dönüştür
        const reader = new FileReader();
        
        const imageLoaded = await new Promise<string>((resolve, reject) => {
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(image);
        });
        
        // PDF sayfasına resmi ekle (sayfaya sığdırarak)
        // Görüntünün en-boy oranını koruyarak sayfaya sığdır
        const imgWidth = pageWidth - 20; // Kenarlarda 10mm boşluk bırak
        const imgHeight = pageHeight - 20; // Kenarlarda 10mm boşluk bırak
        
        doc.addImage(
          imageLoaded, 
          'JPEG', 
          10, // x pozisyonu (sol kenardan 10mm)
          10, // y pozisyonu (üst kenardan 10mm)
          imgWidth, 
          imgHeight, 
          undefined, 
          'FAST',
          0  // Döndürme açısı
        );
      }
      
      // PDF'i indir
      doc.save('resimleriniz.pdf');
      
      toast({
        title: "PDF Oluşturuldu",
        description: `${selectedImages.length} resimden oluşan PDF başarıyla oluşturuldu ve indirildi.`,
        duration: 3000,
      });
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      toast({
        title: "Hata",
        description: "PDF oluşturulurken bir hata oluştu.",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsProcessing(false);
    }
  }, [selectedImages, toast]);

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile && (
          <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
        )}
        <h1 className={`text-2xl font-bold ${isMobile ? 'mx-auto' : ''}`}>Resimden PDF Oluştur</h1>
        {!isMobile && <div className="w-[100px]"></div>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <ImageUpload 
            onImagesSelected={handleImagesSelected}
            isUploading={isProcessing}
            selectedFiles={selectedImages}
            onReset={handleReset}
            title="Resimleri Yükle"
            description="JPG, PNG veya diğer resim formatlarını PDF'e dönüştürün"
          />
          
          {selectedImages.length > 0 && (
            <Card className="p-6 mt-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">PDF Oluştur</h3>
                <p className="text-sm text-gray-500">
                  Seçilen {selectedImages.length} resimden PDF oluşturmak için aşağıdaki butona tıklayın.
                  Her resim bir PDF sayfası olarak eklenecektir.
                </p>
                
                <Button
                  onClick={handleCreatePDF}
                  disabled={isProcessing || selectedImages.length === 0}
                  className="w-full"
                >
                  {isProcessing ? 'PDF Oluşturuluyor...' : 'PDF Oluştur ve İndir'}
                </Button>
              </div>
            </Card>
          )}
        </div>
        
        <div>
          <Card className="p-4">
            <h3 className="text-lg font-semibold mb-4">Resim Önizleme</h3>
            
            {previewUrls.length > 0 ? (
              <div className="grid grid-cols-2 gap-4 max-h-[500px] overflow-y-auto">
                {previewUrls.map((url, index) => (
                  <div key={index} className="border rounded-md overflow-hidden relative group">
                    <img 
                      src={url} 
                      alt={`Önizleme ${index + 1}`} 
                      className="w-full h-auto object-contain"
                    />
                    <div className="p-2 bg-gray-50 dark:bg-gray-800 text-xs text-gray-500 flex justify-between items-center">
                      <span className="truncate mr-1">{selectedImages[index]?.name}</span>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveImageUp(index)}
                          disabled={index === 0}
                        >
                          <ChevronUp className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveImageDown(index)}
                          disabled={index === previewUrls.length - 1}
                        >
                          <ChevronDown className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                          onClick={() => removeImage(index)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center border rounded-md bg-gray-50 dark:bg-gray-800">
                <p className="text-gray-500 text-sm">Önizleme için resim seçin</p>
              </div>
            )}
          </Card>
          
          <div className="mt-4 text-sm text-gray-500">
            <h4 className="font-medium mb-2">İpuçları:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>Resimler PDF'e dönüştürülürken görüntü kalitesi korunacaktır.</li>
              <li>Daha iyi sonuçlar için yüksek çözünürlüklü görüntüler kullanın.</li>
              <li>PDF'te resimlerin sırası, yükleme sırasına göre belirlenecektir.</li>
              <li>Birden fazla resmi tek seferde sürükleyip bırakabilirsiniz.</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="Resimden PDF"
          onSave={selectedImages.length > 0 ? handleCreatePDF : undefined}
          showSave={selectedImages.length > 0}
          showDownload={false}
          isSaving={isProcessing}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default ImagesToPDFPage;