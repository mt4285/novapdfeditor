import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Camera, HardDrive, Bell, ArrowLeft, Upload, Eye, Download, Mic, Square, Play, Pause, Scan, PenTool } from 'lucide-react';
import BackButton from '@/components/ui/back-button';
import CameraCapture from '@/components/CameraCapture';
import FileSystemAccess from '@/components/FileSystemAccess';
import notificationService from '@/services/NotificationService';
import { PushNotifications, PushNotificationSchema } from '@capacitor/push-notifications';
import { useIsMobile } from '@/hooks/use-mobile';
import MobileActionBar from '@/components/MobileActionBar';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { TooltipProvider } from "@/components/ui/tooltip";
import EnhancedPDFViewer from '@/components/EnhancedPDFViewer';

/**
 * Nova PDF Mobil Erişim sayfası
 * PDF görüntüleme, dosya yönetimi ve mobil özellikler
 */
const NativeCapabilitiesPage: React.FC = () => {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [activeTab, setActiveTab] = useState<string>('viewer');
  const [lastNotification, setLastNotification] = useState<PushNotificationSchema | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<boolean | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [savedFile, setSavedFile] = useState<{ uri: string; path: string; name: string } | null>(null);
  const [selectedPdfUrl, setSelectedPdfUrl] = useState<string | null>(null);
  const [uploadedPdfs, setUploadedPdfs] = useState<Array<{id: number, name: string, url: string}>>([]);
  
  // Ses kaydı için state değişkenleri
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [recordedAudios, setRecordedAudios] = useState<Array<{id: string, name: string, url: string, blob: Blob}>>([]);
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);
  
  // İmza için state değişkenleri
  const [isDrawing, setIsDrawing] = useState(false);
  const [signatureCanvas, setSignatureCanvas] = useState<HTMLCanvasElement | null>(null);
  const [savedSignatures, setSavedSignatures] = useState<Array<{id: string, name: string, url: string}>>([]);
  
  // Tarama için state değişkenleri
  const [scannedImages, setScannedImages] = useState<Array<{id: string, name: string, url: string}>>([]);

  // Bildirim servisini başlat
  useEffect(() => {
    const initNotifications = async () => {
      try {
        const result = await notificationService.initialize();
        setNotificationPermission(result);
        
        if (result) {
          // Bildirim dinleyicisi ekle
          const unsubscribe = notificationService.addNotificationListener((notification) => {
            setLastNotification(notification);
            toast({
              title: notification.title || 'Yeni Bildirim',
              description: notification.body || '',
            });
          });
          
          // Temizleme fonksiyonu
          return () => {
            unsubscribe();
          };
        }
      } catch (error) {
        console.error('Bildirim başlatma hatası:', error);
      }
    };
    
    initNotifications();
  }, [toast]);

  // Kamera ile yakalanan görüntüyü işle
  const handleImageCapture = (imageData: string, fileName: string) => {
    setCapturedImage(imageData);
    
    toast({
      title: "Görüntü Yakalandı",
      description: `${fileName} dosyası başarıyla yakalandı.`,
    });
  };

  // Bildirim izni iste
  const requestNotificationPermission = async () => {
    try {
      const result = await notificationService.requestPermission();
      setNotificationPermission(result);
      
      if (result) {
        toast({
          title: "Bildirim İzni Verildi",
          description: "Artık bildirimler alabilirsiniz.",
        });
      } else {
        toast({
          title: "Bildirim İzni Reddedildi",
          description: "Bildirimleri almak için izin vermeniz gerekiyor.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Bildirim izni hatası:', error);
      toast({
        title: "Bildirim İzni Hatası",
        description: "İzin işlemi sırasında bir hata oluştu.",
        variant: "destructive",
      });
    }
  };

  // Dosya kaydedildiğinde
  const handleFileSaved = (result: { uri: string; path: string; name: string }) => {
    setSavedFile(result);
    
    toast({
      title: "Dosya Kaydedildi",
      description: `${result.name} dosyası başarıyla kaydedildi.`,
    });
  };

  // Ses kaydını başlat
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      
      setAudioChunks([]);
      recorder.start();
      setIsRecording(true);
      setMediaRecorder(recorder);
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setAudioChunks(prev => [...prev, event.data]);
        }
      };
      
      toast({
        title: "Kayıt Başladı",
        description: "Ses kaydı başlatıldı. Konuşmaya başlayabilirsiniz.",
      });
    } catch (error) {
      toast({
        title: "Mikrofon Hatası",
        description: "Mikrofonunuza erişilemedi. Lütfen izin verin.",
        variant: "destructive",
      });
    }
  };

  // Ses kaydını durdur
  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        const timestamp = new Date().toLocaleString('tr-TR');
        const audioId = Date.now().toString();
        
        const newAudio = {
          id: audioId,
          name: `Ses Notu - ${timestamp}`,
          url: audioUrl,
          blob: audioBlob
        };
        
        setRecordedAudios(prev => [...prev, newAudio]);
        
        // Backend'e gönder
        try {
          const formData = new FormData();
          formData.append('audio', audioBlob, `note_${audioId}.webm`);
          
          const response = await fetch('/api/upload-audio', {
            method: 'POST',
            body: formData,
          });
          
          if (response.ok) {
            toast({
              title: "Ses Kaydedildi",
              description: "Ses notunuz başarıyla kaydedildi.",
            });
          } else {
            throw new Error('Upload failed');
          }
        } catch (error) {
          toast({
            title: "Yükleme Hatası",
            description: "Ses dosyası sunucuya yüklenirken bir hata oluştu.",
            variant: "destructive",
          });
        }
        
        // Stream'i durdur
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
      };
    }
  };

  // Ses çalma/durdurma
  const toggleAudioPlayback = (audioUrl: string) => {
    if (currentAudio) {
      currentAudio.pause();
      setCurrentAudio(null);
    } else {
      const audio = new Audio(audioUrl);
      audio.play();
      setCurrentAudio(audio);
      
      audio.onended = () => {
        setCurrentAudio(null);
      };
    }
  };

  // İmza çizme fonksiyonları
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!signatureCanvas) return;
    setIsDrawing(true);
    const ctx = signatureCanvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !signatureCanvas) return;
    const ctx = signatureCanvas.getContext('2d');
    if (ctx) {
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#000';
      ctx.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    if (!signatureCanvas) return;
    const ctx = signatureCanvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, signatureCanvas.width, signatureCanvas.height);
    }
  };

  const saveSignature = async () => {
    if (!signatureCanvas) return;
    
    signatureCanvas.toBlob(async (blob) => {
      if (!blob) return;
      
      const timestamp = new Date().toLocaleString('tr-TR');
      const signatureId = Date.now().toString();
      const signatureUrl = URL.createObjectURL(blob);
      
      const newSignature = {
        id: signatureId,
        name: `İmza - ${timestamp}`,
        url: signatureUrl
      };
      
      setSavedSignatures(prev => [...prev, newSignature]);
      
      // Backend'e gönder
      try {
        const formData = new FormData();
        formData.append('signature', blob, `signature_${signatureId}.png`);
        
        const response = await fetch('/api/upload-signature', {
          method: 'POST',
          body: formData,
        });
        
        if (response.ok) {
          toast({
            title: "İmza Kaydedildi",
            description: "İmzanız başarıyla kaydedildi.",
          });
          clearSignature();
        } else {
          throw new Error('Upload failed');
        }
      } catch (error) {
        toast({
          title: "Yükleme Hatası",
          description: "İmza yüklenirken bir hata oluştu.",
          variant: "destructive",
        });
      }
    }, 'image/png');
  };

  // Tarama fonksiyonu
  const handleScanUpload = async (file: File) => {
    try {
      const formData = new FormData();
      formData.append('scan', file);
      
      const response = await fetch('/api/upload-scan', {
        method: 'POST',
        body: formData,
      });
      
      if (response.ok) {
        const result = await response.json();
        const scannedId = Date.now().toString();
        const newScan = {
          id: scannedId,
          name: `Tarama - ${file.name}`,
          url: result.pdfUrl || `/api/scan/${result.filename}`
        };
        
        setScannedImages(prev => [...prev, newScan]);
        
        toast({
          title: "Tarama Tamamlandı",
          description: "Görsel PDF olarak kaydedildi.",
        });
      } else {
        throw new Error('Scan upload failed');
      }
    } catch (error) {
      toast({
        title: "Tarama Hatası",
        description: "Görsel işlenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">Telefon Özellikleri</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">Nova PDF Mobil</h1>
        )}
      </div>
      
      {/* Genel açıklama */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Nova PDF Görüntüleyici</CardTitle>
          <CardDescription>
            Gelişmiş PDF görüntüleme, dosya yönetimi ve mobil özellikler. 
            PDF dosyalarınızı yükleyin, görüntüleyin ve yönetin.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertTitle>Bilgi</AlertTitle>
            <AlertDescription>
              Flask tabanlı PDF görüntüleyici mimarisinden esinlenmiş, 
              modern React bileşenleri ile geliştirilmiş PDF yönetim sistemi.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
      
      {/* Ana sekme görünümü - Nova PDF Viewer tarzı */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="viewer" className="flex items-center gap-1">
            <Eye className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">Viewer</span>
          </TabsTrigger>
          <TabsTrigger value="upload" className="flex items-center gap-1">
            <Upload className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">Yükle</span>
          </TabsTrigger>
          <TabsTrigger value="audio" className="flex items-center gap-1">
            <Mic className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">Ses</span>
          </TabsTrigger>
          <TabsTrigger value="scan" className="flex items-center gap-1">
            <Scan className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">Tarama</span>
          </TabsTrigger>
          <TabsTrigger value="signature" className="flex items-center gap-1">
            <PenTool className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">İmza</span>
          </TabsTrigger>
          <TabsTrigger value="camera" className="flex items-center gap-1">
            <Camera className="h-3 w-3" />
            <span className="hidden sm:inline text-xs">Kamera</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Nova PDF Viewer sekmesi */}
        <TabsContent value="viewer">
          <Card>
            <CardHeader>
              <CardTitle>Nova PDF Viewer</CardTitle>
              <CardDescription>
                Gelişmiş PDF görüntüleyici ile belgelerinizi inceleyin, yakınlaştırın ve yazdırın.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedPdfUrl ? (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">PDF Görüntüleniyor</h3>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedPdfUrl(null)}
                    >
                      Kapat
                    </Button>
                  </div>
                  
                  {/* Nova PDF Viewer - Flask iframe yaklaşımından esinlenmiş */}
                  <div className="border rounded-lg overflow-hidden bg-gray-50">
                    <div className="w-full h-[600px]">
                      <TooltipProvider>
                        <EnhancedPDFViewer
                          pdfUrl={selectedPdfUrl}
                          currentPage={1}
                          totalPages={1}
                          onPageChange={() => {}}
                          className="w-full h-full"
                        />
                      </TooltipProvider>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Eye className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">PDF Seçin</h3>
                  <p className="text-gray-500 mb-4">
                    Görüntülemek için bir PDF dosyası yükleyin veya mevcut dosyalardan birini seçin.
                  </p>
                  {uploadedPdfs.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-medium text-left">Yüklenmiş PDF'ler:</h4>
                      {uploadedPdfs.map((pdf) => (
                        <Button
                          key={pdf.id}
                          variant="outline"
                          className="w-full justify-start"
                          onClick={() => setSelectedPdfUrl(pdf.url)}
                        >
                          <FileText className="w-4 h-4 mr-2" />
                          {pdf.name}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* PDF Yükleme sekmesi */}
        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>PDF Yükleme</CardTitle>
              <CardDescription>
                Cihazınızdan PDF dosyası yükleyin ve görüntüleyicide açın.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                <p className="text-gray-600 mb-2">PDF dosyası sürükleyin veya seçin</p>
                <input
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  id="pdf-upload"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file && file.type === 'application/pdf') {
                      try {
                        const formData = new FormData();
                        formData.append('pdf', file);
                        
                        const response = await fetch('/api/pdf/upload', {
                          method: 'POST',
                          body: formData,
                        });
                        
                        if (response.ok) {
                          const result = await response.json();
                          const newPdf = {
                            id: result.id,
                            name: file.name,
                            url: `/api/pdf/${result.id}/file`
                          };
                          
                          setUploadedPdfs(prev => [...prev, newPdf]);
                          setSelectedPdfUrl(newPdf.url);
                          setActiveTab('viewer');
                          
                          toast({
                            title: "PDF Yüklendi",
                            description: `${file.name} başarıyla yüklendi.`,
                          });
                        } else {
                          throw new Error('Upload failed');
                        }
                      } catch (error) {
                        toast({
                          title: "Yükleme Hatası",
                          description: "PDF dosyası yüklenirken bir hata oluştu.",
                          variant: "destructive",
                        });
                      }
                    }
                  }}
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById('pdf-upload')?.click()}
                >
                  Dosya Seç
                </Button>
              </div>
              
              {uploadedPdfs.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium">Yüklenmiş Dosyalar:</h4>
                  <div className="grid gap-2">
                    {uploadedPdfs.map((pdf) => (
                      <div key={pdf.id} className="flex items-center justify-between p-2 border rounded">
                        <span className="flex items-center">
                          <FileText className="w-4 h-4 mr-2" />
                          {pdf.name}
                        </span>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedPdfUrl(pdf.url);
                              setActiveTab('viewer');
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = pdf.url;
                              link.download = pdf.name;
                              link.click();
                            }}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sesli Not sekmesi */}
        <TabsContent value="audio">
          <Card>
            <CardHeader>
              <CardTitle>Sesli Not Ekleme</CardTitle>
              <CardDescription>
                Mikrofonla ses kaydı yapın ve PDF'e eklenebilir sesli notlar oluşturun.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Kayıt Kontrolleri */}
              <div className="flex justify-center">
                <div className="flex gap-4">
                  {!isRecording ? (
                    <Button
                      onClick={startRecording}
                      className="flex items-center gap-2"
                      size="lg"
                    >
                      <Mic className="w-5 h-5" />
                      Kaydı Başlat
                    </Button>
                  ) : (
                    <Button
                      onClick={stopRecording}
                      variant="destructive"
                      className="flex items-center gap-2"
                      size="lg"
                    >
                      <Square className="w-5 h-5" />
                      Kaydı Durdur
                    </Button>
                  )}
                </div>
              </div>

              {/* Kayıt durumu göstergesi */}
              {isRecording && (
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 text-red-600">
                    <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                    <span className="font-medium">Kayıt yapılıyor...</span>
                  </div>
                </div>
              )}

              {/* Kaydedilmiş Ses Notları */}
              {recordedAudios.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Kaydedilmiş Ses Notları:</h4>
                  <div className="grid gap-3">
                    {recordedAudios.map((audio) => (
                      <div key={audio.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Mic className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="font-medium text-sm">{audio.name}</p>
                            <p className="text-xs text-gray-500">WebM Audio</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toggleAudioPlayback(audio.url)}
                          >
                            {currentAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = audio.url;
                              link.download = `${audio.name}.webm`;
                              link.click();
                            }}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Bilgi mesajı */}
              <Alert>
                <Mic className="h-4 w-4" />
                <AlertTitle>Sesli Not Bilgisi</AlertTitle>
                <AlertDescription>
                  Ses kayıtları WebM formatında kaydedilir ve sunucuya yüklenir. 
                  Bu notlar PDF belgelerinizle ilişkilendirilebilir.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tarama sekmesi */}
        <TabsContent value="scan">
          <Card>
            <CardHeader>
              <CardTitle>Belge Tarayıcı</CardTitle>
              <CardDescription>
                Kamera ile belge tarayın ve otomatik olarak PDF'e dönüştürün.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Tarama yükleme alanı */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  id="scan-input"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleScanUpload(file);
                  }}
                />
                <label htmlFor="scan-input" className="cursor-pointer">
                  <Scan className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-lg font-medium text-gray-700 mb-2">
                    Belge Tarayın
                  </p>
                  <p className="text-sm text-gray-500">
                    Kamera ile belge fotoğrafı çekin veya galeriden seçin
                  </p>
                  <Button className="mt-4">
                    <Camera className="w-4 h-4 mr-2" />
                    Tarama Başlat
                  </Button>
                </label>
              </div>

              {/* Taranan belgeler */}
              {scannedImages.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Taranan Belgeler:</h4>
                  <div className="grid gap-3">
                    {scannedImages.map((scan) => (
                      <div key={scan.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <FileText className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="font-medium text-sm">{scan.name}</p>
                            <p className="text-xs text-gray-500">PDF Belgesi</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(scan.url, '_blank')}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = scan.url;
                              link.download = `${scan.name}.pdf`;
                              link.click();
                            }}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Alert>
                <Scan className="h-4 w-4" />
                <AlertTitle>Tarama Bilgisi</AlertTitle>
                <AlertDescription>
                  Kamera ile çekilen belgeler otomatik olarak PDF formatına dönüştürülür ve sunucuda saklanır.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* İmza sekmesi */}
        <TabsContent value="signature">
          <Card>
            <CardHeader>
              <CardTitle>Dijital İmza</CardTitle>
              <CardDescription>
                Parmağınızla veya mouse ile imza çizin ve PDF belgelerinize ekleyin.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* İmza çizim alanı */}
              <div className="border-2 border-gray-300 rounded-lg p-4">
                <canvas
                  ref={(canvas) => setSignatureCanvas(canvas)}
                  width={400}
                  height={200}
                  className="w-full h-48 border border-gray-200 rounded cursor-crosshair bg-white"
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                />
              </div>

              {/* İmza kontrolleri */}
              <div className="flex justify-center gap-4">
                <Button
                  onClick={clearSignature}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  Temizle
                </Button>
                <Button
                  onClick={saveSignature}
                  className="flex items-center gap-2"
                >
                  <PenTool className="w-4 h-4" />
                  İmzayı Kaydet
                </Button>
              </div>

              {/* Kaydedilen imzalar */}
              {savedSignatures.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Kaydedilen İmzalar:</h4>
                  <div className="grid gap-3">
                    {savedSignatures.map((signature) => (
                      <div key={signature.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <PenTool className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="font-medium text-sm">{signature.name}</p>
                            <p className="text-xs text-gray-500">PNG İmza</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(signature.url, '_blank')}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = signature.url;
                              link.download = `${signature.name}.png`;
                              link.click();
                            }}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Alert>
                <PenTool className="h-4 w-4" />
                <AlertTitle>İmza Bilgisi</AlertTitle>
                <AlertDescription>
                  Çizilen imzalar PNG formatında kaydedilir ve PDF belgelerinize eklenebilir.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Kamera sekmesi */}
        <TabsContent value="camera">
          <Card>
            <CardHeader>
              <CardTitle>Kamera Erişimi</CardTitle>
              <CardDescription>
                Capacitor Camera eklentisi ile cihaz kamerasını kullanabilir, fotoğraf çekebilir veya galeriden görüntü seçebilirsiniz.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CameraCapture 
                onImageCapture={handleImageCapture}
                onError={(error) => {
                  toast({
                    title: "Kamera Hatası",
                    description: error.message,
                    variant: "destructive",
                  });
                }}
              />
              
              {capturedImage && (
                <div className="mt-4">
                  <h3 className="text-lg font-medium mb-2">Yakalanan Görüntü</h3>
                  <div className="border rounded-md overflow-hidden">
                    <img 
                      src={capturedImage} 
                      alt="Yakalanan Görüntü" 
                      className="w-full max-h-60 object-contain"
                    />
                  </div>
                  <div className="flex justify-between mt-2">
                    <Button
                      variant="outline"
                      onClick={() => setCapturedImage(null)}
                    >
                      Temizle
                    </Button>
                    <Button
                      onClick={() => {
                        // Burada görüntüyü kaydet veya işle
                        toast({
                          title: "PDF'e Dönüştürüldü",
                          description: "Görüntü PDF belgesine dönüştürüldü.",
                        });
                      }}
                    >
                      PDF'e Dönüştür
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Dosya Sistemi sekmesi */}
        <TabsContent value="filesystem">
          <Card>
            <CardHeader>
              <CardTitle>Dosya Sistemi Erişimi</CardTitle>
              <CardDescription>
                Capacitor Filesystem eklentisi ile cihazın dosya sistemine erişebilir, dosya okuyabilir, yazabilir ve yönetebilirsiniz.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FileSystemAccess 
                onFileSelect={(fileData) => {
                  toast({
                    title: "Dosya Seçildi",
                    description: `${fileData.name} dosyası başarıyla seçildi.`,
                  });
                }}
                onSaveFile={handleFileSaved}
                allowedExtensions={['pdf', 'jpg', 'jpeg', 'png']}
              />
              
              {savedFile && (
                <Alert className="mt-4">
                  <FileText className="h-4 w-4" />
                  <AlertTitle>Dosya Kaydedildi</AlertTitle>
                  <AlertDescription>
                    <p><strong>Dosya Adı:</strong> {savedFile.name}</p>
                    <p><strong>Konum:</strong> {savedFile.path}</p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Bildirimler sekmesi */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Bildirim Desteği</CardTitle>
              <CardDescription>
                Capacitor Push Notifications eklentisi ile push bildirimleri alabilir ve yönetebilirsiniz.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-md mb-4">
                <h3 className="text-sm font-medium mb-2">Bildirim İzni Durumu</h3>
                <div className="flex items-center">
                  {notificationPermission === null ? (
                    <p className="text-sm text-muted-foreground">İzin durumu kontrol ediliyor...</p>
                  ) : notificationPermission ? (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                      <p className="text-sm">Bildirim gönderme izni verildi</p>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                      <p className="text-sm">Bildirim izni yok</p>
                    </div>
                  )}
                </div>
              </div>
              
              <Button
                onClick={requestNotificationPermission}
                disabled={notificationPermission === true}
                className="w-full"
              >
                {notificationPermission ? "İzin Verildi" : "Bildirim İzni İste"}
              </Button>
              
              {notificationPermission && (
                <Button
                  variant="outline"
                  onClick={async () => {
                    // Örnek bir lokal bildirim gönder
                    await PushNotifications.removeAllDeliveredNotifications();
                    
                    toast({
                      title: "Test Bildirimi Gönderildi",
                      description: "Örnek bir bildirim görüntülenecek.",
                    });
                    
                    // Normalde sunucudan gelen push bildirimleri için kullanılır
                    const notification = {
                      title: "Nova PDF Editör",
                      body: "Bu bir test bildirimidir. " + new Date().toLocaleTimeString(),
                      id: Date.now().toString(),
                    };
                    
                    setLastNotification(notification as PushNotificationSchema);
                  }}
                  className="w-full mt-2"
                >
                  Test Bildirimi Gönder
                </Button>
              )}
              
              {lastNotification && (
                <Alert className="mt-4">
                  <Bell className="h-4 w-4" />
                  <AlertTitle>Son Alınan Bildirim</AlertTitle>
                  <AlertDescription>
                    <p><strong>Başlık:</strong> {lastNotification.title}</p>
                    <p><strong>İçerik:</strong> {lastNotification.body}</p>
                    <p><strong>Zaman:</strong> {new Date().toLocaleTimeString()}</p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="Native Özellikler"
          showSave={false}
          showDownload={false}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default NativeCapabilitiesPage;