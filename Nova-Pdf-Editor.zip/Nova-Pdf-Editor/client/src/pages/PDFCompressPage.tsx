import React, { useState, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, Upload, FileDown, FileText, Download, FileMinus2, Check } from 'lucide-react';
import { useLocation } from "wouter";
import { useIsMobile } from "@/hooks/use-mobile";
import BackButton from '@/components/ui/back-button';
import MobileActionBar from '@/components/MobileActionBar';
import { apiRequest } from "@/lib/queryClient";

type CompressionLevel = "light" | "medium" | "high";

interface CompressionResult {
  originalSize: number;
  compressedSize: number;
  savedSize: number;
  percentSaved: number;
  fileName: string;
  compressionLevel: CompressionLevel;
  qualityFactor: number;
  compressedPdf: string; // base64
}

const PDFCompressPage: React.FC = () => {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressionLevel, setCompressionLevel] = useState<CompressionLevel>("medium");
  const [compressionResult, setCompressionResult] = useState<CompressionResult | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  // PDF dosyasını yükle
  const handleFileUpload = useCallback((file: File) => {
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
      setCompressionResult(null);
      
      toast({
        title: "PDF Seçildi",
        description: `${file.name} dosyası yüklendi.`,
      });
    } else {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında bir dosya yükleyin.",
        variant: "destructive",
      });
    }
  }, [toast]);

  // Dosya seçici dialog'u göster
  const handleSelectFile = useCallback(() => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.pdf';
    fileInput.onchange = (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (files && files.length > 0) {
        handleFileUpload(files[0]);
      }
    };
    fileInput.click();
  }, [handleFileUpload]);

  // PDF'i sıkıştır
  const compressPDF = useCallback(async () => {
    if (!pdfFile) return;

    setIsCompressing(true);
    
    // Sıkıştırma seviyesine göre tahmini süreleri belirleme
    const estimatedTimes = {
      light: 3, // 3 saniye
      medium: 5, // 5 saniye
      high: 8 // 8 saniye
    };
    
    // Bu sıkıştırma seviyesi için tahmini süre
    const estimatedTime = estimatedTimes[compressionLevel as keyof typeof estimatedTimes];
    
    // İlerleme gösterimi başlangıç değerini sıfırla
    setProgressPercent(0);
    
    try {
      // İlerleme simülasyonu başlat
      let counter = 0;
      const totalSteps = 100;
      const interval = Math.floor((estimatedTime * 1000) / totalSteps);
      
      // İlerleme simülasyonu için interval
      const progressInterval = setInterval(() => {
        counter += 1;
        
        // Eğer %90'a ulaştıysak, sunucudan yanıt bekliyoruz demektir
        if (counter <= 90) {
          setProgressPercent(counter);
        }
        
        // İşlem tamamlandığında interval'i temizle
        if (counter >= totalSteps) {
          clearInterval(progressInterval);
        }
      }, interval);
      
      // FormData objesi oluştur
      const formData = new FormData();
      
      // PDF dosyasını ekle - alan adını 'pdf' olarak belirt
      formData.append('pdf', pdfFile);
      formData.append('compressionLevel', compressionLevel);
      
      // Debug için
      console.log("FormData içeriği:", formData.get('pdf'), "Compression Level:", formData.get('compressionLevel'));
      
      // Sıkıştırma seviyesine göre ilerleme mesajını belirle
      let progressMessage = "";
      switch (compressionLevel) {
        case "light":
          progressMessage = "PDF metaverileri optimize ediliyor ve gereksiz veriler kaldırılıyor...";
          break;
        case "medium":
          progressMessage = "Görüntü kalitesi düşürülüyor ve metin verilerinin verimliliği artırılıyor...";
          break;
        case "high":
          progressMessage = "Maksimum sıkıştırma için dosya yapısı yeniden düzenleniyor ve içerik optimize ediliyor...";
          break;
        default:
          progressMessage = "PDF sıkıştırılıyor...";
      }
      
      // Toast bildirimi ile kullanıcıyı bilgilendir
      toast({
        title: "Sıkıştırma İşlemi Sürüyor",
        description: `${progressMessage} Yaklaşık ${estimatedTime} saniye sürecek.`,
        duration: estimatedTime * 1000,
      });
      
      // Fetch API ile direkt istek gönder (apiRequest yerine)
      const response = await fetch('/api/pdf/compress', {
        method: 'POST',
        body: formData,
        // FormData ile headers 'Content-Type' belirtilmemeli
      });
      
      // İlerleme interval'ini temizle
      clearInterval(progressInterval);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Sunucu hatası:", errorText);
        throw new Error(`Sıkıştırma hatası: ${response.status} ${response.statusText}`);
      }
      
      // İlerleme yüzdesini %100 olarak ayarla
      setProgressPercent(100);
      
      const result = await response.json();
      setCompressionResult(result);
      
      toast({
        title: "Sıkıştırma Tamamlandı",
        description: `PDF dosyası %${result.percentSaved} oranında sıkıştırıldı.`,
      });
    } catch (error) {
      console.error("PDF sıkıştırma hatası:", error);
      toast({
        title: "Sıkıştırma Hatası",
        description: "PDF dosyası sıkıştırılırken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsCompressing(false);
    }
  }, [pdfFile, compressionLevel, toast]);

  // Base64 PDF'i indir
  const downloadCompressedPDF = useCallback(() => {
    if (!compressionResult) return;
    
    const byteCharacters = atob(compressionResult.compressedPdf);
    const byteArrays = [];
    
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    
    const blob = new Blob(byteArrays, { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    const originalName = compressionResult.fileName;
    const extension = originalName.substring(originalName.lastIndexOf('.'));
    const baseName = originalName.substring(0, originalName.lastIndexOf('.'));
    
    link.href = url;
    link.download = `${baseName}_compressed${extension}`;
    link.click();
    
    // Temizle
    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 100);
    
    toast({
      title: "İndirme Başlatıldı",
      description: "Sıkıştırılmış PDF indiriliyor.",
    });
  }, [compressionResult, toast]);

  // Yeni bir dosya ile başla
  const resetProcess = useCallback(() => {
    setPdfFile(null);
    setCompressionResult(null);
  }, []);

  // Sıkıştırma seviyesini belirle ve açıklamaları göster
  const getCompressionInfo = useCallback((level: CompressionLevel) => {
    switch (level) {
      case "light":
        return {
          title: "Hafif Sıkıştırma",
          description: "Düşük seviyede sıkıştırma, yüksek görüntü kalitesi",
          expectedReduction: "10-30%",
          quality: "Çok İyi",
          color: "bg-green-500"
        };
      case "medium":
        return {
          title: "Orta Sıkıştırma",
          description: "Dengeli sıkıştırma, iyi görüntü kalitesi",
          expectedReduction: "30-50%",
          quality: "İyi",
          color: "bg-yellow-500"
        };
      case "high":
        return {
          title: "Yüksek Sıkıştırma",
          description: "Güçlü sıkıştırma, düşük görüntü kalitesi",
          expectedReduction: "50-70%",
          quality: "Orta",
          color: "bg-red-500"
        };
    }
  }, []);

  // Dosya boyutunu formatlı göster
  const formatFileSize = useCallback((sizeInKB: number): string => {
    if (sizeInKB < 1024) {
      return `${sizeInKB} KB`;
    } else {
      return `${(sizeInKB / 1024).toFixed(2)} MB`;
    }
  }, []);

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">PDF Sıkıştırma</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">PDF Sıkıştırma</h1>
        )}
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>PDF Dosyası Boyutunu Küçültme</CardTitle>
          <CardDescription>
            PDF dosyalarınızın boyutunu üç farklı sıkıştırma seviyesiyle küçültün. 
            Dosyalarınızı e-posta ile göndermek veya depolama alanından tasarruf etmek için idealdir.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {!pdfFile ? (
            <div className="flex flex-col items-center justify-center p-10 border-2 border-dashed rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50">
              <FileText className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500 mb-4 text-center">
                Sıkıştırmak istediğiniz PDF dosyasını yükleyin
              </p>
              <Button onClick={handleSelectFile}>
                <Upload className="h-4 w-4 mr-2" />
                PDF Seç
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">{pdfFile.name}</h3>
                  <p className="text-sm text-gray-500">
                    {formatFileSize(Math.round(pdfFile.size / 1024))}
                  </p>
                </div>
                <Button
                  variant="outline" 
                  size="sm"
                  onClick={resetProcess}
                >
                  Değiştir
                </Button>
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="font-medium mb-3">Sıkıştırma Seviyesi</h3>
                <RadioGroup 
                  value={compressionLevel} 
                  onValueChange={(value: CompressionLevel) => setCompressionLevel(value)}
                  className="space-y-4"
                >
                  {(['light', 'medium', 'high'] as CompressionLevel[]).map((level) => {
                    const info = getCompressionInfo(level);
                    return (
                      <div key={level} className="flex items-start space-x-2 border rounded-md p-3">
                        <RadioGroupItem value={level} id={`compression-${level}`} />
                        <Label htmlFor={`compression-${level}`} className="flex-1">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{info.title}</span>
                            <Badge variant="outline">
                              Beklenen Küçültme: {info.expectedReduction}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            {info.description}
                          </p>
                          <div className="mt-2 flex items-center gap-2">
                            <span className="text-xs">Kalite:</span>
                            <span className={`h-2 w-12 rounded-full ${info.color}`}></span>
                            <span className="text-xs">{info.quality}</span>
                          </div>
                        </Label>
                      </div>
                    );
                  })}
                </RadioGroup>
              </div>
              
              <div className="space-y-4">
                {isCompressing && progressPercent > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span>İşleniyor</span>
                      <span>{progressPercent}%</span>
                    </div>
                    <Progress value={progressPercent} className="h-2" />
                    
                    <div className="text-center text-sm text-gray-500">
                      {progressPercent < 30 && "PDF analiz ediliyor..."}
                      {progressPercent >= 30 && progressPercent < 60 && "Metaveriler optimize ediliyor..."}
                      {progressPercent >= 60 && progressPercent < 90 && "Dosya sıkıştırılıyor..."}
                      {progressPercent >= 90 && "Tamamlanıyor..."}
                    </div>
                  </div>
                )}
                
                <div className="flex justify-center">
                  <Button 
                    disabled={isCompressing} 
                    onClick={compressPDF} 
                    className="w-full sm:w-auto"
                  >
                    {isCompressing ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Sıkıştırılıyor... ({progressPercent}%)
                      </>
                    ) : (
                      <>
                        <FileMinus2 className="h-4 w-4 mr-2" />
                        PDF'i Sıkıştır
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {compressionResult && (
        <Card className="mb-6 border-primary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-500" />
              <CardTitle>Sıkıştırma Tamamlandı</CardTitle>
            </div>
            <CardDescription>
              PDF dosyanız başarıyla sıkıştırıldı. Aşağıdaki sonuçları inceleyebilir ve sıkıştırılmış dosyayı indirebilirsiniz.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* İlerleme çubuğu */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Orijinal: {formatFileSize(compressionResult.originalSize)}</span>
                <span>Sıkıştırılmış: {formatFileSize(compressionResult.compressedSize)}</span>
              </div>
              <Progress value={compressionResult.percentSaved} className="h-2" />
              <div className="text-center font-medium text-primary">
                %{compressionResult.percentSaved} Küçültme ({formatFileSize(compressionResult.savedSize)} tasarruf)
              </div>
            </div>
            
            {/* Sıkıştırma detayları */}
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="border rounded p-3">
                <div className="text-sm text-gray-500">Dosya Adı</div>
                <div className="font-medium truncate">{compressionResult.fileName}</div>
              </div>
              <div className="border rounded p-3">
                <div className="text-sm text-gray-500">Sıkıştırma Seviyesi</div>
                <div className="font-medium">
                  {getCompressionInfo(compressionResult.compressionLevel).title}
                </div>
              </div>
            </div>
            
            {/* Debug bilgileri */}
            <div className="text-xs text-gray-500 mt-2 p-2 bg-gray-100 dark:bg-gray-800 rounded">
              <details>
                <summary className="cursor-pointer font-medium">Teknik Detaylar</summary>
                <div className="mt-2 space-y-1">
                  <p>Orijinal Boyut: {compressionResult.originalSize} KB</p>
                  <p>Sıkıştırılmış Boyut: {compressionResult.compressedSize} KB</p>
                  <p>Tasarruf: {compressionResult.savedSize} KB (%{compressionResult.percentSaved})</p>
                  <p>Sıkıştırma Seviyesi: {compressionResult.compressionLevel}</p>
                  <p>Kalite Faktörü: {compressionResult.qualityFactor}</p>
                </div>
              </details>
            </div>
          </CardContent>
          
          <CardFooter>
            <Button onClick={downloadCompressedPDF} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Sıkıştırılmış PDF'i İndir
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="PDF Sıkıştırma"
          showSave={false}
          showDownload={!!compressionResult}
          onBack={() => setLocation("/mobile")}
          onDownload={compressionResult ? downloadCompressedPDF : undefined}
        />
      )}
    </div>
  );
};

export default PDFCompressPage;