import React, { useState, useCallback, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Download, Save, ChevronUp, ChevronDown, X, Plus, Lock } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import MobileActionBar from '@/components/MobileActionBar';
import BackButton from '@/components/ui/back-button';
import { Progress } from "@/components/ui/progress";
import { useFileConverter } from "@/hooks/use-file-converter";

interface ConversionFile {
  file: File;
  previewUrl?: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

// İzin verilen dosya türleri
const SUPPORTED_IMAGES = [
  'image/jpeg', 
  'image/png', 
  'image/gif', 
  'image/bmp', 
  'image/webp',
  'image/tiff',
  'image/svg+xml'
];

const SUPPORTED_DOCUMENTS = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation', // .pptx
  'text/plain',
  'text/html',
  'text/csv',
  'application/rtf'
];

// Ücretsiz sürüm maksimum dosya sayısı
const FREE_TIER_MAX_FILES = 3;

const ConvertCenterPage: React.FC = () => {
  const [selectedFiles, setSelectedFiles] = useState<ConversionFile[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("images");
  const [isPremiumBlocked, setIsPremiumBlocked] = useState<boolean>(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Dosya dönüştürme hook'unu kullan
  const { 
    isConverting,
    convertFilesToPdf
  } = useFileConverter();

  // Dosya yükleme işleyicisi
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    const files = Array.from(e.target.files);
    
    // Dosya türü kontrolü
    const acceptedFiles = filterFilesByType(files, activeTab);
    
    // Dosya sayısı kontrolü
    if (selectedFiles.length + acceptedFiles.length > FREE_TIER_MAX_FILES) {
      // Premium kontrolü
      const isPremium = false; // Burada premium kontrolü yapılabilir
      
      if (!isPremium) {
        setIsPremiumBlocked(true);
        toast({
          title: "Dosya Sayısı Sınırı",
          description: `Ücretsiz sürümde en fazla ${FREE_TIER_MAX_FILES} dosya ekleyebilirsiniz. Daha fazla dosya eklemek için Pro sürüme geçin.`,
          variant: "destructive",
        });
        
        // Sınıra kadar olan dosyaları ekle
        const remainingSlots = FREE_TIER_MAX_FILES - selectedFiles.length;
        if (remainingSlots > 0) {
          processFiles(acceptedFiles.slice(0, remainingSlots));
        }
        return;
      }
    }
    
    processFiles(acceptedFiles);
  }, [selectedFiles, activeTab, toast]);

  // Dosya türüne göre filtreleme
  const filterFilesByType = (files: File[], type: string): File[] => {
    return files.filter(file => {
      if (type === "images") {
        return SUPPORTED_IMAGES.includes(file.type);
      } else if (type === "documents") {
        return SUPPORTED_DOCUMENTS.includes(file.type);
      }
      return false;
    });
  };

  // Dosyaları işleme
  const processFiles = (files: File[]) => {
    const newFiles: ConversionFile[] = files.map(file => {
      // Görsel dosyalar için önizleme URL'si oluştur
      let previewUrl;
      if (SUPPORTED_IMAGES.includes(file.type)) {
        previewUrl = URL.createObjectURL(file);
      }
      
      return {
        file,
        previewUrl,
        status: 'pending',
        progress: 0
      };
    });
    
    setSelectedFiles(prev => [...prev, ...newFiles]);
    
    toast({
      title: "Dosyalar Eklendi",
      description: `${files.length} dosya başarıyla eklendi.`,
      duration: 3000,
    });

    // Input değerini sıfırla
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Dosya sürükle & bırak işleyicileri
  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files);
      
      // Dosya türü kontrolü
      const acceptedFiles = filterFilesByType(files, activeTab);
      
      if (acceptedFiles.length === 0) {
        toast({
          title: "Desteklenmeyen Dosya Türü",
          description: `Lütfen ${activeTab === "images" ? "resim" : "belge"} formatında dosyalar yükleyin.`,
          variant: "destructive",
        });
        return;
      }
      
      // Dosya sayısı kontrolü
      if (selectedFiles.length + acceptedFiles.length > FREE_TIER_MAX_FILES) {
        // Premium kontrolü
        const isPremium = false; // Burada premium kontrolü yapılabilir
        
        if (!isPremium) {
          setIsPremiumBlocked(true);
          toast({
            title: "Dosya Sayısı Sınırı",
            description: `Ücretsiz sürümde en fazla ${FREE_TIER_MAX_FILES} dosya ekleyebilirsiniz. Daha fazla dosya eklemek için Pro sürüme geçin.`,
            variant: "destructive",
          });
          
          // Sınıra kadar olan dosyaları ekle
          const remainingSlots = FREE_TIER_MAX_FILES - selectedFiles.length;
          if (remainingSlots > 0) {
            processFiles(acceptedFiles.slice(0, remainingSlots));
          }
          return;
        }
      }
      
      processFiles(acceptedFiles);
    }
  }, [selectedFiles, activeTab, toast]);

  // Dosyayı kaldır
  const removeFile = useCallback((index: number) => {
    setSelectedFiles(prev => {
      const newFiles = [...prev];
      
      // Önizleme URL'sini temizle
      if (newFiles[index].previewUrl) {
        URL.revokeObjectURL(newFiles[index].previewUrl);
      }
      
      // Dosyayı kaldır
      newFiles.splice(index, 1);
      return newFiles;
    });
    
    toast({
      title: "Dosya Kaldırıldı",
      description: "Seçilen dosya başarıyla kaldırıldı.",
      duration: 1500,
    });
  }, [toast]);

  // Tüm dosyaları temizle
  const clearAllFiles = useCallback(() => {
    // Önizleme URL'lerini temizle
    selectedFiles.forEach(file => {
      if (file.previewUrl) {
        URL.revokeObjectURL(file.previewUrl);
      }
    });
    
    setSelectedFiles([]);
    setIsPremiumBlocked(false);
    
    toast({
      title: "Dosyalar Temizlendi",
      description: "Tüm dosyalar başarıyla kaldırıldı.",
      duration: 1500,
    });
  }, [selectedFiles, toast]);

  // Dosya sırasını değiştir
  const moveFileUp = useCallback((index: number) => {
    if (index <= 0) return;
    
    setSelectedFiles(prev => {
      const newFiles = [...prev];
      [newFiles[index - 1], newFiles[index]] = [newFiles[index], newFiles[index - 1]];
      return newFiles;
    });
  }, []);

  const moveFileDown = useCallback((index: number) => {
    setSelectedFiles(prev => {
      if (index >= prev.length - 1) return prev;
      
      const newFiles = [...prev];
      [newFiles[index], newFiles[index + 1]] = [newFiles[index + 1], newFiles[index]];
      return newFiles;
    });
  }, []);

  // Dosyaları PDF'e dönüştür
  const handleCreatePDF = useCallback(async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "Hata",
        description: "Lütfen en az bir dosya seçin.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Dosya işleme durumlarını güncelle
      setSelectedFiles(prev => prev.map(file => ({
        ...file,
        status: 'processing',
        progress: 0
      })));
      
      // Birden fazla dosya için birleştirme işlemi yapılacak son PDF buffer'ı
      let finalPdfBuffer: ArrayBuffer | null = null;
      const allPdfIds: number[] = [];
      
      // Her dosya için sunucuya gönderip PDF'e dönüştür
      for (let i = 0; i < selectedFiles.length; i++) {
        const fileData = selectedFiles[i];
        
        // İşleme durumunu güncelle - Başlıyor
        setSelectedFiles(prev => {
          const updated = [...prev];
          updated[i] = {
            ...updated[i],
            progress: 25
          };
          return updated;
        });
        
        // Dosyayı sunucuya gönder ve dönüştür
        const formData = new FormData();
        formData.append('file', fileData.file);
        
        try {
          // İşleme durumunu güncelle - Yükleniyor
          setSelectedFiles(prev => {
            const updated = [...prev];
            updated[i] = {
              ...updated[i],
              progress: 50
            };
            return updated;
          });
          
          // Sunucuya dosyayı gönder ve dönüştür - Python ile dönüştürme işlemi server tarafında yapılıyor
          console.log(`Dosya gönderiliyor: ${fileData.file.name}, Tür: ${fileData.file.type}`);
          
          const response = await fetch('/api/convert-to-pdf', {
            method: 'POST',
            body: formData,
          });
          
          // Hata durumunu detaylandır
          if (!response.ok) {
            let errorText = 'Sunucu hatası';
            try {
              const errorJson = await response.json();
              errorText = errorJson.message || errorJson.error || 'Bilinmeyen hata';
            } catch (e) {
              errorText = await response.text() || `HTTP Hata: ${response.status}`;
            }
            
            console.error('API Yanıt Hatası:', {
              status: response.status,
              statusText: response.statusText,
              errorText
            });
            
            throw new Error(`Dönüştürme hatası: ${errorText}`);
          }
          
          const result = await response.json();
          
          // PDF ID'sini kaydet
          allPdfIds.push(result.id);
          
          // İlk dönüştürülen PDF ise, doğrudan indir
          if (finalPdfBuffer === null) {
            // PDF içeriğini al
            const pdfResponse = await fetch(`/api/pdf/${result.id}/file`);
            if (!pdfResponse.ok) {
              throw new Error(`PDF alınamadı: ${pdfResponse.status}`);
            }
            
            finalPdfBuffer = await pdfResponse.arrayBuffer();
          }
          
          // İşleme durumunu güncelle - Tamamlandı
          setSelectedFiles(prev => {
            const updated = [...prev];
            updated[i] = {
              ...updated[i],
              status: 'completed',
              progress: 100
            };
            return updated;
          });
        } catch (err) {
          // Tip güvenliği için error tipi tanımla
          const fileError = err as Error;
          console.error(`Dosya dönüştürme hatası (${fileData.file.name}):`, fileError);
          
          // İşleme durumunu güncelle - Hata
          setSelectedFiles(prev => {
            const updated = [...prev];
            updated[i] = {
              ...updated[i],
              status: 'error',
              progress: 0
            };
            return updated;
          });
          
          toast({
            title: "Dosya Dönüştürme Hatası",
            description: `${fileData.file.name}: ${fileError.message || 'Bilinmeyen hata'}`,
            variant: "destructive",
          });
        }
      }
      
      // Eğer en az bir dosya başarıyla dönüştürüldüyse, PDF'i indir
      if (finalPdfBuffer) {
        // PDF'i indir
        const blob = new Blob([finalPdfBuffer], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'donusturulen_dosyalar.pdf';
        document.body.appendChild(a);
        a.click();
        
        // Temizlik
        setTimeout(() => {
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }, 100);
        
        toast({
          title: "PDF Oluşturuldu",
          description: `${selectedFiles.filter(f => f.status === 'completed').length} dosyadan oluşan PDF başarıyla oluşturuldu ve indirildi.`,
          duration: 3000,
        });
      } else {
        toast({
          title: "Dönüştürme Başarısız",
          description: "Hiçbir dosya başarıyla dönüştürülemedi.",
          variant: "destructive",
        });
      }
      
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      toast({
        title: "Hata",
        description: "PDF oluşturulurken bir hata oluştu.",
        variant: "destructive",
        duration: 3000,
      });
      
      // Hata durumunu güncelle
      setSelectedFiles(prev => prev.map(file => 
        file.status === 'processing' 
          ? { ...file, status: 'error', progress: 0 } 
          : file
      ));
    } finally {
      setIsProcessing(false);
    }
  }, [selectedFiles, toast, convertFilesToPdf]);

  // Dosya formatı desteği metni
  const getFormatSupportText = () => {
    if (activeTab === "images") {
      return "JPG, PNG, GIF, BMP, WEBP, TIFF, SVG formatları desteklenir";
    } else {
      return "PDF, DOCX, XLSX, PPTX, TXT, HTML, CSV, RTF formatları desteklenir";
    }
  };

  // Dosya boyutu formatlama
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile && (
          <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
        )}
        <h1 className={`text-2xl font-bold ${isMobile ? 'mx-auto' : ''}`}>PDF Dönüştürme Merkezi</h1>
        {!isMobile && <div className="w-[100px]"></div>}
      </div>
      
      <Tabs defaultValue="images" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="images">Görsellerden PDF</TabsTrigger>
          <TabsTrigger value="documents">Belgelerden PDF</TabsTrigger>
        </TabsList>
        
        <TabsContent value="images" className="mt-4">
          <p className="text-sm text-gray-500 mb-4">
            Görsellerinizi tek bir PDF dosyasına dönüştürün. Her görsel bir sayfa olarak eklenecektir.
          </p>
        </TabsContent>
        
        <TabsContent value="documents" className="mt-4">
          <p className="text-sm text-gray-500 mb-4">
            Microsoft Office belgeleri ve diğer dokümanları PDF formatına dönüştürün.
          </p>
        </TabsContent>
      </Tabs>
      
      {isPremiumBlocked && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Dosya Sayısı Sınırı Aşıldı</AlertTitle>
          <AlertDescription>
            Ücretsiz sürümde en fazla {FREE_TIER_MAX_FILES} dosya ekleyebilirsiniz. 
            <Button 
              variant="link" 
              className="p-0 h-auto font-semibold"
              onClick={() => setLocation("/pricing")}
            >
              Pro sürüme geç
            </Button>
          </AlertDescription>
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Card className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                    Dosya Yükle
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {activeTab === "images" ? "Görsellerinizi" : "Belgelerinizi"} PDF'e dönüştürelim
                  </p>
                </div>
              </div>
              
              <div
                className="border-2 border-dashed rounded-lg p-4 transition-colors border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center justify-center py-4 text-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept={activeTab === "images" 
                      ? ".jpg,.jpeg,.png,.gif,.bmp,.webp,.tiff,.svg" 
                      : ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.html,.csv,.rtf"}
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={isProcessing || (selectedFiles.length >= FREE_TIER_MAX_FILES && !isPremiumBlocked)}
                  />
                  
                  <div className="mb-4 text-gray-400">
                    {activeTab === "images" 
                      ? <img src="/icons/image-icon.svg" alt="Görsel" className="h-16 w-16 mx-auto opacity-50" />
                      : <img src="/icons/document-icon.svg" alt="Belge" className="h-16 w-16 mx-auto opacity-50" />
                    }
                  </div>
                  
                  <p className="mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
                    Dosyaları buraya sürükleyin veya tıklayın
                  </p>
                  
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {getFormatSupportText()}
                  </p>
                  
                  <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                    {isPremiumBlocked ? (
                      <span className="flex items-center">
                        <Lock className="h-3 w-3 mr-1" />
                        Ücretsiz sürümde en fazla {FREE_TIER_MAX_FILES} dosya
                      </span>
                    ) : (
                      <span>En fazla {FREE_TIER_MAX_FILES} dosya (ücretsiz sürüm)</span>
                    )}
                  </p>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-4"
                    disabled={isProcessing || (selectedFiles.length >= FREE_TIER_MAX_FILES && !isPremiumBlocked)}
                  >
                    {isProcessing ? 'İşleniyor...' : 'Dosya Seç'}
                  </Button>
                </div>
              </div>
              
              {selectedFiles.length > 0 && (
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Seçilen Dosyalar ({selectedFiles.length}/{FREE_TIER_MAX_FILES})
                    </h4>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAllFiles}
                      disabled={isProcessing}
                      className="text-xs"
                    >
                      Temizle
                    </Button>
                  </div>
                </div>
              )}
              
              {selectedFiles.length > 0 && (
                <Card className="p-4 mt-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">PDF Oluştur</h3>
                    <p className="text-sm text-gray-500">
                      Seçilen {selectedFiles.length} dosyadan PDF oluşturmak için aşağıdaki butona tıklayın.
                    </p>
                    
                    <Button
                      onClick={handleCreatePDF}
                      disabled={isProcessing || selectedFiles.length === 0}
                      className="w-full"
                    >
                      {isProcessing ? 'PDF Oluşturuluyor...' : 'PDF Oluştur ve İndir'}
                    </Button>
                  </div>
                </Card>
              )}
            </div>
          </Card>
        </div>
        
        <div>
          <Card className="p-4">
            <h3 className="text-lg font-semibold mb-4">Dosya Önizleme</h3>
            
            {selectedFiles.length > 0 ? (
              <div className="space-y-4 max-h-[500px] overflow-y-auto">
                {selectedFiles.map((fileData, index) => (
                  <div key={index} className="border rounded-md overflow-hidden relative">
                    {/* Önizleme görüntüsü (varsa) */}
                    {fileData.previewUrl ? (
                      <div className="h-40 overflow-hidden bg-gray-50 dark:bg-gray-800 flex items-center justify-center">
                        <img 
                          src={fileData.previewUrl} 
                          alt={`Önizleme ${index + 1}`} 
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="h-40 flex items-center justify-center bg-gray-50 dark:bg-gray-800 text-center p-4">
                        <div>
                          <p className="text-sm font-medium mb-2">{fileData.file.name}</p>
                          <p className="text-xs text-gray-500">{formatFileSize(fileData.file.size)}</p>
                          <p className="text-xs text-gray-500 mt-1">{fileData.file.type}</p>
                        </div>
                      </div>
                    )}
                    
                    {/* İşlem durumu */}
                    {fileData.status === 'processing' && (
                      <div className="px-4 py-2 bg-gray-100 dark:bg-gray-800 border-t">
                        <p className="text-xs text-gray-500 mb-1">İşleniyor...</p>
                        <Progress value={fileData.progress} className="h-1.5" />
                      </div>
                    )}
                    
                    {/* Dosya bilgisi ve kontroller */}
                    <div className="p-2 bg-gray-50 dark:bg-gray-800 text-xs text-gray-500 flex justify-between items-center border-t">
                      <span className="truncate mr-1">{fileData.file.name}</span>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveFileUp(index)}
                          disabled={index === 0 || isProcessing}
                        >
                          <ChevronUp className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => moveFileDown(index)}
                          disabled={index === selectedFiles.length - 1 || isProcessing}
                        >
                          <ChevronDown className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                          onClick={() => removeFile(index)}
                          disabled={isProcessing}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center border rounded-md bg-gray-50 dark:bg-gray-800">
                <p className="text-gray-500 text-sm">Önizleme için dosya seçin</p>
              </div>
            )}
          </Card>
          
          <div className="mt-4 text-sm text-gray-500">
            <h4 className="font-medium mb-2">Özellikler:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>Dosyalar PDF'e dönüştürülürken kalite korunacaktır.</li>
              <li>PDF'te dosyaların sırası, yükleme sırasına göre belirlenecektir.</li>
              <li>Birden fazla dosyayı tek seferde sürükleyip bırakabilirsiniz.</li>
              <li>Ücretsiz sürümde en fazla {FREE_TIER_MAX_FILES} dosya dönüştürebilirsiniz.</li>
              <li>Daha fazla özellik için <Button variant="link" className="p-0 h-auto" onClick={() => setLocation("/pricing")}>Pro sürüme geçin</Button>.</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="PDF Dönüştürme"
          onSave={selectedFiles.length > 0 ? handleCreatePDF : undefined}
          showSave={selectedFiles.length > 0}
          showDownload={false}
          isSaving={isProcessing}
          onBack={() => setLocation("/")}
        />
      )}
    </div>
  );
};

export default ConvertCenterPage;