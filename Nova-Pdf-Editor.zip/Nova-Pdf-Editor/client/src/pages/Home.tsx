import React, { useState, useCallback, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import FileUpload from "@/components/FileUpload";
import EditingTools from "@/components/EditingTools";
import PDFViewer from "@/components/PDFViewer";
import OCRProcessor from "@/components/OCRProcessor";
import TextSearcher from "@/components/TextSearcher";
import MetadataEditor from "@/components/MetadataEditor";
import NovaLogo from "@/components/NovaLogo";
import HelpModal from "@/components/HelpModal";
import PricingPlans from "@/components/PricingPlans";
import PDFComparer from "@/components/PDFComparer";
import SimplePDFViewer from "@/components/SimplePDFViewer";
import PDFUygulamaGoruntuleleyici from "@/components/PDFUygulamaGoruntuleleyici";
import ObjectPDFViewer from "@/components/ObjectPDFViewer";
import BasicPDFViewer from "@/components/BasicPDFViewer";
import PDFEditingPanel from "@/components/PDFEditingPanel";
import InteractivePDFViewer from "@/components/InteractivePDFViewer";
import TextElementsEditor from "@/components/TextElementsEditor";
import { Button } from "@/components/ui/button";
import { usePDF } from "@/hooks/usePDF";
import { Download, RefreshCw, FileText, LogOut, TextSearch, Search, Info, CreditCard, Edit, FileEdit } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { LanguageSelector } from "@/components/ui/language-selector";
import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Home() {
  const { toast } = useToast();
  const { t } = useTranslation();
  const [_, setLocation] = useLocation();
  const [numPages, setNumPages] = useState(1);
  const [selectedPosition, setSelectedPosition] = useState<{ x: number; y: number } | null>(null);
  const [extractedText, setExtractedText] = useState<string[]>([]);
  
  const {
    currentPdfId,
    pdfMetadata,
    isLoadingMetadata,
    metadataError,
    currentPageIndex,
    zoomLevel,
    pdfBuffer,
    operations,
    pdfTextElements,
    loadingTextElements,
    isUploading,
    isSaving,
    addImageOperation,
    handleFileUpload,
    goToNextPage,
    goToPrevPage,
    zoomIn,
    zoomOut,
    addTextOperation,
    updateTextOperation,
    deleteTextOperation,
    saveChanges,
    downloadPdf,
    resetPdf,
    setPdfBuffer,
    setCurrentPageIndex
  } = usePDF();

  const handleDocumentLoadSuccess = useCallback((numPages: number) => {
    setNumPages(numPages);
  }, []);

  const handleAddTextAtPosition = useCallback((x: number, y: number) => {
    setSelectedPosition({ x, y });
  }, []);

  const handleAddText = useCallback((text: string) => {
    if (!selectedPosition) {
      toast({
        title: "Konum seçilmedi",
        description: "Lütfen önce metni eklemek istediğiniz yere tıklayın.",
        variant: "destructive",
      });
      return;
    }

    // Metin ekleme operasyonu - bu zaten PDF içeriğine ekleme yapar
    addTextOperation(
      text, 
      currentPageIndex + 1, 
      selectedPosition
    );

    setSelectedPosition(null);
    
    toast({
      title: "Metin eklendi",
      description: "Metin başarıyla eklendi. (Not: PDF.js versiyon uyumsuzluğu nedeniyle sadece görsel ekleme yapılabilir.)",
    });
  }, [addTextOperation, currentPageIndex, selectedPosition, toast]);
  
  // Görüntü ekleme işleyicisi
  const handleAddImage = useCallback((imageFile: File) => {
    if (!selectedPosition) {
      toast({
        title: "Konum seçilmedi",
        description: "Lütfen önce görüntüyü eklemek istediğiniz yere tıklayın.",
        variant: "destructive",
      });
      return;
    }
    
    // Görüntü ekleme işlemini addImageOperation kullanarak gerçekleştir
    addImageOperation(
      imageFile,
      currentPageIndex + 1,
      selectedPosition
    );
    
    setSelectedPosition(null);
    
    toast({
      title: "Görüntü ekleniyor",
      description: "Görüntü PDF'e ekleniyor, lütfen işlem tamamlanana kadar bekleyin.",
    });
  }, [addImageOperation, currentPageIndex, selectedPosition, toast]);

  const handleOCRComplete = useCallback((result: string[]) => {
    setExtractedText(result);
  }, []);

  return (
    <>
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <NovaLogo size="sm" />
            <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">Nova PDF Editor</h1>
          </div>
          <div className="flex items-center space-x-4">
            <LanguageSelector />
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLocation("/mobile")}
              className="text-gray-600 hover:text-primary dark:text-gray-300"
            >
              Mobil Görünüm
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/auth")}
              title={t("login")}
              className="text-gray-600 hover:text-primary dark:text-gray-300"
            >
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">{t("login")}</span>
            </Button>
            <HelpModal />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Panel: Controls */}
          <div className="lg:col-span-1">
            <FileUpload 
              onFileUpload={handleFileUpload}
              isUploading={isUploading}
              fileData={pdfMetadata ? {
                name: pdfMetadata.originalFilename || "belge.pdf",
                size: pdfMetadata.size || 0
              } : null}
              onReset={resetPdf}
            />
            
            {currentPdfId && (
              <>
                <Tabs defaultValue="edit" className="mt-6">
                  <TabsList className="w-full mb-4">
                    <TabsTrigger value="edit" className="flex-1">Düzenleme</TabsTrigger>
                    <TabsTrigger value="text_edit" className="flex-1">
                      <Edit className="h-4 w-4 mr-2" />
                      Yazı Düzenle
                    </TabsTrigger>
                    <TabsTrigger value="ocr" className="flex-1">
                      <TextSearch className="h-4 w-4 mr-2" />
                      OCR
                    </TabsTrigger>
                    <TabsTrigger value="search" className="flex-1">
                      <Search className="h-4 w-4 mr-2" />
                      Metin Ara
                    </TabsTrigger>
                    <TabsTrigger value="metadata" className="flex-1">
                      <Info className="h-4 w-4 mr-2" />
                      Metaveri
                    </TabsTrigger>
                    <TabsTrigger value="compare" className="flex-1">
                      <FileText className="h-4 w-4 mr-2" />
                      Karşılaştır
                    </TabsTrigger>
                    <TabsTrigger value="pricing" className="flex-1">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Paketler
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="edit">
                    <EditingTools 
                      onAddText={handleAddText}
                      onAddImage={handleAddImage}
                      currentPage={currentPageIndex + 1}
                      totalPages={numPages}
                      onPrevPage={goToPrevPage}
                      onNextPage={goToNextPage}
                    />
                    
                    <div className="space-y-3 mt-4">
                      <Button 
                        className="w-full flex items-center justify-center"
                        onClick={downloadPdf}
                        disabled={isSaving || isUploading}
                      >
                        <Download className="h-5 w-5 mr-2" />
                        Düzenlenmiş PDF'i İndir
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center justify-center"
                        onClick={resetPdf}
                        disabled={isSaving || isUploading}
                      >
                        <RefreshCw className="h-5 w-5 mr-2" />
                        Sıfırla
                      </Button>
                      
                      <Button 
                        variant="secondary" 
                        className="w-full flex items-center justify-center"
                        onClick={() => setLocation("/pdf-edit")}
                      >
                        <FileEdit className="h-5 w-5 mr-2" />
                        Gelişmiş Metin Düzenleyiciye Git
                      </Button>
                    </div>
                    
                    {selectedPosition && (
                      <Alert className="mt-4">
                        <AlertDescription>
                          Bir konum seçildi. Şimdi metin veya görüntü ekleyebilirsiniz.
                        </AlertDescription>
                      </Alert>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="text_edit">
                    <div className="mb-4">
                      <h3 className="text-lg font-medium mb-2">PDF Metin Düzenleme</h3>
                      <p className="text-sm text-muted-foreground">
                        PDF içerisindeki metinleri düzenleyebilir veya silebilirsiniz. İşlemleriniz sonucunda PDF yeniden oluşturulur.
                      </p>
                    </div>
                    
                    <div className="flex flex-col space-y-4">
                      <TextElementsEditor 
                        textElements={pdfTextElements}
                        isLoading={loadingTextElements}
                        onUpdateText={updateTextOperation}
                        onDeleteText={deleteTextOperation}
                      />
                      
                      <div className="space-y-3 mt-4">
                        <Button 
                          className="w-full flex items-center justify-center"
                          onClick={downloadPdf}
                          disabled={isSaving || isUploading}
                        >
                          <Download className="h-5 w-5 mr-2" />
                          Düzenlenmiş PDF'i İndir
                        </Button>
                        
                        <Button 
                          variant="secondary" 
                          className="w-full flex items-center justify-center"
                          onClick={() => setLocation("/pdf-edit")}
                        >
                          <FileEdit className="h-5 w-5 mr-2" />
                          Gelişmiş Metin Düzenleyiciye Git
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="ocr">
                    <OCRProcessor 
                      pdfBuffer={pdfBuffer || undefined}
                      pdfName={pdfMetadata?.originalFilename || 'belge.pdf'}
                      onOCRComplete={handleOCRComplete}
                    />
                  </TabsContent>
                  
                  <TabsContent value="search">
                    <TextSearcher
                      documentText={extractedText}
                      isLoading={false}
                      currentPage={currentPageIndex + 1}
                      totalPages={numPages}
                      onNavigateToPage={(page) => {
                        if (page > 0 && page <= numPages) {
                          setCurrentPageIndex(page - 1);
                        }
                      }}
                    />
                    
                    {extractedText.length === 0 && (
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-100 dark:border-yellow-900 p-4 rounded-md mt-3">
                        <p className="text-sm text-yellow-800 dark:text-yellow-400">
                          Metin içinde arama yapmak için önce OCR işlemini çalıştırın. OCR işlemi, PDF'teki metinleri otomatik olarak tanıyarak arama yapmanızı sağlar.
                        </p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="metadata">
                    <MetadataEditor
                      pdfBuffer={pdfBuffer || undefined}
                      pdfId={currentPdfId || undefined}
                      pdfName={pdfMetadata?.originalFilename || 'belge.pdf'}
                      onMetadataUpdated={(updatedBuffer) => {
                        // Güncellenmiş PDF buffer'ını state'e set ediyoruz
                        if (updatedBuffer) {
                          setPdfBuffer(updatedBuffer);
                        }
                      }}
                    />
                  </TabsContent>
                  
                  <TabsContent value="compare">
                    <div className="mb-4">
                      <h3 className="text-lg font-medium mb-2">PDF Karşılaştırma</h3>
                      <p className="text-sm text-muted-foreground">
                        İki PDF dosyasını karşılaştırarak aralarındaki farkları görebilirsiniz.
                      </p>
                    </div>
                    <div>
                      <PDFComparer 
                        firstPdfBuffer={pdfBuffer || undefined}
                      />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="pricing">
                    <PricingPlans />
                  </TabsContent>
                </Tabs>
              </>
            )}
          </div>
          
          {/* Right Panel: PDF Preview */}
          <div className="lg:col-span-2">
            {!currentPdfId ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-8 flex flex-col items-center justify-center h-96">
                <NovaLogo size="lg" className="mb-4" />
                <h3 className="text-lg font-medium text-gray-700 dark:text-gray-200 mb-2">Nova PDF Editor</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 text-center max-w-md">
                  PDF dosyanızı yükleyin ve düzenlemeye başlayın. Metinleri değiştirebilir, OCR ile metin çıkarabilir, metaveri düzenleyebilir ve daha fazlasını yapabilirsiniz.
                </p>
              </div>
            ) : (
              <>

                {/* Temel PDF görüntüleyici - tüm tarayıcılar ve cihazlar için güvenilir çalışır */}
                <div className="flex flex-col md:flex-row gap-8">
                  <div className="w-full md:w-1/3">
                    <h3 className="text-lg font-semibold mb-4">PDF Düzenleme</h3>
                    <PDFEditingPanel 
                      currentPage={currentPageIndex + 1}
                      totalPages={numPages}
                      onPrevPage={goToPrevPage}
                      onNextPage={goToNextPage}
                      onAddText={handleAddText}
                      onAddImage={handleAddImage}
                    />
                  </div>
                  
                  <div className="w-full md:w-2/3">
                    <h3 className="text-lg font-semibold mb-4">PDF Düzenleme Ekranı</h3>
                    <InteractivePDFViewer 
                      pdfUrl={`/api/pdf/${currentPdfId}/file`}
                      currentPage={currentPageIndex + 1}
                      totalPages={numPages}
                      onPageChange={(pageNumber) => setCurrentPageIndex(pageNumber - 1)}
                      onClickPosition={handleAddTextAtPosition}
                      enableTextOverlay={true}
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </main>
    </>
  );
}
