import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, ChevronDown, ChevronUp, FileText, Plus, Trash, Upload, X, ChevronLeft, ChevronRight, Eye, ZoomIn, ZoomOut, Maximize2, MinusCircle } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import MobileActionBar from '@/components/MobileActionBar';
import { PDFDocument } from 'pdf-lib';
import BackButton from '@/components/ui/back-button';
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface PagePreview {
  index: number;
  dataUrl: string;
  selected: boolean;
}

const PDFSplitPage: React.FC = () => {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfBuffer, setPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [pageCount, setPageCount] = useState(0);
  const [pagePreviews, setPagePreviews] = useState<PagePreview[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [previewPage, setPreviewPage] = useState<PagePreview | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [previewZoom, setPreviewZoom] = useState(1.0);
  const previewContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  // Modal açıldığında yakınlaştırma sıfırla
  useEffect(() => {
    if (showPreview) {
      setPreviewZoom(1.0);
    }
  }, [showPreview]);
  
  // İki parmakla yakınlaştırma/uzaklaştırma işlemi
  useEffect(() => {
    if (!previewContainerRef.current || !showPreview) return;
    
    const container = previewContainerRef.current;
    
    let initialDistance = 0;
    let initialZoom = 1.0;
    
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        // İki parmak tespit edildi
        initialDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        initialZoom = previewZoom;
        e.preventDefault();
      }
    };
    
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        // İki parmak hareketi tespit edildi
        const currentDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        
        // Mesafe oranına göre yakınlaştırma/uzaklaştırma
        const ratio = currentDistance / initialDistance;
        const newZoom = Math.max(0.5, Math.min(2.5, initialZoom * ratio));
        setPreviewZoom(newZoom);
        e.preventDefault();
      }
    };
    
    // Event listener'ları ekle
    container.addEventListener('touchstart', handleTouchStart, { passive: false });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });
    
    return () => {
      // Event listener'ları kaldır
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
    };
  }, [previewContainerRef, showPreview, previewZoom]);
  
  // PDF dosyasını yükle ve önizlemeleri oluştur
  const handleFileUpload = useCallback(async (file: File) => {
    if (file && file.type === 'application/pdf') {
      setIsLoading(true);
      setPdfFile(file);
      
      try {
        // PDF dosyasını ArrayBuffer olarak oku
        const buffer = await file.arrayBuffer();
        setPdfBuffer(buffer);
        
        // PDF dökümanını yükle
        const pdfDoc = await PDFDocument.load(buffer);
        const totalPages = pdfDoc.getPageCount();
        setPageCount(totalPages);
        
        // Her sayfa için önizleme oluştur
        const previews: PagePreview[] = [];
        
        for (let i = 0; i < totalPages; i++) {
          // Tek sayfalık yeni bir PDF oluştur
          const newPdf = await PDFDocument.create();
          const [copiedPage] = await newPdf.copyPages(pdfDoc, [i]);
          newPdf.addPage(copiedPage);
          
          // PDF'i base64 olarak dönüştür
          const pdfBytes = await newPdf.save();
          const blob = new Blob([pdfBytes], { type: 'application/pdf' });
          const dataUrl = URL.createObjectURL(blob);
          
          previews.push({
            index: i,
            dataUrl,
            selected: true // Varsayılan olarak tüm sayfalar seçili
          });
        }
        
        setPagePreviews(previews);
        
        // İlk sayfa için otomatik önizleme göster (eğer en az bir sayfa varsa)
        if (previews.length > 0) {
          setPreviewPage(previews[0]);
          setShowPreview(true);
        }
        
        toast({
          title: "PDF Yüklendi",
          description: `${file.name} dosyası başarıyla yüklendi. ${totalPages} sayfa bulundu.`,
        });
      } catch (error) {
        console.error('PDF yükleme hatası:', error);
        toast({
          title: "PDF Yükleme Hatası",
          description: "PDF dosyası yüklenirken bir hata oluştu.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    } else {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında bir dosya yükleyin.",
        variant: "destructive",
      });
    }
  }, [toast]);

  // Tüm sayfaları seç veya seçimi kaldır
  const toggleSelectAll = useCallback((select: boolean) => {
    setPagePreviews(prev => prev.map(page => ({ ...page, selected: select })));
  }, []);

  // Belirli bir sayfanın seçimini değiştir
  const togglePageSelection = useCallback((index: number) => {
    setPagePreviews(prev => {
      return prev.map(page => {
        if (page.index === index) {
          return { ...page, selected: !page.selected };
        }
        return page;
      });
    });
  }, []);

  // Seçili sayfaları yeni bir PDF olarak kaydet
  const createPdfFromSelectedPages = useCallback(async () => {
    if (!pdfBuffer) {
      toast({
        title: "Hata",
        description: "İşlenecek PDF bulunamadı.",
        variant: "destructive",
      });
      return;
    }
    
    const selectedPages = pagePreviews.filter(page => page.selected);
    
    if (selectedPages.length === 0) {
      toast({
        title: "Sayfa Seçilmedi",
        description: "Lütfen en az bir sayfa seçin.",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Orijinal PDF'i yükle
      const pdfDoc = await PDFDocument.load(pdfBuffer);
      
      // Seçili sayfalardan yeni bir PDF oluştur
      const newPdf = await PDFDocument.create();
      
      // Seçili sayfaları orjinal sıralarına göre sırala
      const sortedSelectedPages = selectedPages.sort((a, b) => a.index - b.index);
      
      // Seçili sayfaları yeni PDF'e kopyala
      for (const page of sortedSelectedPages) {
        const [copiedPage] = await newPdf.copyPages(pdfDoc, [page.index]);
        newPdf.addPage(copiedPage);
      }
      
      // Yeni PDF'i kaydet
      const pdfBytes = await newPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      // PDF'i indir
      const a = document.createElement('a');
      a.href = url;
      a.download = pdfFile ? `${pdfFile.name.replace('.pdf', '')}-secilen-sayfalar.pdf` : 'secilen-sayfalar.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "PDF Oluşturuldu",
        description: `Seçili ${selectedPages.length} sayfadan yeni PDF oluşturuldu ve indirildi.`,
      });
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      toast({
        title: "PDF Oluşturma Hatası",
        description: "Yeni PDF oluşturulurken bir hata meydana geldi.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [pdfBuffer, pagePreviews, pdfFile, toast]);

  // Döküman kapatıldığında kaynakları temizle
  const resetDocument = useCallback(() => {
    // Önizleme URL'lerini serbest bırak
    pagePreviews.forEach(page => URL.revokeObjectURL(page.dataUrl));
    
    setPdfFile(null);
    setPdfBuffer(null);
    setPageCount(0);
    setPagePreviews([]);
  }, [pagePreviews]);

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">PDF Sayfalarını Düzenle</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">PDF Sayfalarını Düzenle</h1>
        )}
      </div>
      
      {!pdfFile ? (
        <Card className="p-6 mb-6">
          <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg mb-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
            <FileText className="h-12 w-12 text-gray-400 mb-2" />
            <p className="text-sm text-gray-500 mb-2">PDF dosyası seçin veya buraya sürükleyin</p>
            <p className="text-xs text-gray-500 mb-4">Sayfaları düzenlemek istediğiniz PDF dosyasını yükleyin</p>
            <Button 
              onClick={() => {
                const fileInput = document.createElement('input');
                fileInput.type = 'file';
                fileInput.accept = '.pdf';
                fileInput.onchange = (e) => {
                  const files = (e.target as HTMLInputElement).files;
                  if (files && files.length > 0) {
                    handleFileUpload(files[0]);
                  }
                };
                fileInput.click();
              }}
              className="flex items-center gap-2"
              disabled={isLoading}
            >
              {isLoading ? 'Yükleniyor...' : (
                <>
                  <Upload className="h-4 w-4" />
                  PDF Dosyası Seç
                </>
              )}
            </Button>
          </div>
        </Card>
      ) : (
        <>
          <Card className="p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-lg font-semibold">{pdfFile.name}</h2>
                <p className="text-sm text-gray-500">Toplam {pageCount} sayfa</p>
              </div>
              
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => resetDocument()}
                >
                  Belgeyi Kapat
                </Button>
                
                <Button
                  onClick={createPdfFromSelectedPages}
                  disabled={isProcessing || pagePreviews.filter(p => p.selected).length === 0}
                  className="flex items-center gap-2"
                  size="sm"
                >
                  {isProcessing ? 'İşleniyor...' : 'Seçili Sayfalardan PDF Oluştur'}
                </Button>
              </div>
            </div>
            
            <div className="flex items-center gap-4 mb-4 p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="select-all" 
                  checked={pagePreviews.length > 0 && pagePreviews.every(p => p.selected)}
                  onCheckedChange={(checked) => toggleSelectAll(checked === true)}
                />
                <Label htmlFor="select-all">Tümünü Seç</Label>
              </div>
              
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="deselect-all" 
                  checked={pagePreviews.length > 0 && pagePreviews.every(p => !p.selected)}
                  onCheckedChange={(checked) => toggleSelectAll(checked !== true)}
                />
                <Label htmlFor="deselect-all">Seçimi Kaldır</Label>
              </div>
              
              <p className="text-sm text-gray-500 ml-auto">
                {pagePreviews.filter(p => p.selected).length} sayfa seçildi
              </p>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-4">
              {pagePreviews.map((page) => (
                <div 
                  key={page.index}
                  className={`border rounded-md overflow-hidden ${page.selected ? 'border-primary/70 bg-primary/5' : 'border-gray-200 dark:border-gray-700'}`}
                >
                  <div className="relative">
                    <div 
                      className="aspect-[3/4] w-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center cursor-pointer"
                      onClick={() => {
                        setPreviewPage(page);
                        setShowPreview(true);
                      }}
                    >
                      <iframe 
                        src={page.dataUrl} 
                        className="w-full h-full pointer-events-none" 
                        title={`Sayfa ${page.index + 1}`}
                      />
                    </div>
                    
                    <div className="absolute top-2 right-2 flex space-x-1">
                      <Button
                        variant="outline"
                        size="icon"
                        className={`h-7 w-7 bg-white/90 dark:bg-gray-800/90 hover:bg-blue-50 dark:hover:bg-blue-900/20`}
                        onClick={() => {
                          setPreviewPage(page);
                          setShowPreview(true);
                        }}
                        title="Önizleme"
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        className={`h-7 w-7 ${page.selected ? 'bg-primary text-white hover:bg-primary/90' : 'bg-white/90 dark:bg-gray-800/90'}`}
                        onClick={() => togglePageSelection(page.index)}
                        title={page.selected ? "Seçimi Kaldır" : "Seç"}
                      >
                        {page.selected ? (
                          <span>✓</span>
                        ) : (
                          <Plus className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <div className="p-2 text-center text-sm">
                    Sayfa {page.index + 1}
                  </div>
                </div>
              ))}
            </div>
          </Card>
          
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-3">Nasıl Çalışır?</h3>
            <ol className="list-decimal pl-5 space-y-2 text-sm">
              <li>Yukarıdaki sayfa önizlemelerinde saklamak istediğiniz sayfaları seçin.</li>
              <li>Seçmediğiniz sayfalar yeni PDF'e dahil edilmeyecektir.</li>
              <li>Seçiminizi tamamladığınızda "Seçili Sayfalardan PDF Oluştur" butonuna tıklayın.</li>
              <li>Yeni PDF dosyası otomatik olarak indirilecektir.</li>
            </ol>
            
            <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-md text-sm text-amber-600 dark:text-amber-400 flex items-start gap-2">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p>Orijinal PDF dosyasında değişiklik yapılmaz. Bu işlem sadece seçtiğiniz sayfalardan yeni bir PDF dosyası oluşturur.</p>
            </div>
          </Card>
        </>
      )}
      
      {/* Önizleme modalı */}
      {showPreview && previewPage && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="text-lg font-semibold">Sayfa {previewPage.index + 1} Önizleme</h3>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowPreview(false)}
                className="h-8 w-8"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-gray-100 dark:bg-gray-900 relative">
              <div 
                ref={previewContainerRef}
                className="relative overflow-auto h-full w-full max-h-[70vh]"
                style={{ 
                  touchAction: "manipulation",
                  overflowY: "auto", 
                  overflowX: "auto" 
                }}
              >
                <div 
                  style={{ 
                    transform: `scale(${previewZoom})`, 
                    transformOrigin: 'center top',
                    transition: 'transform 0.2s ease'
                  }}
                  className="flex items-center justify-center min-h-full"
                >
                  <iframe
                    src={previewPage.dataUrl}
                    title={`Sayfa Önizleme ${previewPage.index + 1}`}
                    className="border-0 h-[70vh]"
                    style={{ pointerEvents: "none" }}
                    sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"
                  />
                </div>
              </div>
              
              {/* Yakınlaştırma/Uzaklaştırma kontrolleri */}
              <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 flex flex-col">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPreviewZoom(prev => Math.min(prev + 0.1, 2.5))}
                  className="h-8 w-8"
                  title="Yakınlaştır"
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPreviewZoom(1.0)}
                  className="h-8 w-8"
                  title="Varsayılan Boyut"
                >
                  <Maximize2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPreviewZoom(prev => Math.max(prev - 0.1, 0.5))}
                  className="h-8 w-8"
                  title="Uzaklaştır"
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="p-4 border-t flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => togglePageSelection(previewPage.index)}
                >
                  {previewPage.selected ? 'Seçimi Kaldır' : 'Sayfayı Seç'}
                </Button>
              </div>
              <Button 
                onClick={() => setShowPreview(false)}
              >
                Kapat
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="PDF Sayfalarını Düzenle"
          onSave={pdfFile && pagePreviews.some(p => p.selected) ? createPdfFromSelectedPages : undefined}
          showSave={Boolean(pdfFile && pagePreviews.some(p => p.selected))}
          showDownload={false}
          isSaving={isProcessing}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default PDFSplitPage;