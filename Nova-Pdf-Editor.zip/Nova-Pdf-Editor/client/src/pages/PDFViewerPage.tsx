import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Upload, Languages, Globe } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import MobileActionBar from '@/components/MobileActionBar';
import BackButton from '@/components/ui/back-button';
import EnhancedPDFViewer from '@/components/EnhancedPDFViewer';
import { TooltipProvider } from '@/components/ui/tooltip';

const PDFViewerPage: React.FC = () => {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedText, setSelectedText] = useState<string>("");
  const [isTranslationDialogOpen, setIsTranslationDialogOpen] = useState(false);
  const [translations, setTranslations] = useState<{[key: string]: string}>({});
  const [isTranslating, setIsTranslating] = useState(false);
  const [hasUsedFreeTrial, setHasUsedFreeTrial] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  // PDF yükleme işlemi
  const handleFileUpload = useCallback(async (file: File) => {
    if (file && file.type === 'application/pdf') {
      setIsLoading(true);
      setPdfFile(file);
      
      try {
        // PDF dosyası URL'ini oluştur
        const url = URL.createObjectURL(file);
        setPdfUrl(url);
        
        toast({
          title: "PDF Yüklendi",
          description: `${file.name} dosyası başarıyla yüklendi.`,
        });
      } catch (error) {
        console.error('PDF yükleme hatası:', error);
        toast({
          title: "PDF Yükleme Hatası",
          description: "PDF dosyası yüklenirken bir hata oluştu.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    } else {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında bir dosya yükleyin.",
        variant: "destructive",
      });
    }
  }, [toast]);

  // PDF yazdırma fonksiyonu
  const handlePrint = useCallback(() => {
    if (!pdfUrl) return;
    
    // PDF'i yeni sekmede açarak yazdırma yapmak daha güvenli ve tarayıcı dostu
    const pdfWindow = window.open(pdfUrl, '_blank');
    
    if (pdfWindow) {
      toast({
        title: "PDF Açıldı",
        description: "PDF yeni sekmede açıldı. Tarayıcınızın yazdırma özelliğini kullanabilirsiniz (Ctrl+P).",
      });
    } else {
      toast({
        title: "Açma Hatası",
        description: "PDF yeni sekmede açılamadı. Tarayıcınızın popup engelleyicisi etkin olabilir.",
        variant: "destructive",
      });
    }
  }, [pdfUrl, toast]);

  // PDF indirme fonksiyonu
  const handleDownload = useCallback(() => {
    if (!pdfUrl || !pdfFile) return;
    
    const link = document.createElement('a');
    link.href = pdfUrl;
    link.download = pdfFile.name;
    link.click();
    
    toast({
      title: "PDF İndiriliyor",
      description: `${pdfFile.name} dosyası indiriliyor.`,
    });
  }, [pdfUrl, pdfFile, toast]);

  // PDF'i kapat ve temizle
  const resetDocument = useCallback(() => {
    if (pdfUrl) {
      URL.revokeObjectURL(pdfUrl);
    }
    
    setPdfFile(null);
    setPdfUrl(null);
    setCurrentPage(1);
    setTotalPages(0);
  }, [pdfUrl]);

  // Sayfa değişikliği
  const handlePageChange = useCallback((pageNumber: number) => {
    setCurrentPage(pageNumber);
  }, []);

  // Toplam sayfa sayısı değişikliği
  const handleTotalPagesChange = useCallback((pages: number) => {
    setTotalPages(pages);
  }, []);
  
  // Başlangıçta LocalStorage'dan ücretsiz deneme kullanımını kontrol et
  useEffect(() => {
    const trialUsed = localStorage.getItem('translation_trial_used') === 'true';
    setHasUsedFreeTrial(trialUsed);
  }, []);
  
  // Metin seçimi
  const handleTextSelect = useCallback((text: string) => {
    setSelectedText(text);
    if (text) {
      setIsTranslationDialogOpen(true);
      
      if (!hasUsedFreeTrial) {
        // Demo çeviriler oluştur
        setTimeout(() => {
          setTranslations({
            en: "This is a demo translation to English.",
            fr: "C'est une traduction de démonstration en français.",
            de: "Dies ist eine Demo-Übersetzung auf Deutsch.",
            ar: "هذه ترجمة تجريبية إلى اللغة العربية.",
            zh: "这是一个示范翻译成中文。"
          });
          setIsTranslating(false);
          
          // Ücretsiz denemeyi kullanıldı olarak işaretle
          setHasUsedFreeTrial(true);
          localStorage.setItem('translation_trial_used', 'true');
          
          toast({
            title: "Deneme Çeviri Tamamlandı",
            description: "Bu bir deneme çevirisidir. Pro sürüme geçerek sınırsız çeviri yapabilirsiniz.",
            duration: 5000
          });
        }, 1500);
      } else {
        // Pro sürüm gerekli uyarısı
        toast({
          title: "Pro Özelliği Gerekli",
          description: "Çeviri yapmak için Pro sürüme yükseltmeniz gerekmektedir.",
          variant: "destructive",
          duration: 5000
        });
        // Çeviri diyalogunu kapatma zamanlaması
        setTimeout(() => {
          setIsTranslationDialogOpen(false);
        }, 2000);
      }
    }
  }, [hasUsedFreeTrial, toast]);

  return (
    <TooltipProvider>
      <div className="container mx-auto px-4 py-8 pb-20">
        <div className="flex items-center justify-between mb-6">
          {!isMobile ? (
            <>
              <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
              <h1 className="text-3xl font-bold">PDF Görüntüle</h1>
              <div className="w-[100px]"></div>
            </>
          ) : (
            <h1 className="text-xl font-bold mx-auto">PDF Görüntüle</h1>
          )}
        </div>
        
        {!pdfFile ? (
          <Card className="p-6 mb-6">
            <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg mb-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
              <FileText className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-sm text-gray-500 mb-2">Görüntülemek istediğiniz PDF dosyasını seçin</p>
              <p className="text-xs text-gray-500 mb-4">Yüklediğiniz PDF dosyasını büyütebilir, küçültebilir, döndürebilir ve yazdırabilirsiniz</p>
              <Button 
                onClick={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.pdf';
                  fileInput.onchange = (e) => {
                    const files = (e.target as HTMLInputElement).files;
                    if (files && files.length > 0) {
                      handleFileUpload(files[0]);
                    }
                  };
                  fileInput.click();
                }}
                className="flex items-center gap-2"
                disabled={isLoading}
              >
                {isLoading ? 'Yükleniyor...' : (
                  <>
                    <Upload className="h-4 w-4" />
                    PDF Dosyası Seç
                  </>
                )}
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-lg font-semibold">{pdfFile.name}</h2>
                <p className="text-sm text-gray-500">PDF Görüntüleyici</p>
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={resetDocument}
              >
                Belgeyi Kapat
              </Button>
            </div>
            
            {pdfUrl && (
              <EnhancedPDFViewer 
                pdfUrl={pdfUrl}
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
                onTotalPagesChange={handleTotalPagesChange}
                onPrint={handlePrint}
                onDownload={handleDownload}
                pdfName={pdfFile.name}
                className="mb-4"
                onTextSelect={handleTextSelect}
              />
            )}
            
            <div className="text-center text-xs text-gray-500 mt-4">
              <p>Soldan küçük resimler ile sayfalar arasında dolaşabilir, sayfaları döndürebilir ve yakınlaştırabilirsiniz.</p>
              <p className="mt-1">Ayrıca doğrudan sayfa numarasını girerek istediğiniz sayfaya gidebilirsiniz.</p>
            </div>
          </Card>
        )}
        
        {/* Mobil görünümde alt çubuk */}
        {isMobile && (
          <MobileActionBar
            title="PDF Görüntüle"
            showSave={false}
            showDownload={false}
            onBack={() => setLocation("/mobile")}
          />
        )}
      </div>
      
      {/* Çeviri Modal */}
      <Dialog open={isTranslationDialogOpen} onOpenChange={setIsTranslationDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Languages className="h-5 w-5 mr-2" />
              Metin Çevirisi
            </DialogTitle>
            <DialogDescription>
              {hasUsedFreeTrial 
                ? "Bu özellik Pro sürüm aboneliği gerektirmektedir. Lütfen Pro sürüme yükseltin."
                : "Bu bir deneme çevirisidir. Pro sürüme geçerek sınırsız çeviri yapabilirsiniz."}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-md border">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Seçilen Metin:</h3>
              <p className="text-sm">{selectedText}</p>
            </div>
            
            <Tabs defaultValue="en">
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="en">İngilizce</TabsTrigger>
                <TabsTrigger value="fr">Fransızca</TabsTrigger>
                <TabsTrigger value="de">Almanca</TabsTrigger>
                <TabsTrigger value="ar">Arapça</TabsTrigger>
                <TabsTrigger value="zh">Çince</TabsTrigger>
              </TabsList>
              
              {isTranslating ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Çeviriliyor"/>
                </div>
              ) : (
                <>
                  <TabsContent value="en" className="p-3 bg-white dark:bg-gray-800 rounded-md border min-h-[100px]">
                    {translations.en || "Pro sürümde çevirilere erişebilirsiniz."}
                  </TabsContent>
                  <TabsContent value="fr" className="p-3 bg-white dark:bg-gray-800 rounded-md border min-h-[100px]">
                    {translations.fr || "Pro sürümde çevirilere erişebilirsiniz."}
                  </TabsContent>
                  <TabsContent value="de" className="p-3 bg-white dark:bg-gray-800 rounded-md border min-h-[100px]">
                    {translations.de || "Pro sürümde çevirilere erişebilirsiniz."}
                  </TabsContent>
                  <TabsContent value="ar" className="p-3 bg-white dark:bg-gray-800 rounded-md border min-h-[100px] text-right">
                    {translations.ar || "Pro sürümde çevirilere erişebilirsiniz."}
                  </TabsContent>
                  <TabsContent value="zh" className="p-3 bg-white dark:bg-gray-800 rounded-md border min-h-[100px]">
                    {translations.zh || "Pro sürümde çevirilere erişebilirsiniz."}
                  </TabsContent>
                </>
              )}
            </Tabs>
            
            <div className="flex justify-between items-center pt-2">
              <div className="text-xs text-gray-500 flex items-center">
                <Languages className="h-3 w-3 mr-1 inline" />
                Powered by Nova AI Translation
              </div>
              <Button 
                variant="default" 
                onClick={() => setIsTranslationDialogOpen(false)}
              >
                Kapat
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
};

export default PDFViewerPage;