import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, ChevronDown, ChevronUp, FileText, Plus, Trash, Upload, X } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import MobileActionBar from '@/components/MobileActionBar';
import { PDFDocument } from 'pdf-lib';
import BackButton from '@/components/ui/back-button';

interface UploadedPDF {
  id: string;
  file: File;
  url: string;
  pageCount?: number;
}

const PDFMergePage: React.FC = () => {
  const [pdfs, setPdfs] = useState<UploadedPDF[]>([]);
  const [isMerging, setIsMerging] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  // PDF dosyalarını yükle
  const handleFileUpload = (files: FileList) => {
    const fileArray = Array.from(files);
    const pdfFiles = fileArray.filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length === 0) {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında dosyalar yükleyin.",
        variant: "destructive",
      });
      return;
    }

    // Yeni PDF dosyalarını mevcut listeye ekle
    const newPdfs = pdfFiles.map(file => ({
      id: Math.random().toString(36).substring(2, 9),
      file,
      url: URL.createObjectURL(file),
    }));

    setPdfs(prev => [...prev, ...newPdfs]);
    
    toast({
      title: "PDF Yüklendi",
      description: `${pdfFiles.length} adet PDF dosyası başarıyla eklendi.`,
    });
  };

  // Belirli bir PDF'i kaldır
  const removePdf = (id: string) => {
    setPdfs(prev => {
      const filtered = prev.filter(pdf => pdf.id !== id);
      // Kaldırılan PDF'in URL'ini temizle
      const removedPdf = prev.find(pdf => pdf.id === id);
      if (removedPdf) {
        URL.revokeObjectURL(removedPdf.url);
      }
      return filtered;
    });
  };

  // PDF'in sırasını değiştir (yukarı taşı)
  const movePdfUp = (index: number) => {
    if (index <= 0) return;
    setPdfs(prev => {
      const newOrder = [...prev];
      [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
      return newOrder;
    });
  };

  // PDF'in sırasını değiştir (aşağı taşı)
  const movePdfDown = (index: number) => {
    if (index >= pdfs.length - 1) return;
    setPdfs(prev => {
      const newOrder = [...prev];
      [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
      return newOrder;
    });
  };

  // PDF'leri birleştir
  const mergePdfs = async () => {
    if (pdfs.length < 2) {
      toast({
        title: "Yetersiz PDF Sayısı",
        description: "Birleştirmek için en az 2 PDF dosyası gereklidir.",
        variant: "destructive",
      });
      return;
    }

    setIsMerging(true);
    try {
      // Yeni bir PDF oluştur
      const mergedPdf = await PDFDocument.create();
      
      // Tüm PDF'leri sırayla birleştir
      for (const pdf of pdfs) {
        try {
          const pdfBytes = await fetch(pdf.url).then(res => res.arrayBuffer());
          const pdfDoc = await PDFDocument.load(pdfBytes);
          const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
          copiedPages.forEach(page => mergedPdf.addPage(page));
        } catch (err) {
          console.error(`PDF birleştirme hatası (${pdf.file.name}):`, err);
          toast({
            title: "PDF Birleştirme Hatası",
            description: `"${pdf.file.name}" dosyası eklenirken hata oluştu.`,
            variant: "destructive",
          });
        }
      }
      
      // Birleştirilmiş PDF'i kaydet
      const mergedPdfBytes = await mergedPdf.save();
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      // PDF'i indir
      const a = document.createElement('a');
      a.href = url;
      a.download = 'birlestirilmis-pdf.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "PDF'ler Birleştirildi",
        description: "Tüm PDF dosyaları başarıyla birleştirildi ve indirildi.",
      });
    } catch (error) {
      console.error('PDF birleştirme hatası:', error);
      toast({
        title: "Birleştirme Hatası",
        description: "PDF dosyaları birleştirilirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsMerging(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">PDF Birleştirme</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">PDF Birleştirme</h1>
        )}
      </div>
      
      <Card className="p-6 mb-6">
        <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg mb-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
          <FileText className="h-12 w-12 text-gray-400 mb-2" />
          <p className="text-sm text-gray-500 mb-2">PDF dosyalarını seçin veya buraya sürükleyin</p>
          <p className="text-xs text-gray-500 mb-4">Birleştirmek istediğiniz tüm PDF dosyalarını tek seferde seçebilirsiniz</p>
          <Button 
            onClick={() => {
              const fileInput = document.createElement('input');
              fileInput.type = 'file';
              fileInput.accept = '.pdf';
              fileInput.multiple = true;
              fileInput.onchange = (e) => {
                const files = (e.target as HTMLInputElement).files;
                if (files && files.length > 0) {
                  handleFileUpload(files);
                }
              };
              fileInput.click();
            }}
            className="flex items-center gap-2"
          >
            <Upload className="h-4 w-4" />
            PDF Dosyalarını Seç
          </Button>
        </div>
        
        {pdfs.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-3">Birleştirilecek PDF Dosyaları ({pdfs.length})</h3>
            <p className="text-sm text-gray-500 mb-4">
              PDF'ler aşağıdaki sırayla birleştirilecektir. Sıralamayı değiştirmek için okları kullanabilirsiniz.
            </p>
            
            <div className="space-y-2 mt-4">
              {pdfs.map((pdf, index) => (
                <div 
                  key={pdf.id} 
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-md border"
                >
                  <div className="flex items-center flex-1 min-w-0">
                    <FileText className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                    <span className="text-sm truncate">{pdf.file.name}</span>
                    <span className="text-xs text-gray-500 ml-2">
                      ({(pdf.file.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 ml-2">
                    <Button
                      variant="ghost" 
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => movePdfUp(index)}
                      disabled={index === 0}
                    >
                      <ChevronUp className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost" 
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => movePdfDown(index)}
                      disabled={index === pdfs.length - 1}
                    >
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost" 
                      size="icon"
                      className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                      onClick={() => removePdf(pdf.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 mt-6">
              <Button
                onClick={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.pdf';
                  fileInput.multiple = true;
                  fileInput.onchange = (e) => {
                    const files = (e.target as HTMLInputElement).files;
                    if (files && files.length > 0) {
                      handleFileUpload(files);
                    }
                  };
                  fileInput.click();
                }}
                variant="outline"
                className="flex items-center justify-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Daha Fazla PDF Ekle
              </Button>
              
              <Button
                onClick={mergePdfs}
                disabled={pdfs.length < 2 || isMerging}
                className="flex items-center justify-center gap-2"
              >
                {isMerging ? (
                  <>
                    <span className="animate-spin">⏳</span>
                    İşleniyor...
                  </>
                ) : (
                  <>
                    Birleştir ve İndir
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </Card>
      
      {pdfs.length === 0 && (
        <Card className="p-6">
          <div className="flex items-center text-amber-500 p-4 bg-amber-50 dark:bg-amber-950/20 rounded-md mb-4">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
            <p className="text-sm">
              Birleştirmek için en az 2 PDF dosyası yüklemelisiniz. PDF dosyalarını sırayla yükleyin veya tek seferde birden fazla dosya seçin.
            </p>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Nasıl Çalışır?</h3>
            <ol className="list-decimal pl-5 space-y-2 text-sm">
              <li>"PDF Dosyalarını Seç" düğmesine tıklayarak birleştirmek istediğiniz PDF dosyalarını yükleyin.</li>
              <li>Yüklenen dosyaları sürükleyerek veya ok tuşlarını kullanarak istediğiniz sıraya getirin.</li>
              <li>Dosyaların doğru sırada olduğunu kontrol edin - dosyalar listede göründüğü sırayla birleştirilecektir.</li>
              <li>"Birleştir ve İndir" düğmesine tıklayarak PDF dosyalarını birleştirin.</li>
              <li>Birleştirme işlemi tamamlandığında, yeni oluşturulan PDF dosyası otomatik olarak indirilecektir.</li>
            </ol>
          </div>
        </Card>
      )}
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="PDF Birleştirme"
          onSave={pdfs.length >= 2 ? mergePdfs : undefined}
          showSave={pdfs.length >= 2}
          showDownload={false}
          isSaving={isMerging}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default PDFMergePage;