import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useIsMobile } from '@/hooks/use-mobile';
import BackButton from '@/components/ui/back-button';
import MobileActionBar from '@/components/MobileActionBar';
import TranslationTools from '@/components/TranslationTools';
import BasicPDFViewer from '@/components/BasicPDFViewer';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsList, TabsContent, TabsTrigger } from '@/components/ui/tabs';
import { LayoutGrid, Languages, FileText, Upload, FileUp, FileQuestion } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { FileInput } from '@/components/ui/FileInput';

const TranslationPage: React.FC = () => {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfText, setPdfText] = useState<string[]>([]);
  const [translatedText, setTranslatedText] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<string>("original");
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [showDemoContent, setShowDemoContent] = useState<boolean>(false);
  
  // Kullanıcı Pro versiyona sahip mi kontrolü
  const [isProUser, setIsProUser] = useState<boolean>(true); // TEST için Pro modunu aktif ettik
  
  // Pro kullanıcı durumunu kontrol et
  useEffect(() => {
    // TEST MODU: Pro kullanıcı olarak ayarla
    localStorage.setItem('pro_user', 'true');
    setIsProUser(true);
    console.log("TEST MODU: Çeviri özelliği için Pro kullanıcı özelliği aktif edildi");
  }, []);
  
  // PDF yükleme işlemi
  const handleFileUpload = (file: File) => {
    setPdfFile(file);
    setIsUploading(true);
    setShowDemoContent(false);
    
    // PDF dosyasının içeriğini çıkar ve URL'ini ayarla
    const fileReader = new FileReader();
    fileReader.onload = (event) => {
      if (event.target?.result) {
        const url = URL.createObjectURL(file);
        setPdfUrl(url);
        
        // Gerçek uygulamada burada PDF'ten metin çıkarma işlemi yapılacak
        // Şimdilik demo metin kullanıyoruz
        setPdfText([
          "Yüklenen PDF içeriği başarıyla alındı.",
          "Bu metni gerçek PDF içeriğiniz ile değiştirin.",
          `Dosya: ${file.name}, Boyut: ${(file.size / 1024).toFixed(2)} KB`
        ]);
        
        setIsUploading(false);
        
        toast({
          title: "PDF Yüklendi",
          description: `${file.name} dosyası başarıyla yüklendi.`,
        });
      }
    };
    
    fileReader.onerror = () => {
      setIsUploading(false);
      toast({
        title: "Hata",
        description: "PDF dosyası yüklenirken bir hata oluştu.",
        variant: "destructive"
      });
    };
    
    fileReader.readAsArrayBuffer(file);
  };
  
  // Demo içeriği göster
  const handleShowDemo = () => {
    setShowDemoContent(true);
    
    // Demo metin ve PDF ayarla
    setPdfText([
      "Welcome to the PDF Translator!\n\nThis document demonstrates the translation capabilities of our application. You can translate entire PDF documents with a single click.\n\nThe translator supports multiple languages and provides accurate translations for your content.",
      "PDF documents can be complex with various elements like text, images, tables, and more. Our system attempts to preserve the structure while translating the textual content.\n\nYou can also use our dictionary feature to look up specific words and get their meanings in different languages.",
      "The translation feature is part of our premium offering in the Nova PDF Editor. With this tool, you can easily translate documents for international audiences.\n\nThank you for using our application!"
    ]);
    
    // Demo PDF URL'i ayarla
    setPdfUrl("/attached_assets/05c2b1d2-dd2e-4742-ba88-9ed2dd5b4739.png");
    
    toast({
      title: "Demo İçerik Yüklendi",
      description: "Çeviri özelliklerini test etmek için demo içerik yüklendi.",
    });
  };

  // Çevrilmiş metni işle
  const handleTranslatedText = (texts: string[]) => {
    setTranslatedText(texts);
    setActiveTab("translated");
    
    toast({
      title: "Çeviri Tamamlandı",
      description: "PDF içeriği başarıyla çevrildi.",
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">Çeviri ve Dil Araçları</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">Çeviri ve Dil Araçları</h1>
        )}
      </div>
      
      {/* PDF Yükleme Bölümü */}
      <Card className="mb-6 overflow-hidden border-2 border-primary/20 shadow-md">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-transparent">
          <CardTitle className="flex items-center gap-2">
            <FileUp className="h-5 w-5 text-primary" />
            PDF Dosyası Yükle
          </CardTitle>
          <CardDescription>
            Çeviri yapmak için PDF dosyanızı yükleyin veya demo içeriği kullanın
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg border-muted-foreground/25 hover:border-primary/50 transition-colors bg-muted/5">
              <FileUp className="w-10 h-10 mb-2 text-primary" />
              <h3 className="text-lg font-medium mb-2">PDF Dosyası Yükleyin</h3>
              <p className="text-sm text-muted-foreground text-center mb-4">
                Çeviri yapmak için bir PDF dosyası yükleyin
              </p>
              <div className="w-full max-w-sm">
                <FileInput
                  accept=".pdf"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="w-full"
                />
              </div>
              {isUploading && (
                <div className="flex items-center mt-4">
                  <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full mr-2"></div>
                  <span className="text-sm">Yükleniyor...</span>
                </div>
              )}
              {pdfFile && !isUploading && (
                <div className="mt-4 p-2 bg-primary/10 rounded-md text-sm">
                  <span className="font-medium">{pdfFile.name}</span> ({(pdfFile.size / 1024).toFixed(2)} KB)
                </div>
              )}
            </div>
            
            <div className="flex flex-col items-center justify-center p-6 border rounded-lg border-muted-foreground/25 bg-muted/5">
              <FileQuestion className="w-10 h-10 mb-2 text-primary/80" />
              <h3 className="text-lg font-medium mb-2">Demo İçeriği Kullanın</h3>
              <p className="text-sm text-muted-foreground text-center mb-4">
                Çeviri özelliklerini test etmek için örnek bir PDF içeriği kullanabilirsiniz
              </p>
              <Button 
                onClick={handleShowDemo}
                className="w-full max-w-sm"
                variant={showDemoContent ? "secondary" : "default"}
              >
                {showDemoContent ? 'Demo İçerik Yüklendi' : 'Demo İçeriği Yükle'}
              </Button>
              
              {showDemoContent && (
                <div className="mt-4 p-2 bg-primary/10 rounded-md text-sm">
                  <span className="font-medium">Demo PDF dosyası yüklendi</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Özellik açıklaması kartı */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>PDF Çeviri ve Dil Araçları</CardTitle>
          <CardDescription>
            PDF belgelerinizi farklı dillere çevirin, metinleri analiz edin ve sözlük özelliğiyle kelimelerin anlamlarını öğrenin
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col items-center text-center p-4 border rounded-md">
              <Languages className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium">PDF Çeviri</h3>
              <p className="text-sm text-muted-foreground">
                PDF içeriğini farklı dillere çevirin ve orijinal formata uygun şekilde görüntüleyin
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-4 border rounded-md">
              <LayoutGrid className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium">Metin Çevirisi</h3>
              <p className="text-sm text-muted-foreground">
                Seçtiğiniz metinleri hızlıca farklı dillere çevirin ve düzenleyin
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-4 border rounded-md">
              <FileText className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-medium">Sözlük Entegrasyonu</h3>
              <p className="text-sm text-muted-foreground">
                Metindeki kelimelerin anlamlarını ve farklı dillerdeki karşılıklarını bulun
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sol panel - PDF Görüntüleyici */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold mb-2">PDF Belgesi</h2>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full">
              <TabsTrigger value="original" className="flex-1">Orijinal PDF</TabsTrigger>
              <TabsTrigger value="translated" className="flex-1" disabled={translatedText.length === 0}>
                Çevrilmiş PDF
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="original" className="mt-2">
              {pdfUrl ? (
                <div className="relative border rounded-md overflow-hidden bg-white" style={{ height: '500px' }}>
                  <BasicPDFViewer pdfUrl={pdfUrl} />
                </div>
              ) : (
                <div className="flex items-center justify-center h-[500px] border rounded-md bg-muted/10">
                  <div className="text-center p-4">
                    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                    <p>PDF yükleniyor...</p>
                  </div>
                </div>
              )}
              
              <div className="mt-4">
                <Label className="text-sm font-medium">Orijinal Metin:</Label>
                <div className="mt-2 p-4 border rounded-md bg-muted/10 max-h-60 overflow-y-auto">
                  <p className="whitespace-pre-wrap text-sm">
                    {pdfText.join('\n\n')}
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="translated" className="mt-2">
              {pdfUrl && translatedText.length > 0 ? (
                <>
                  <div className="relative border rounded-md overflow-hidden bg-white" style={{ height: '500px' }}>
                    <BasicPDFViewer pdfUrl={pdfUrl} />
                    
                    <div className="absolute top-0 left-0 right-0 bg-primary text-white text-center py-2 opacity-80">
                      Çevrilmiş İçerik (Demo Görüntüleme)
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <Label className="text-sm font-medium">Çevrilmiş Metin:</Label>
                    <div className="mt-2 p-4 border rounded-md bg-muted/10 max-h-60 overflow-y-auto">
                      <p className="whitespace-pre-wrap text-sm">
                        {translatedText.join('\n\n')}
                      </p>
                    </div>
                  </div>
                </>
              ) : (
                <Alert className="mt-4">
                  <AlertTitle>Çevrilmiş İçerik Yok</AlertTitle>
                  <AlertDescription>
                    Henüz çevrilmiş içerik bulunmuyor. Lütfen önce PDF'i çevirin.
                  </AlertDescription>
                </Alert>
              )}
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Sağ panel - Çeviri Araçları */}
        <div>
          <h2 className="text-xl font-semibold mb-6">Dil Araçları</h2>
          
          {!isProUser ? (
            <div className="space-y-4">
              <Alert variant="destructive">
                <AlertTitle className="font-semibold">Pro Sürüm Gerekli</AlertTitle>
                <AlertDescription>
                  Çeviri özellikleri Pro sürüm aboneliği gerektirmektedir. Pro sürüme geçerek tam PDF çeviri, metin çevirisi ve sözlük özelliklerine erişebilirsiniz.
                </AlertDescription>
              </Alert>
              
              <Button 
                variant="default" 
                className="w-full"
                onClick={() => {
                  toast({
                    title: "Pro Sürüm Bilgisi",
                    description: "Pro sürüme geçiş için abonelik sayfasını ziyaret edebilirsiniz.",
                    duration: 5000
                  });
                }}
              >
                Pro Sürüme Yükselt
              </Button>
              
              <div className="p-4 border rounded-md bg-muted/40 text-sm">
                <p className="mb-2 font-medium">Pro Sürüm Özellikleri:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Tam PDF çeviri desteği (5 dil)</li>
                  <li>Seçilen metin çevirisi</li>
                  <li>OCR metin tanıma ile taranmış belgelerde çeviri</li>
                  <li>Çoklu sözlük entegrasyonu</li>
                  <li>Gelişmiş belge formatları koruma</li>
                </ul>
              </div>
            </div>
          ) : (
            <TranslationTools 
              pdfText={pdfText}
              onTranslatedText={handleTranslatedText}
            />
          )}
        </div>
      </div>
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="Çeviri Araçları"
          showSave={false}
          showDownload={false}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default TranslationPage;