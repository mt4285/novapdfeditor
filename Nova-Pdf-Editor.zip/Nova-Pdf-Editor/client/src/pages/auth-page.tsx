import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import { Eye, EyeOff, FileText, ArrowLeft } from "lucide-react";
import BackButton from "@/components/ui/back-button";

export default function AuthPage() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [showPassword, setShowPassword] = useState(false);

  // Login form state
  const [loginForm, setLoginForm] = useState({
    username: "",
    password: "",
  });

  // Register form state
  const [registerForm, setRegisterForm] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Demo mode - basit giriş simülasyonu
    if (loginForm.username.trim() && loginForm.password.trim()) {
      toast({
        title: t("success"),
        description: t("login") + " " + t("success").toLowerCase(),
      });
      
      // Ana sayfaya yönlendir
      setLocation("/");
    } else {
      toast({
        title: t("error"),
        description: "Lütfen tüm alanları doldurun.",
        variant: "destructive",
      });
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basit doğrulama
    if (!registerForm.username.trim() || !registerForm.email.trim() || 
        !registerForm.password.trim() || !registerForm.confirmPassword.trim()) {
      toast({
        title: t("error"),
        description: "Lütfen tüm alanları doldurun.",
        variant: "destructive",
      });
      return;
    }
    
    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: t("error"),
        description: "Şifreler eşleşmiyor.",
        variant: "destructive",
      });
      return;
    }
    
    // Demo mode - başarılı kayıt simülasyonu
    toast({
      title: t("success"),
      description: t("register") + " " + t("success").toLowerCase(),
    });
    
    // Ana sayfaya yönlendir
    setLocation("/");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <BackButton target="/" variant="outline" className="mr-2" />
            <FileText className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-semibold text-gray-800 dark:text-gray-200">{t("app_title")}</h1>
          </div>
          <div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-5">
        <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="bg-gradient-to-br from-primary to-indigo-600 rounded-lg p-8 text-white hidden md:block">
            <h2 className="text-3xl font-bold mb-4">{t("welcome")}</h2>
            <p className="text-lg opacity-90 mb-6">{t("welcome_subtitle")}</p>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <path d="M16 13H8"></path>
                    <path d="M16 17H8"></path>
                    <path d="M10 9H8"></path>
                  </svg>
                </div>
                <span>PDF dosyalarını kolayca düzenleyin</span>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="m18 7 4 2v11a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9l4-2"></path>
                    <path d="M14 22v-4a2 2 0 0 0-4 0v4"></path>
                    <path d="M18 22V5l-6-3-6 3v17"></path>
                    <path d="M12 7v5"></path>
                    <path d="M10 9h4"></path>
                  </svg>
                </div>
                <span>Güvenli bulut depolama ile belgelerinizi saklayın</span>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                    <path d="m9 12 2 2 4-4"></path>
                  </svg>
                </div>
                <span>Kullanımı kolay arayüz</span>
              </div>
            </div>
          </div>

          <div>
            <Tabs defaultValue="login" className="w-full max-w-md mx-auto">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t("login")}</TabsTrigger>
                <TabsTrigger value="register">{t("register")}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle>{t("login")}</CardTitle>
                    <CardDescription>
                      Hesabınıza giriş yaparak belgelerinize erişin.
                    </CardDescription>
                  </CardHeader>
                  <form onSubmit={handleLoginSubmit}>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="login-username">{t("username")}</Label>
                        <Input 
                          id="login-username"
                          placeholder="kullanici_adi"
                          value={loginForm.username}
                          onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="login-password">{t("password")}</Label>
                        <div className="relative">
                          <Input 
                            id="login-password"
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            value={loginForm.password}
                            onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-2 top-1/2 transform -translate-y-1/2"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                            <span className="sr-only">
                              {showPassword ? "Şifreyi gizle" : "Şifreyi göster"}
                            </span>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex flex-col items-start gap-4">
                      <Button type="submit" className="w-full">{t("login_button")}</Button>
                      <div className="text-sm text-muted-foreground w-full text-center">
                        <a href="#" className="text-primary hover:underline">
                          {t("forgot_password")}
                        </a>
                      </div>
                    </CardFooter>
                  </form>
                </Card>
              </TabsContent>
              
              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle>{t("register")}</CardTitle>
                    <CardDescription>
                      Yeni bir hesap oluşturarak başlayın.
                    </CardDescription>
                  </CardHeader>
                  <form onSubmit={handleRegisterSubmit}>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="register-username">{t("username")}</Label>
                        <Input 
                          id="register-username" 
                          placeholder="kullanici_adi"
                          value={registerForm.username}
                          onChange={(e) => setRegisterForm({...registerForm, username: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-email">{t("email")}</Label>
                        <Input 
                          id="register-email" 
                          type="email" 
                          placeholder="email@example.com"
                          value={registerForm.email}
                          onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-password">{t("password")}</Label>
                        <div className="relative">
                          <Input 
                            id="register-password"
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            value={registerForm.password}
                            onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-2 top-1/2 transform -translate-y-1/2"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-confirm-password">Şifre Onayı</Label>
                        <Input 
                          id="register-confirm-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={registerForm.confirmPassword}
                          onChange={(e) => setRegisterForm({...registerForm, confirmPassword: e.target.value})}
                        />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button type="submit" className="w-full">{t("register_button")}</Button>
                    </CardFooter>
                  </form>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500 dark:text-gray-400">
          &copy; {new Date().getFullYear()} PDF Düzenleyici. Tüm hakları saklıdır.
        </div>
      </footer>
    </div>
  );
}