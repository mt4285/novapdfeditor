import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import AnimatedPDFViewer, { TransitionEffect } from '@/components/AnimatedPDFViewer';
import { FileInput } from '@/components/ui/FileInput';
import MobileActionBar from '@/components/MobileActionBar';
import { ChevronLeft, Lock, Star } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

const PDFAnimationDemo = () => {
  const [, setLocation] = useLocation();
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [transitionEffect, setTransitionEffect] = useState<TransitionEffect>('slide');
  const [transitionDuration, setTransitionDuration] = useState<number>(0.5);
  const [isProUser, setIsProUser] = useState<boolean>(true); // TEST için Pro modunu aktif ettik
  const { toast } = useToast();
  
  // Pro kullanıcı durumunu kontrol et
  useEffect(() => {
    // TEST MODU: Pro kullanıcı olarak ayarla
    localStorage.setItem('pro_user', 'true');
    setIsProUser(true);
    console.log("TEST MODU: PDF Animasyon özelliği için Pro kullanıcı özelliği aktif edildi");
  }, []);
  
  const handleFileUpload = (file: File) => {
    setPdfFile(file);
    setIsUploading(true);
    
    // Simüle edilmiş yükleme
    setTimeout(() => {
      setIsUploading(false);
      setCurrentPage(1);
    }, 1000);
  };
  
  const handleReset = () => {
    setPdfFile(null);
    setCurrentPage(1);
    setTotalPages(1);
  };

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };
  
  const handleTotalPagesChange = (pages: number) => {
    setTotalPages(pages);
  };
  
  const getFileUrl = () => {
    if (!pdfFile) return '';
    return URL.createObjectURL(pdfFile);
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Mobil Başlık Çubuğu */}
      <MobileActionBar
        title="Animasyonlu PDF Gösterimi"
        onBack={() => setLocation('/')}
        showSave={false}
        showDownload={false}
      />
      
      <div className="container mx-auto px-4 py-8 flex-1">
        {!isProUser ? (
          <div className="max-w-3xl mx-auto space-y-6">
            <Alert variant="destructive" className="mb-6">
              <Lock className="h-4 w-4 mr-2" />
              <AlertTitle>Pro Sürüm Özelliği</AlertTitle>
              <AlertDescription>
                Animasyonlu PDF Görüntüleyici, Pro abonelik planına sahip kullanıcılar için sunulan bir özelliktir.
              </AlertDescription>
            </Alert>
            
            <div className="bg-card rounded-lg p-6 shadow border border-destructive/20">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
                <h2 className="text-2xl font-bold">Pro Sürüm Özelliği</h2>
                <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
              </div>
              
              <p className="text-center mb-6">
                Bu özellik yalnızca Pro abonelik paketine sahip kullanıcılar tarafından kullanılabilir.
              </p>
              
              <div className="bg-muted/40 rounded-lg p-4 mb-6">
                <h3 className="font-semibold mb-2">Animasyonlu PDF Görüntüleyici ile:</h3>
                <ul className="space-y-1 list-disc list-inside">
                  <li>5 farklı sayfa geçiş efekti (Kaydırma, Solma, Yakınlaştırma, 3D Çevirme, 3D Küp)</li>
                  <li>Geçiş hızını özelleştirme</li>
                  <li>Etkileyici sunum deneyimi</li>
                  <li>PDF içeriğini profesyonel şekilde gösterme</li>
                  <li>Sunumlarınız için premium görsel kalitesi</li>
                </ul>
              </div>
              
              <div className="text-center">
                <Button 
                  variant="default" 
                  size="lg"
                  className="w-full sm:w-auto"
                  onClick={() => {
                    // Demo amacıyla kullanıcıyı Pro yapma
                    localStorage.setItem('pro_user', 'true');
                    setIsProUser(true);
                    toast({
                      title: "Pro Sürüm Etkinleştirildi",
                      description: "Animasyonlu PDF özellikleri etkinleştirildi. (Demo amaçlı)",
                    });
                  }}
                >
                  Pro Sürüme Yükselt
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Sol Panel - Ayarlar */}
            <div className="w-full lg:w-1/4 space-y-6">
              <div className="bg-card rounded-lg p-4 shadow-sm">
                <h2 className="text-xl font-semibold mb-4">PDF Dosyası</h2>
                <div className="w-full">
                  {!pdfFile ? (
                    <FileInput
                      onFileSelected={handleFileUpload}
                      accept=".pdf"
                      disabled={isUploading}
                      maxSizeMB={30}
                      acceptedFileTypes={["application/pdf"]}
                      dropAreaClassName="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg p-8 hover:border-primary/50 transition-colors"
                    >
                      <div className="text-center">
                        <div className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                          </svg>
                        </div>
                        <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                          PDF dosyanızı sürükleyip bırakın veya seçin
                        </p>
                        <Button
                          variant="outline"
                          className="mt-2"
                          disabled={isUploading}
                          type="button"
                        >
                          {isUploading ? "Yükleniyor..." : "Dosya Seç"}
                        </Button>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                          Maksimum dosya boyutu: 30MB
                        </p>
                      </div>
                    </FileInput>
                  ) : (
                    <div className="border rounded-md p-4 bg-muted/20">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="mr-3 text-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-8 w-8">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          </div>
                          <div>
                            <p className="text-sm font-medium truncate">{pdfFile.name}</p>
                            <p className="text-xs text-muted-foreground">{(pdfFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleReset}
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        >
                          Sil
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {pdfFile && (
                <div className="bg-card rounded-lg p-4 shadow-sm space-y-4">
                  <h2 className="text-xl font-semibold mb-4">Animasyon Ayarları</h2>
                  
                  <div className="space-y-2">
                    <Label htmlFor="transition-effect">Geçiş Efekti</Label>
                    <Select 
                      value={transitionEffect} 
                      onValueChange={(value) => setTransitionEffect(value as TransitionEffect)}
                    >
                      <SelectTrigger id="transition-effect">
                        <SelectValue placeholder="Geçiş efekti seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="slide">Kaydırma</SelectItem>
                        <SelectItem value="fade">Solma</SelectItem>
                        <SelectItem value="zoom">Yakınlaştırma</SelectItem>
                        <SelectItem value="flip">3D Çevirme</SelectItem>
                        <SelectItem value="cube">3D Küp</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="transition-duration">Geçiş Süresi: {transitionDuration.toFixed(1)}s</Label>
                    </div>
                    <Slider
                      id="transition-duration"
                      min={0.1}
                      max={1.5}
                      step={0.1}
                      value={[transitionDuration]}
                      onValueChange={(values) => setTransitionDuration(values[0])}
                    />
                  </div>
                  
                  <div className="pt-4">
                    <p className="text-sm text-muted-foreground mb-2">Aktif Sayfa: {currentPage} / {totalPages}</p>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                        disabled={currentPage <= 1}
                      >
                        Önceki Sayfa
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                        disabled={currentPage >= totalPages}
                      >
                        Sonraki Sayfa
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              <Button 
                variant="outline" 
                className="w-full flex items-center justify-center" 
                onClick={() => setLocation('/')}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Ana Sayfaya Dön
              </Button>
            </div>
            
            {/* Sağ Panel - PDF Görüntüleyici */}
            <div className="w-full lg:w-3/4">
              {pdfFile ? (
                <div className="bg-card rounded-lg p-4 shadow-sm h-[80vh]">
                  <AnimatedPDFViewer
                    pdfUrl={getFileUrl()}
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                    onTotalPagesChange={handleTotalPagesChange}
                    transitionEffect={transitionEffect}
                    transitionDuration={transitionDuration}
                    className="h-full"
                  />
                </div>
              ) : (
                <div className="bg-card rounded-lg p-8 shadow-sm h-[80vh] flex flex-col items-center justify-center text-center">
                  <h3 className="text-xl font-semibold mb-4">Animasyonlu PDF Gösterim Demosu</h3>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    Sol panelden bir PDF dosyası yükleyin ve farklı sayfa geçiş animasyonlarını deneyimleyin. 
                    Kaydırma, solma, yakınlaştırma ve 3D efektler arasında geçiş yapabilirsiniz.
                  </p>
                  <div className="flex flex-col items-center space-y-4">
                    <div className="w-64 h-64 border-2 border-dashed border-muted-foreground/25 rounded-lg flex items-center justify-center">
                      <p className="text-muted-foreground text-sm">PDF dosyası burada görüntülenecek</p>
                    </div>
                    <Button onClick={() => document.getElementById('file-upload')?.click()}>
                      PDF Dosyası Yükle
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PDFAnimationDemo;