import React, { useState } from "react";
import { useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  Plus, 
  Search, 
  ImageIcon, 
  FileOutput, 
  Star, 
  ScanEye,
  ImagePlus,
  FileMinus,
  FileQuestion,
  BookText,
  FileImage,
  Merge,
  Moon,
  Sun,
  User,
  HelpCircle,
  LogIn,
  Languages,
  Globe,
  Smartphone,
  FileDown,
  FileUp,
  PlayCircle
} from "lucide-react";
import NovaLogo from "@/components/NovaLogo";
import MobileMenuItem from "@/components/ui/mobile-menu-item";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";

// PDF işlevleri için ana menü öğesi arayüzü
interface MenuItem {
  id: string;
  icon: React.ReactNode;
  label: string;
  path: string;
  description?: string;
  disabled?: boolean;
  premium?: boolean;
}

export default function MobileHomePage() {
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const [_, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);

  // PDF işlevleri için menü öğeleri
  const menuItems: MenuItem[] = [
    {
      id: "convert_center",
      icon: <FileUp className="w-6 h-6" />,
      label: "PDF Dönüştürme Merkezi",
      path: "/convert-center",
      description: "Çeşitli dosya türlerinden PDF oluştur"
    },
    {
      id: "view_pdf",
      icon: <Search className="w-6 h-6" />,
      label: "PDF Görüntüle",
      path: "/pdf-view",
      description: "PDF dosyasını görüntüle, yakınlaştır, yazdır"
    },

    {
      id: "native_capabilities",
      icon: <Smartphone className="w-6 h-6" />,
      label: "Mobil Erişim Araçları",
      path: "/native-capabilities",
      description: "Kamera, Dosya Sistemi ve Bildirim özellikleri"
    },


    {
      id: "compress_pdf",
      icon: <FileDown className="w-6 h-6" />,
      label: "PDF Sıkıştır",
      path: "/pdf-compress",
      description: "PDF boyutunu küçült"
    },
    {
      id: "merge_pdfs",
      icon: <Merge className="w-6 h-6" />,
      label: "PDF Birleştir",
      path: "/merge-pdfs",
      description: "Birden fazla PDF'i tek dosyada birleştir",
      premium: true
    },

    {
      id: "split_pdf",
      icon: <FileMinus className="w-6 h-6" />,
      label: "PDF Böl",
      path: "/pdf-split",
      description: "PDF'i birden fazla dosyaya böl",
      premium: true
    },
    {
      id: "convert_pdf",
      icon: <FileOutput className="w-6 h-6" />,
      label: "PDF Dönüştür",
      path: "/convert-pdf",
      description: "PDF'i Word, PPT veya başka formatlara dönüştür",
      premium: true
    },
    {
      id: "pdf_ocr",
      icon: <ScanEye className="w-6 h-6" />,
      label: "PDF OCR",
      path: "/pdf-ocr",
      description: "Taranmış PDF'lerden metin çıkar",
      premium: true
    },
    {
      id: "pdf_compare",
      icon: <BookText className="w-6 h-6" />,
      label: "PDF Karşılaştır",
      path: "/pdf-compare",
      description: "İki PDF arasındaki farkları göster",
      premium: true
    },
    {
      id: "translation",
      icon: <Globe className="w-6 h-6" />,
      label: "PDF Çeviri",
      path: "/translation",
      description: "PDF içeriğini farklı dillere çevir",
      premium: true
    },
    {
      id: "rate_app",
      icon: <Star className="w-6 h-6" />,
      label: "Uygulamayı Değerlendir",
      path: "/rate",
      description: "Uygulamayı değerlendir ve geribildirim gönder"
    },
    {
      id: "help",
      icon: <FileQuestion className="w-6 h-6" />,
      label: "Yardım & Destek",
      path: "/help",
      description: "Yardım ve destek alın"
    }
  ];

  const handleMenuItemClick = (item: MenuItem) => {
    if (item.disabled) {
      toast({
        title: "Yakında",
        description: "Bu özellik yakında eklenecektir.",
        variant: "default",
      });
      return;
    }

    // Premium özellikler için kontrol yapıyoruz
    if (item.premium) {
      // TEST MODU: Tüm premium özelliklere erişime izin ver
      console.log("TEST MODU: Premium özelliğe erişim sağlanıyor:", item.label);
      
      // Animasyonlu PDF özelliği 
      if (item.id === "animated_pdf") {
        setLocation("/pdf-animation");
        return;
      }
      
      // Translation sayfası için özel yönlendirme
      if (item.id === "translation") {
        setLocation("/translation");
        return;
      }
      
      // Diğer premium sayfalara yönlendir (erişim engeli kaldırıldı)
    }

    // Yeni özellikler için doğru yönlendirmeleri yapıyoruz
    if (item.id === "view_pdf") {
      // PDF görüntüleme sayfasına git
      setLocation("/pdf-view");
    } else if (item.id === "convert_center") {
      // PDF Dönüştürme Merkezi sayfasına git
      setLocation("/convert-center");
    } else if (item.id === "add_image_to_pdf") {
      // PDF'e Resim Ekle sayfasına git
      setLocation("/images-to-pdf");
    } else if (item.id === "pdf_compare") {
      // PDF karşılaştırma sayfasına git
      setLocation("/pdf-compare");
    } else if (item.id === "pdf_to_text" || item.id === "pdf_ocr") {
      // OCR sayfasına git
      setLocation("/pdf-edit");
    } else if (item.id === "merge_pdfs") {
      // PDF birleştirme sayfasına git
      setLocation("/pdf-merge");
    } else if (item.id === "split_pdf") {
      // PDF bölme sayfasına git
      setLocation("/pdf-split");
    } else if (item.id === "convert_pdf") {
      // PDF dönüştürme sayfasına git
      setLocation("/pdf-edit");
    } else if (item.id === "compress_pdf") {
      // PDF sıkıştırma sayfasına git
      setLocation("/pdf-compress");
    } else if (item.id === "rate_app") {
      // Değerlendirme sayfasına git
      setLocation("/rate");
    } else if (item.id === "help") {
      // Yardım sayfasına git
      toast({
        title: "Yardım & Destek",
        description: "Yardım ve destek bilgilerini üst menüden bulabilirsiniz.",
        variant: "default",
      });
    } else if (item.id === "native_capabilities") {
      // Native özellikler sayfasına git
      setLocation("/native-capabilities");
    } else {
      // Varsayılan olarak PDF düzenleme sayfasına git
      setLocation("/pdf-edit");
    }
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-900 min-h-screen">
      {/* Uygulama başlığı ve logo - arkaplan görseliyle */}
      <div 
        className="p-4 flex items-center justify-between shadow-sm relative overflow-hidden"
        style={{
          backgroundImage: "url('/attached_assets/DALL·E 2025-04-21 23.49.43 - A sleek, high-resolution background image with a 5_1 aspect ratio (ideal for 1500x300px) designed for an APK interface. The theme is PDF editing – inc.webp')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "70px"
        }}
      >
        {/* Arkaplan üzerine hafif şeffaf bir katman */}
        <div className="absolute inset-0 bg-white/60 dark:bg-gray-800/70 backdrop-blur-sm"></div>
        
        <div className="flex items-center z-10 relative">
          <NovaLogo size="md" className="h-9 w-9" /> {/* Logo boyutunu büyüttük */}
          <h1 className="text-xl font-bold ml-2 text-gray-800 dark:text-gray-200">Nova PDF Editör</h1>
        </div>
        <div className="flex items-center gap-2 z-10 relative">
          {/* Açık/Koyu tema değiştirme butonu */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="text-gray-600 hover:text-primary dark:text-gray-300"
            title={theme === 'dark' ? 'Açık Tema' : 'Koyu Tema'}
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          
          {/* Dil değiştirme butonu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowLanguageMenu(!showLanguageMenu)}
              className="text-gray-600 hover:text-primary dark:text-gray-300"
              title="Dil Değiştir"
            >
              <Globe className="h-5 w-5" />
            </Button>
            
            {showLanguageMenu && (
              <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-md shadow-lg z-50 border border-gray-200 dark:border-gray-700">
                <div className="py-1">
                  <button
                    className={`w-full text-left px-4 py-2 text-sm ${i18n.language === 'tr' ? 'bg-gray-100 dark:bg-gray-700' : ''}`}
                    onClick={() => {
                      localStorage.setItem("i18nextLng", "tr");
                      setShowLanguageMenu(false);
                      toast({
                        title: "Dil değiştirildi",
                        description: "Uygulama dili Türkçe olarak ayarlandı.",
                        variant: "default",
                      });
                      window.location.href = window.location.origin; // Tam sayfa yenileme yapalım
                    }}
                  >
                    Türkçe
                  </button>
                  <button
                    className={`w-full text-left px-4 py-2 text-sm ${i18n.language === 'en' ? 'bg-gray-100 dark:bg-gray-700' : ''}`}
                    onClick={() => {
                      localStorage.setItem("i18nextLng", "en");
                      setShowLanguageMenu(false);
                      toast({
                        title: "Language changed",
                        description: "Application language set to English.",
                        variant: "default",
                      });
                      window.location.href = window.location.origin; // Tam sayfa yenileme yapalım
                    }}
                  >
                    English
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* Yardım butonu */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              // Yardım modalı açmak yerine help sayfasına yönlendiriyoruz
              const helpMenuItem = menuItems.find(item => item.id === "help");
              if (helpMenuItem) {
                handleMenuItemClick(helpMenuItem);
              } else {
                toast({
                  title: "Yardım & Destek",
                  description: "Yardım ve destek sayfası açılıyor...",
                  variant: "default",
                });
                // İçinde yardım içeriğiyle özel bir sayfa oluşturmak için:
                setLocation("/help");
              }
            }}
            className="text-gray-600 hover:text-primary dark:text-gray-300"
            title="Yardım"
          >
            <HelpCircle className="h-5 w-5" />
          </Button>
          
          {/* Giriş butonu */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              toast({
                title: "Giriş",
                description: "Giriş sayfasına yönlendiriliyorsunuz.",
                variant: "default",
              });
              setLocation("/auth");
            }}
            className="text-gray-600 hover:text-primary dark:text-gray-300"
            title="Giriş Yap"
          >
            <LogIn className="h-5 w-5" />
          </Button>
          
          {/* Masaüstü görünüm butonu */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/desktop")}
            className="text-gray-600 hover:text-primary dark:text-gray-300 ml-1"
          >
            Masaüstü
          </Button>
        </div>
      </div>

      {/* Ana logo - ana ekrana hızlı erişim için */}
      <div className="flex justify-center mt-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-full p-3 shadow-md">
          <NovaLogo size="lg" className="w-20 h-20" />
        </div>
      </div>

      {/* Menü elemanları listesi */}
      <div className="px-4 pb-16">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm divide-y divide-gray-200 dark:divide-gray-700">
          {menuItems.map((item) => (
            <MobileMenuItem
              key={item.id}
              icon={item.icon}
              label={item.label}
              description={item.description}
              onClick={() => handleMenuItemClick(item)}
              isPremium={item.premium}
              disabled={item.disabled}
            />
          ))}
        </div>
      </div>
    </div>
  );
}