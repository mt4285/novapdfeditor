import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileText, Upload } from 'lucide-react';
import { useIsMobile } from "@/hooks/use-mobile";
import { useLocation } from "wouter";
import MobileActionBar from '@/components/MobileActionBar';
import PDFComparer from '@/components/PDFComparer';
import BackButton from '@/components/ui/back-button';

const PDFComparePage: React.FC = () => {
  const [firstPdfBuffer, setFirstPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [secondPdfBuffer, setSecondPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [firstPdfName, setFirstPdfName] = useState<string>("");
  const [secondPdfName, setSecondPdfName] = useState<string>("");
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  const handleFirstPdfUpload = (file: File) => {
    if (file && file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const buffer = e.target?.result as ArrayBuffer;
        setFirstPdfBuffer(buffer);
        setFirstPdfName(file.name);
        
        toast({
          title: "İlk PDF Yüklendi",
          description: `${file.name} başarıyla yüklendi.`,
        });
      };
      reader.readAsArrayBuffer(file);
    } else {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında bir dosya yükleyin.",
        variant: "destructive",
      });
    }
  };

  const handleSecondPdfUpload = (file: File) => {
    if (file && file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const buffer = e.target?.result as ArrayBuffer;
        setSecondPdfBuffer(buffer);
        setSecondPdfName(file.name);
        
        toast({
          title: "İkinci PDF Yüklendi",
          description: `${file.name} başarıyla yüklendi.`,
        });
      };
      reader.readAsArrayBuffer(file);
    } else {
      toast({
        title: "Geçersiz Dosya",
        description: "Lütfen PDF formatında bir dosya yükleyin.",
        variant: "destructive",
      });
    }
  };

  const resetComparison = () => {
    setFirstPdfBuffer(null);
    setSecondPdfBuffer(null);
    setFirstPdfName("");
    setSecondPdfName("");
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile && (
          <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
        )}
        <h1 className={`text-2xl font-bold ${isMobile ? 'mx-auto' : ''}`}>PDF Karşılaştırma</h1>
        {!isMobile && <div className="w-[100px]"></div>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Card className="p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">İlk PDF'i Yükle</h2>
            <div className="flex flex-col items-center justify-center p-4 border-2 border-dashed rounded-lg mb-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
              <FileText className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-sm text-gray-500 mb-2">PDF dosyasını seçin veya buraya sürükleyin</p>
              <Button 
                onClick={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.pdf';
                  fileInput.onchange = (e) => {
                    const files = (e.target as HTMLInputElement).files;
                    if (files && files.length > 0) {
                      handleFirstPdfUpload(files[0]);
                    }
                  };
                  fileInput.click();
                }}
                className="mt-2"
              >
                <Upload className="mr-2 h-4 w-4" />
                PDF Seç
              </Button>
            </div>
            
            {firstPdfName && (
              <div className="p-3 bg-primary/5 rounded-lg flex items-center">
                <FileText className="h-5 w-5 text-primary mr-2" />
                <span className="text-sm truncate">{firstPdfName}</span>
              </div>
            )}
          </Card>
          
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">İkinci PDF'i Yükle</h2>
            <div className="flex flex-col items-center justify-center p-4 border-2 border-dashed rounded-lg mb-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
              <FileText className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-sm text-gray-500 mb-2">PDF dosyasını seçin veya buraya sürükleyin</p>
              <Button 
                onClick={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.pdf';
                  fileInput.onchange = (e) => {
                    const files = (e.target as HTMLInputElement).files;
                    if (files && files.length > 0) {
                      handleSecondPdfUpload(files[0]);
                    }
                  };
                  fileInput.click();
                }}
                className="mt-2"
              >
                <Upload className="mr-2 h-4 w-4" />
                PDF Seç
              </Button>
            </div>
            
            {secondPdfName && (
              <div className="p-3 bg-primary/5 rounded-lg flex items-center">
                <FileText className="h-5 w-5 text-primary mr-2" />
                <span className="text-sm truncate">{secondPdfName}</span>
              </div>
            )}
          </Card>
          
          {(firstPdfBuffer || secondPdfBuffer) && (
            <Button 
              variant="outline" 
              className="w-full mt-4" 
              onClick={resetComparison}
            >
              Karşılaştırmayı Sıfırla
            </Button>
          )}
        </div>
        
        <div>
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Karşılaştırma Sonuçları</h2>
            
            {firstPdfBuffer && secondPdfBuffer ? (
              <PDFComparer 
                firstPdfBuffer={firstPdfBuffer}
                secondPdfBuffer={secondPdfBuffer}
              />
            ) : (
              <div className="p-8 text-center bg-gray-50 dark:bg-gray-800 rounded-lg">
                <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">PDF Karşılaştırması</h3>
                <p className="text-sm text-gray-500">
                  Karşılaştırma yapmak için iki PDF dosyası da yüklenmelidir.
                  {firstPdfBuffer ? " İkinci PDF'i yükleyin." : secondPdfBuffer ? " İlk PDF'i yükleyin." : ""}
                </p>
              </div>
            )}
            
            <div className="mt-4 text-sm text-gray-500">
              <h4 className="font-medium mb-2">Nasıl Çalışır?</h4>
              <p>PDF karşılaştırma aracı, iki PDF dosyası arasındaki metin farklılıklarını analiz eder:</p>
              <ul className="list-disc pl-5 mt-2 space-y-1">
                <li>İki PDF yükledikten sonra, metin içeriği otomatik olarak çıkarılır</li>
                <li>Metin içeriği karşılaştırılarak farklılıklar vurgulanır</li>
                <li>Eklenen, çıkarılan ve değiştirilen metin bölümleri belirlenir</li>
                <li>Karşılaştırma sonuçları canlı olarak gösterilir</li>
              </ul>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Mobil görünümde alt çubuk */}
      {isMobile && (
        <MobileActionBar
          title="PDF Karşılaştırma"
          showSave={false}
          showDownload={false}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default PDFComparePage;