import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import * as pdfjsLib from 'pdfjs-dist';
import { 
  Loader2, 
  Upload, 
  Download, 
  Save, 
  FileText, 
  Stamp, 
  FilePenLine, 
  FileSignature, 
  LayoutGrid,
  Globe,
  Languages,
  FileImage,
  ImagePlus,
  Search,
  ChevronUp,
  ChevronDown,
  X,
  Plus
} from 'lucide-react';
import ReactPDFViewer from '@/components/ReactPDFViewer';
import TextEditor from '@/components/TextEditor';
import { PDFTextItem, updateTextItem, TextFormatting } from '@/lib/pdf-edit-utils';
import { jsPDF } from 'jspdf';
import MobileActionBar from '@/components/MobileActionBar';
import { useIsMobile } from "@/hooks/use-mobile";
import BackButton from '@/components/ui/back-button';
import { useLocation } from 'wouter';
import PageManagement from '@/components/PageManagement';
import FormSigningTools from '@/components/FormSigningTools';
import WatermarkTool from '@/components/WatermarkTool';
import TranslationTools from '@/components/TranslationTools';
import EnhancedPDFViewer from '@/components/EnhancedPDFViewer';
import ImageUpload from '@/components/ImageUpload';

const PDFEditPage: React.FC = () => {
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [selectedText, setSelectedText] = useState<string | null>(null);
  const [selectedItemIndex, setSelectedItemIndex] = useState<number | null>(null);
  const [selectedTextItem, setSelectedTextItem] = useState<PDFTextItem | null>(null);
  const [pdfTextItems, setPdfTextItems] = useState<PDFTextItem[]>([]);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("text-edit");
  const [hasWatermark, setHasWatermark] = useState<boolean>(false);
  const [extractedText, setExtractedText] = useState<string[]>([]);
  const [translatedText, setTranslatedText] = useState<string[]>([]);
  const { toast } = useToast();

  // PDF dosyası yüklendiğinde
  const handleFileUpload = (file: File) => {
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
      const fileUrl = URL.createObjectURL(file);
      setPdfUrl(fileUrl);
      setCurrentPage(1);
      
      // Metin içermeyen PDF için bilgilendirme
      toast({
        title: "PDF Yüklendi",
        description: `${file.name} dosyası başarıyla yüklendi. Eğer PDF içerisinde metin bulunamazsa, bir uyarı mesajı gösterilecektir.`,
        duration: 5000,
      });
    } else {
      toast({
        title: "Hata",
        description: "Lütfen geçerli bir PDF dosyası yükleyin.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  // Metin seçildiğinde
  const handleTextSelect = (text: string, itemIndex: number, textItem?: PDFTextItem) => {
    setSelectedText(text);
    setSelectedItemIndex(itemIndex);
    
    if (textItem) {
      setSelectedTextItem(textItem);
      // Eğer bu ilk seçilen öğe ise pdfTextItems dizisini başlat
      if (pdfTextItems.length === 0) {
        setPdfTextItems([textItem]);
      }
    }
  };

  // Metin güncellendiğinde
  const handleTextUpdate = (newText: string, itemIndex: number, formatting?: TextFormatting) => {
    if (selectedTextItem) {
      // Seçili öğeyi güncelle, biçimlendirme bilgilerini içerecek şekilde
      const updatedTextItem = { 
        ...selectedTextItem, 
        text: newText,
        ...(formatting && {
          fontSize: formatting.fontSize,
          fontFamily: formatting.fontFamily,
          fontColor: formatting.fontColor,
          textAlign: formatting.textAlign,
          fontWeight: formatting.fontWeight,
          fontStyle: formatting.fontStyle,
          textDecoration: formatting.textDecoration
        })
      };
      setSelectedTextItem(updatedTextItem);
      
      // pdfTextItems içindeki ilgili öğeyi güncelle
      const updatedItems = updateTextItem(pdfTextItems, itemIndex, newText, formatting);
      setPdfTextItems(updatedItems);
      
      toast({
        title: "Metin Güncellendi",
        description: "Seçilen metin ve biçimlendirme başarıyla değiştirildi.",
        duration: 3000,
      });
    }
  };

  // Metin düzenlemeyi iptal et
  const handleCancelEdit = () => {
    setSelectedText(null);
    setSelectedItemIndex(null);
    setSelectedTextItem(null);
  };

  // Düzenlenmiş PDF'i indir
  const handleSaveAsPDF = async () => {
    if (!pdfUrl || pdfTextItems.length === 0) {
      toast({
        title: "Hata",
        description: "Düzenlenecek bir PDF veya metin bulunamadı.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    try {
      setIsDownloading(true);
      
      // PDF oluştur
      const doc = new jsPDF();
      
      // Eski PDF'i yükle
      const pdfBytes = await fetch(pdfUrl).then(res => res.arrayBuffer());
      
      // PDF'in asıl boyutunu al
      let scale = 1;
      let width = 210; // A4 genişliği (mm)
      let height = 297; // A4 yüksekliği (mm)
      
      // Her sayfada farklı metinler için işlem yap
      const textItemsByPage: { [key: number]: PDFTextItem[] } = {};
      
      // Metinleri sayfalara göre grupla
      pdfTextItems.forEach(item => {
        if (!textItemsByPage[item.pageNumber]) {
          textItemsByPage[item.pageNumber] = [];
        }
        textItemsByPage[item.pageNumber].push(item);
      });
      
      // Her sayfayı işle
      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        if (pageNum > 1) {
          doc.addPage();
        }
        
        // Bu sayfadaki metinleri ekle
        const pageItems = textItemsByPage[pageNum] || [];
        
        pageItems.forEach(item => {
          // PDF koordinat sistemine çevir (y koordinatı alt kısımdan başlar)
          const x = item.x / scale;
          const y = height - (item.y / scale);
          
          // Font boyutunu ayarla
          const fontSize = item.fontSize || Math.round(item.height * 0.75);
          doc.setFontSize(fontSize);
          
          // Font ailesini ayarla
          try {
            if (item.fontFamily) {
              doc.setFont(item.fontFamily.toLowerCase());
            }
          } catch (e) {
            console.warn(`Font not supported: ${item.fontFamily}, using default`);
          }
          
          // Font rengini ayarla
          if (item.fontColor) {
            // Hex renk değerini RGB'ye çevir
            const hex = item.fontColor.replace('#', '');
            const r = parseInt(hex.substring(0, 2), 16);
            const g = parseInt(hex.substring(2, 4), 16);
            const b = parseInt(hex.substring(4, 6), 16);
            doc.setTextColor(r, g, b);
          } else {
            doc.setTextColor(0, 0, 0); // Varsayılan siyah
          }
          
          // Font stillerini ayarla
          let fontStyle = '';
          if (item.fontWeight === 'bold') fontStyle += 'bold';
          if (item.fontStyle === 'italic') fontStyle += 'italic';
          if (fontStyle) {
            doc.setFont(item.fontFamily?.toLowerCase() || 'helvetica', fontStyle);
          }
          
          // Text align ayarla (jsPDF'in desteklediği şekilde)
          let align: 'left' | 'center' | 'right' | 'justify' = 'left';
          if (item.textAlign && ['left', 'center', 'right', 'justify'].includes(item.textAlign)) {
            align = item.textAlign as 'left' | 'center' | 'right' | 'justify';
          }
          
          // Metni ekle
          doc.text(item.text, x, y, { align });
          
          // Altı çizili metin için
          if (item.textDecoration === 'underline') {
            const textWidth = doc.getTextWidth(item.text);
            const lineHeight = 0.5; // Çizgi kalınlığı
            doc.line(x, y + lineHeight, x + textWidth, y + lineHeight);
          }
          
          // Varsayılan değerlere geri dön
          doc.setTextColor(0, 0, 0);
          doc.setFontSize(12);
          doc.setFont('helvetica', 'normal');
        });
      }
      
      // PDF'i indir
      const pdfName = pdfFile ? pdfFile.name.replace('.pdf', '') + '-edited.pdf' : 'edited-document.pdf';
      doc.save(pdfName);
      
      toast({
        title: "PDF İndirildi",
        description: "Düzenlenmiş PDF başarıyla indirildi.",
        duration: 3000,
      });
    } catch (error) {
      console.error('PDF kaydetme hatası:', error);
      toast({
        title: "Hata",
        description: "PDF kaydedilirken bir hata oluştu.",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsDownloading(false);
    }
  };

  // PDF metnini çıkarma fonksiyonu
  const extractPdfText = useCallback(async (pdfUrl: string) => {
    try {
      setIsProcessing(true);
      toast({
        title: "Metin Çıkarılıyor",
        description: "PDF içeriğindeki metinler çıkarılıyor...",
      });

      // PDFJsLib'i yapılandır
      const loadingTask = pdfjsLib.getDocument(pdfUrl);
      const pdf = await loadingTask.promise;
      const numPages = pdf.numPages;
      
      const pageTexts: string[] = [];
      
      // Her sayfadan metni çıkar
      for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        
        pageTexts.push(pageText);
      }
      
      setExtractedText(pageTexts);
      toast({
        title: "Metin Çıkarıldı",
        description: `${pageTexts.length} sayfadan metin başarıyla çıkarıldı.`,
      });
      
      return pageTexts;
    } catch (error) {
      console.error("PDF metin çıkarma hatası:", error);
      toast({
        title: "Hata",
        description: "PDF içeriğindeki metinler çıkarılırken bir hata oluştu.",
        variant: "destructive",
      });
      return [];
    } finally {
      setIsProcessing(false);
    }
  }, [toast]);

  // PDF yüklendiğinde metni çıkar
  useEffect(() => {
    if (pdfUrl && activeTab === "translation") {
      extractPdfText(pdfUrl);
    }
  }, [pdfUrl, activeTab, extractPdfText]);

  // Sekme değiştiğinde ve çeviri sekmesi seçildiğinde metin çıkar
  useEffect(() => {
    if (activeTab === "translation" && pdfUrl && extractedText.length === 0) {
      extractPdfText(pdfUrl);
    }
  }, [activeTab, pdfUrl, extractedText.length, extractPdfText]);

  // Komponent kaldırıldığında URL'leri temizle
  useEffect(() => {
    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [pdfUrl]);

  // Sayfa silme işlemi
  const handlePageDelete = (pageNumber: number) => {
    setIsProcessing(true);
    try {
      toast({
        title: "Sayfa Siliniyor",
        description: `Sayfa ${pageNumber} siliniyor...`,
      });
      
      // Burada gerçek sayfa silme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Sayfa Silindi",
          description: `Sayfa ${pageNumber} başarıyla silindi.`,
        });
        setTotalPages(prev => Math.max(prev - 1, 1));
        setCurrentPage(prev => prev > 1 ? prev - 1 : 1);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Sayfa silme hatası:", error);
      toast({
        title: "Hata",
        description: "Sayfa silinemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Sayfa ekleme işlemi
  const handlePageAdd = (position: 'before' | 'after', sourcePage?: number) => {
    setIsProcessing(true);
    try {
      const targetPage = sourcePage || currentPage;
      toast({
        title: "Sayfa Ekleniyor",
        description: `Sayfa ${position === 'before' ? 'öncesine' : 'sonrasına'} yeni sayfa ekleniyor...`,
      });
      
      // Burada gerçek sayfa ekleme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Sayfa Eklendi",
          description: `Sayfa ${position === 'before' ? targetPage : targetPage + 1} eklendi.`,
        });
        setTotalPages(prev => prev + 1);
        setCurrentPage(position === 'before' ? targetPage : targetPage + 1);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Sayfa ekleme hatası:", error);
      toast({
        title: "Hata",
        description: "Sayfa eklenemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Sayfaları yeniden sıralama
  const handlePagesReorder = (fromPage: number, toPage: number) => {
    setIsProcessing(true);
    try {
      toast({
        title: "Sayfalar Yeniden Sıralanıyor",
        description: `Sayfa ${fromPage}, sayfa ${toPage} konumuna taşınıyor...`,
      });
      
      // Burada gerçek sayfa sıralama işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Sayfalar Yeniden Sıralandı",
          description: `Sayfa ${fromPage}, sayfa ${toPage} konumuna taşındı.`,
        });
        setCurrentPage(toPage);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Sayfa sıralama hatası:", error);
      toast({
        title: "Hata",
        description: "Sayfalar yeniden sıralanamadı.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Sayfa döndürme
  const handlePageRotate = (pageNumber: number, rotation: number) => {
    setIsProcessing(true);
    try {
      toast({
        title: "Sayfa Döndürülüyor",
        description: `Sayfa ${pageNumber}, ${rotation}° döndürülüyor...`,
      });
      
      // Burada gerçek sayfa döndürme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Sayfa Döndürüldü",
          description: `Sayfa ${pageNumber}, ${rotation}° döndürüldü.`,
        });
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Sayfa döndürme hatası:", error);
      toast({
        title: "Hata",
        description: "Sayfa döndürülemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Boş sayfa ekleme
  const handleBlankPageAdd = (position: 'start' | 'end' | 'after', afterPage?: number) => {
    setIsProcessing(true);
    try {
      let targetPosition = position === 'start' ? 1 : 
                           position === 'end' ? totalPages + 1 : 
                           (afterPage || currentPage) + 1;
      
      toast({
        title: "Boş Sayfa Ekleniyor",
        description: `${position === 'start' ? 'Başa' : position === 'end' ? 'Sona' : `Sayfa ${afterPage} sonrasına`} boş sayfa ekleniyor...`,
      });
      
      // Burada gerçek boş sayfa ekleme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Boş Sayfa Eklendi",
          description: `${position === 'start' ? 'Başa' : position === 'end' ? 'Sona' : `Sayfa ${afterPage} sonrasına`} boş sayfa eklendi.`,
        });
        setTotalPages(prev => prev + 1);
        setCurrentPage(targetPosition);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Boş sayfa ekleme hatası:", error);
      toast({
        title: "Hata",
        description: "Boş sayfa eklenemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Form alanı ekleme
  const handleAddFormField = (type: string, params: any) => {
    setIsProcessing(true);
    try {
      toast({
        title: "Form Alanı Ekleniyor",
        description: `"${params.name}" adlı form alanı ekleniyor...`,
      });
      
      // Burada gerçek form alanı ekleme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Form Alanı Eklendi",
          description: `"${params.name}" adlı form alanı eklendi.`,
        });
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Form alanı ekleme hatası:", error);
      toast({
        title: "Hata",
        description: "Form alanı eklenemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // İmza ekleme
  const handleAddSignature = (signatureData: string, position: { x: number, y: number, width: number, height: number }) => {
    setIsProcessing(true);
    try {
      toast({
        title: "İmza Ekleniyor",
        description: "İmza PDF'e ekleniyor...",
      });
      
      // Burada gerçek imza ekleme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "İmza Eklendi",
          description: "İmza başarıyla eklendi.",
        });
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("İmza ekleme hatası:", error);
      toast({
        title: "Hata",
        description: "İmza eklenemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Filigran ekleme
  const handleAddWatermark = (params: any) => {
    setIsProcessing(true);
    try {
      toast({
        title: "Filigran Ekleniyor",
        description: `"${params.text}" filigranı ekleniyor...`,
      });
      
      // Burada gerçek filigran ekleme işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Filigran Eklendi",
          description: `"${params.text}" filigranı eklendi.`,
        });
        setHasWatermark(true);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Filigran ekleme hatası:", error);
      toast({
        title: "Hata",
        description: "Filigran eklenemedi.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  // Filigran kaldırma
  const handleRemoveWatermark = () => {
    setIsProcessing(true);
    try {
      toast({
        title: "Filigran Kaldırılıyor",
        description: "Filigran kaldırılıyor...",
      });
      
      // Burada gerçek filigran kaldırma işlemleri yapılacak
      setTimeout(() => {
        toast({
          title: "Filigran Kaldırıldı",
          description: "Filigran başarıyla kaldırıldı.",
        });
        setHasWatermark(false);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error("Filigran kaldırma hatası:", error);
      toast({
        title: "Hata",
        description: "Filigran kaldırılamadı.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  const isMobile = useIsMobile();
  const [_, setLocation] = useLocation();

  return (
    <div className="container mx-auto px-4 py-8 pb-20">
      <div className="flex items-center justify-between mb-6">
        {!isMobile ? (
          <>
            <BackButton target="/" variant="outline" className="text-gray-600 hover:text-primary" />
            <h1 className="text-3xl font-bold">PDF Düzenleyici</h1>
            <div className="w-[100px]"></div>
          </>
        ) : (
          <h1 className="text-xl font-bold mx-auto">PDF Düzenleyici</h1>
        )}
      </div>
      
      <div className="mb-6">
        <Card className="p-4">
          <h2 className="text-xl font-semibold mb-4">PDF Yükle</h2>
          <Button 
            onClick={() => {
              const fileInput = document.createElement('input');
              fileInput.type = 'file';
              fileInput.accept = '.pdf';
              fileInput.onchange = (e) => {
                const files = (e.target as HTMLInputElement).files;
                if (files && files.length > 0) {
                  handleFileUpload(files[0]);
                }
              };
              fileInput.click();
            }}
            className="flex items-center gap-2"
          >
            <Upload className="h-4 w-4" />
            PDF Seç
          </Button>
          
          {pdfFile && (
            <div className="mt-2 text-sm text-gray-600">
              <p>Yüklenen dosya: {pdfFile.name}</p>
              <p>Boyut: {(pdfFile.size / 1024).toFixed(1)} KB</p>
            </div>
          )}
        </Card>
      </div>
      
      {pdfUrl ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Card className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">PDF Görüntüleyici</h2>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSaveAsPDF}
                  disabled={isDownloading}
                  className="flex items-center gap-2"
                >
                  {isDownloading ? (
                    <>
                      <span className="animate-spin">⏳</span>
                      İndiriliyor...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Düzenlenmiş PDF'i İndir
                    </>
                  )}
                </Button>
              </div>
              
              <div className="border rounded overflow-hidden">
                <ReactPDFViewer
                  pdfUrl={pdfUrl}
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={setCurrentPage}
                  onTextSelect={handleTextSelect}
                />
              </div>
              
              <div className="mt-4 flex justify-between items-center">
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Sayfa {currentPage} / {totalPages}</span>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                    disabled={currentPage <= 1}
                  >
                    Önceki
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                    disabled={currentPage >= totalPages}
                  >
                    Sonraki
                  </Button>
                </div>
              </div>
            </Card>
            
            {/* PDF Düzenleme Araçları - Sekmeli Yapı */}
            <Card className="p-4 mt-6">
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 w-full sm:gap-1 p-1 bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 rounded-xl shadow-md">
                  <TabsTrigger value="text-edit" className="flex items-center justify-center gap-2 py-3 rounded-lg transition-all hover:bg-blue-50 dark:hover:bg-blue-950">
                    <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    <span className="inline font-medium">Metin Ekleme</span>
                  </TabsTrigger>
                  <TabsTrigger value="form-sign" className="flex items-center justify-center gap-2 py-3 rounded-lg transition-all hover:bg-blue-50 dark:hover:bg-blue-950">
                    <FileSignature className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                    <span className="inline font-medium">Form/İmza</span>
                  </TabsTrigger>
                  <TabsTrigger value="watermark" className="flex items-center justify-center gap-2 py-3 rounded-lg transition-all hover:bg-blue-50 dark:hover:bg-blue-950">
                    <Stamp className="h-5 w-5 text-red-600 dark:text-red-400" />
                    <span className="inline font-medium">Filigran</span>
                  </TabsTrigger>
                </TabsList>
                
                {/* Metin Düzenleme Sekmesi */}
                <TabsContent value="text-edit" className="space-y-4 mt-4">
                  <TextEditor
                    selectedText={selectedText}
                    selectedItemIndex={selectedItemIndex}
                    onTextUpdate={handleTextUpdate}
                    onCancel={handleCancelEdit}
                  />
                  
                  {/* Düzenlenen metinlerin listesi */}
                  {pdfTextItems.length > 0 && (
                    <Card className="p-4 mt-4 border-dashed">
                      <h3 className="text-lg font-semibold mb-3">Düzenlenen Metinler</h3>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {pdfTextItems.filter(item => item.text !== selectedTextItem?.text).map((item, idx) => (
                          <div
                            key={idx}
                            className="p-2 border rounded flex flex-col hover:bg-gray-50"
                          >
                            <div className="text-sm text-gray-500">
                              Sayfa {item.pageNumber}, Öğe #{item.itemIndex + 1}
                            </div>
                            <div className="flex-1">{item.text}</div>
                          </div>
                        ))}
                      </div>
                    </Card>
                  )}
                </TabsContent>
                

                {/* Form ve İmza Sekmesi */}
                <TabsContent value="form-sign" className="mt-4">
                  <FormSigningTools 
                    onAddFormField={handleAddFormField}
                    onAddSignature={handleAddSignature}
                    currentPage={currentPage}
                    isProcessing={isProcessing}
                  />
                </TabsContent>
                
                {/* Filigran Sekmesi */}
                <TabsContent value="watermark" className="mt-4">
                  <WatermarkTool 
                    onAddWatermark={handleAddWatermark}
                    onRemoveWatermark={handleRemoveWatermark}
                    hasWatermark={hasWatermark}
                    isProcessing={isProcessing}
                  />
                </TabsContent>
                

              </Tabs>
            </Card>
          </div>
          
          <div>
            <Card className="p-4">
              <h3 className="text-xl font-semibold mb-4">Özellikler</h3>
              <div className="space-y-4">
                <div className="flex flex-col gap-2">
                  <div className="text-sm font-medium">PDF Bilgileri</div>
                  <div className="border rounded-md p-3 text-sm">
                    <p>Dosya: {pdfFile?.name}</p>
                    <p>Sayfa Sayısı: {totalPages}</p>
                    <p>Boyut: {pdfFile ? Math.round(pdfFile.size / 1024) : 0} KB</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-sm font-medium">Düzenleme İşlemleri</div>
                  <div className="grid grid-cols-3 sm:grid-cols-2 gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setActiveTab("text-edit")}
                      className="flex items-center justify-center"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Metin Düzenle
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setActiveTab("page-manage")}
                      className="flex items-center justify-center"
                    >
                      <LayoutGrid className="h-4 w-4 mr-2" />
                      Sayfa Yönetimi
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setActiveTab("form-sign")}
                      className="flex items-center justify-center"
                    >
                      <FileSignature className="h-4 w-4 mr-2" />
                      Form/İmza
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setActiveTab("watermark")}
                      className="flex items-center justify-center"
                    >
                      <Stamp className="h-4 w-4 mr-2" />
                      Filigran
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setActiveTab("translation")}
                      className="flex items-center justify-center"
                    >
                      <Globe className="h-4 w-4 mr-2" />
                      Çeviri
                    </Button>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <Button 
                    onClick={handleSaveAsPDF} 
                    className="w-full flex items-center justify-center"
                    disabled={isDownloading}
                  >
                    {isDownloading ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        İndiriliyor...
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4 mr-2" />
                        Düzenlenmiş PDF'i İndir
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
            
            <Card className="p-4 mt-4">
              <h3 className="text-xl font-semibold mb-4">Kullanım Kılavuzu</h3>
              <div className="space-y-3 text-sm">
                <div className="pb-2 border-b">
                  <p className="font-medium">Metin Düzenleme</p>
                  <p className="text-muted-foreground">PDF üzerindeki metinlere tıklayarak düzenleyebilirsiniz.</p>
                </div>
                <div className="pb-2 border-b">
                  <p className="font-medium">Sayfa İşlemleri</p>
                  <p className="text-muted-foreground">Sayfaları ekle, sil, düzenle veya yeniden sırala.</p>
                </div>
                <div className="pb-2 border-b">
                  <p className="font-medium">Form ve İmza</p>
                  <p className="text-muted-foreground">Form alanları ekle veya belgeyi imzala.</p>
                </div>
                <div className="pb-2 border-b">
                  <p className="font-medium">Filigran</p>
                  <p className="text-muted-foreground">Belgeye filigran ekle veya mevcut filigranı kaldır.</p>
                </div>
                <div>
                  <p className="font-medium">Çeviri ve Dil Araçları</p>
                  <p className="text-muted-foreground">PDF içeriğini çevir, metin çevirisi yap veya sözlük kullan.</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      ) : (
        <Card className="p-8 text-center">
          <p className="text-lg text-gray-600">
            Başlamak için bir PDF dosyası yükleyin.
          </p>
        </Card>
      )}

      {/* Mobil görünümde alt çubuk ekle - her durumda en azından geri butonu göster */}
      {isMobile && (
        <MobileActionBar
          title={pdfFile?.name || "PDF Düzenleme"}
          onSave={pdfUrl ? handleSaveAsPDF : undefined}
          onDownload={pdfUrl ? handleSaveAsPDF : undefined}
          showSave={Boolean(pdfUrl && pdfTextItems.length > 0)}
          showDownload={Boolean(pdfUrl && pdfTextItems.length > 0)}
          isSaving={isDownloading}
          onBack={() => setLocation("/mobile")}
        />
      )}
    </div>
  );
};

export default PDFEditPage;