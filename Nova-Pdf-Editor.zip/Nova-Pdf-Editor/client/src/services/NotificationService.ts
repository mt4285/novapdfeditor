import { PushNotifications, Token, PushNotificationSchema, ActionPerformed } from '@capacitor/push-notifications';

/**
 * Kapasitör Bildirimleri İçin Servis
 * Bu servis, uygulamanın bildirim izinlerini yönetir ve bildirim olaylarını dinler.
 */
class NotificationService {
  private initialized: boolean = false;
  private listeners: Array<(notification: PushNotificationSchema) => void> = [];
  
  /**
   * Servis başlatma işlemi
   * Bildirimleri kaydeder, izinleri kontrol eder ve olay dinleyicilerini ayarlar
   */
  async initialize(): Promise<boolean> {
    if (this.initialized) {
      return true;
    }
    
    try {
      // İzinleri kontrol et
      const permissionStatus = await PushNotifications.checkPermissions();
      
      if (permissionStatus.receive === 'prompt') {
        // İzin iste
        const requestResult = await PushNotifications.requestPermissions();
        if (requestResult.receive !== 'granted') {
          console.log('Bildirim izinleri reddedildi');
          return false;
        }
      } else if (permissionStatus.receive !== 'granted') {
        console.log('Bildirim izinleri yok');
        return false;
      }
      
      // Bildirimleri kaydet
      await PushNotifications.register();
      
      // Olay dinleyicilerini ayarla
      this.setupListeners();
      
      this.initialized = true;
      return true;
    } catch (error) {
      console.error('Bildirim servisi başlatılamadı:', error);
      return false;
    }
  }
  
  /**
   * Bildirim olaylarını dinle
   */
  private setupListeners() {
    // Token alındığında
    PushNotifications.addListener('registration', (token: Token) => {
      console.log('Bildirim token\'ı:', token.value);
    });
    
    // Bildirim alındığında
    PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
      console.log('Bildirim alındı:', notification);
      this.notifyListeners(notification);
    });
    
    // Bildirime tıklandığında
    PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
      console.log('Bildirim işlemi gerçekleştirildi:', action);
    });
  }
  
  /**
   * Bildirim dinleyicisi ekle
   * @param listener Bildirimleri dinleyecek fonksiyon
   */
  addNotificationListener(listener: (notification: PushNotificationSchema) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }
  
  /**
   * Tüm dinleyicilere bildirim gönder
   * @param notification Gönderilecek bildirim
   */
  private notifyListeners(notification: PushNotificationSchema) {
    this.listeners.forEach(listener => {
      try {
        listener(notification);
      } catch (error) {
        console.error('Bildirim dinleyicisi hatası:', error);
      }
    });
  }
  
  /**
   * Bildirim iznini kontrol et
   * @returns İzin durumu için bir Promise
   */
  async checkPermission(): Promise<boolean> {
    const permissionStatus = await PushNotifications.checkPermissions();
    return permissionStatus.receive === 'granted';
  }
  
  /**
   * Bildirim izni iste
   * @returns İzin sonucu için bir Promise
   */
  async requestPermission(): Promise<boolean> {
    const requestResult = await PushNotifications.requestPermissions();
    return requestResult.receive === 'granted';
  }
  
  /**
   * Alınan bildirimleri getir
   * @returns Alınan bildirimleri içeren bir Promise
   */
  async getDeliveredNotifications(): Promise<PushNotificationSchema[]> {
    const result = await PushNotifications.getDeliveredNotifications();
    return result.notifications;
  }
  
  /**
   * Servisin başlatılıp başlatılmadığını kontrol et
   * @returns Başlatma durumu
   */
  isInitialized(): boolean {
    return this.initialized;
  }
}

// Singleton instance
export const notificationService = new NotificationService();
export default notificationService;