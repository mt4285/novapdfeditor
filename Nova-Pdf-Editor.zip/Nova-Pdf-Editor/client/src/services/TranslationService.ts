/**
 * PDF metinleri için çeviri servisi
 * OpenAI API kullanarak metin çevirisi yapar
 */

import axios from "axios";

interface TranslationRequest {
  text: string;
  sourceLang: string;
  targetLang: string;
}

interface TranslationResponse {
  translatedText: string;
  detectedLanguage?: string;
}

interface DictionaryLookupRequest {
  word: string;
  sourceLang: string;
  targetLang: string;
}

interface DictionaryEntry {
  word: string;
  phonetic?: string;
  meanings: {
    partOfSpeech: string;
    definitions: {
      definition: string;
      example?: string;
      synonyms?: string[];
    }[];
  }[];
  translations?: {
    text: string;
    partOfSpeech?: string;
  }[];
}

class TranslationService {
  private apiUrl = "/api/translate";
  private dictionaryUrl = "/api/dictionary";
  
  /**
   * Metni belirtilen dile çevirir
   * @param text Çevrilecek metin
   * @param targetLang Hedef dil kodu (örn. "en", "tr", "fr")
   * @param sourceLang Kaynak dil kodu (otomatik algılama için boş bırakılabilir)
   * @returns Çevrilmiş metin Promise nesnesi
   */
  async translateText(
    text: string,
    targetLang: string,
    sourceLang: string = "auto"
  ): Promise<TranslationResponse> {
    try {
      const response = await axios.post<TranslationResponse>(this.apiUrl, {
        text,
        sourceLang,
        targetLang,
      });
      
      return response.data;
    } catch (error) {
      console.error("Çeviri hatası:", error);
      throw new Error("Metin çevrilemedi.");
    }
  }
  
  /**
   * PDF içeriğini belirtilen dile çevirir
   * @param pdfText PDF içeriğindeki metin dizisi
   * @param targetLang Hedef dil kodu (örn. "en", "tr", "fr")
   * @param sourceLang Kaynak dil kodu (otomatik algılama için boş bırakılabilir)
   * @returns Çevrilmiş metin dizisi Promise nesnesi
   */
  async translatePdfContent(
    pdfText: string[],
    targetLang: string,
    sourceLang: string = "auto"
  ): Promise<string[]> {
    try {
      // Büyük içerikler için metni parçalara ayırıp çeviriyoruz
      const translatedParts: string[] = [];
      
      // Her sayfayı ayrı ayrı çeviriyoruz
      for (const text of pdfText) {
        if (!text.trim()) {
          translatedParts.push("");
          continue;
        }
        
        const result = await this.translateText(text, targetLang, sourceLang);
        translatedParts.push(result.translatedText);
      }
      
      return translatedParts;
    } catch (error) {
      console.error("PDF çeviri hatası:", error);
      throw new Error("PDF içeriği çevrilemedi.");
    }
  }
  
  /**
   * Sözlükte kelime araması yapar
   * @param word Aranacak kelime
   * @param sourceLang Kaynak dil kodu
   * @param targetLang Hedef dil kodu (çeviri için)
   * @returns Kelime bilgileri ve çevirisi
   */
  async lookupWord(
    word: string,
    sourceLang: string = "en",
    targetLang: string = "tr"
  ): Promise<DictionaryEntry> {
    try {
      const response = await axios.post<DictionaryEntry>(this.dictionaryUrl, {
        word,
        sourceLang,
        targetLang,
      });
      
      return response.data;
    } catch (error) {
      console.error("Sözlük hatası:", error);
      throw new Error("Kelime bulunamadı.");
    }
  }
  
  /**
   * Metindeki belirli kelimelerin anlamlarını bulur
   * @param text Metin
   * @param sourceLang Kaynak dil kodu
   * @param targetLang Hedef dil kodu
   * @returns Bulunan kelimeler ve anlamları
   */
  async analyzeText(
    text: string,
    sourceLang: string = "en",
    targetLang: string = "tr"
  ): Promise<{word: string, entry: DictionaryEntry}[]> {
    try {
      // Basit bir kelime bölme işlemi (gerçek uygulamada daha gelişmiş NLP kullanılabilir)
      const words = text
        .replace(/[^\w\s']/g, '')
        .split(/\s+/)
        .filter(word => word.length > 3) // Kısa kelimeleri filtrele
        .filter((value, index, self) => self.indexOf(value) === index) // Tekrarları kaldır
        .slice(0, 10); // En fazla 10 kelime al (API yükünü azaltmak için)
      
      const results: {word: string, entry: DictionaryEntry}[] = [];
      
      for (const word of words) {
        try {
          const entry = await this.lookupWord(word, sourceLang, targetLang);
          results.push({ word, entry });
        } catch (error) {
          console.warn(`Kelime bulunamadı: ${word}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error("Metin analizi hatası:", error);
      throw new Error("Metin analiz edilemedi.");
    }
  }
  
  /**
   * Desteklenen dillerin listesini döndürür
   * @returns Dil kodları ve isimleri
   */
  getSupportedLanguages(): { code: string; name: string }[] {
    return [
      { code: "tr", name: "Türkçe" },
      { code: "en", name: "İngilizce" },
      { code: "fr", name: "Fransızca" },
      { code: "de", name: "Almanca" },
      { code: "es", name: "İspanyolca" },
      { code: "it", name: "İtalyanca" },
      { code: "ru", name: "Rusça" },
      { code: "zh", name: "Çince" },
      { code: "ja", name: "Japonca" },
      { code: "ar", name: "Arapça" },
      { code: "ko", name: "Korece" },
    ];
  }
}

// Singleton instance
export const translationService = new TranslationService();
export default translationService;