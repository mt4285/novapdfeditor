import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import i18n from "./lib/i18n"; // Initialize i18n

// Dil ayarını doğrudan localStorage'dan kontrol et
const storedLang = localStorage.getItem('i18nextLng');
if (storedLang) {
  i18n.changeLanguage(storedLang);
}

createRoot(document.getElementById("root")!).render(<App />);
