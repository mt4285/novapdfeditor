import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import PageNavigation from "./PageNavigation";
import { loadPDFFromUrl, renderPage } from "@/lib/pdf-utils";

// PDF worker için pdf-utils.ts dosyasındaki konfigürasyonu kullan
// Worker konfigürasyonu oradan alınıyor

interface PDFViewerProps {
  pdfUrl: string;
  currentPage: number;
  totalPages: number;
  zoomLevel: number;
  onPrevPage: () => void;
  onNextPage: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onDocumentLoadSuccess: (numPages: number) => void;
  onAddTextAtPosition: (x: number, y: number) => void;
}

const PDFViewer: React.FC<PDFViewerProps> = ({
  pdfUrl,
  currentPage,
  totalPages,
  zoomLevel,
  onPrevPage,
  onNextPage,
  onZoomIn,
  onZoomOut,
  onDocumentLoadSuccess,
  onAddTextAtPosition,
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<Error | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    console.log("PDF başarıyla yüklendi, sayfa sayısı:", numPages);
    setIsLoading(false);
    onDocumentLoadSuccess(numPages);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Call the callback with the click position
    onAddTextAtPosition(x, y);
  };

  const handleDocumentLoadError = (error: Error) => {
    console.error("PDF yükleme hatası:", error);
    console.log("PDF URL:", pdfUrl);
    setIsLoading(false);
    setLoadError(error);
  };
  
  // PDF.js ile doğrudan yükleme
  const canvasElementRef = useRef<HTMLCanvasElement>(null);
  
  // PDF değiştiğinde yükleme işlemi yapacak effect
  useEffect(() => {
    console.log("PDF Viewer render edildi. PDF URL:", pdfUrl);
    
    if (!pdfUrl) {
      return;
    }
    
    setIsLoading(true);
    setLoadError(null);
    
    // PDF yükleme işlemini başlat - doğrudan PDF.js global API'sini kullan
    const loadPdf = async () => {
      try {
        console.log("PDF yükleniyor...");
        
        // Doğrudan fetch ile PDF'i yükle
        const response = await fetch(pdfUrl);
        const arrayBuffer = await response.arrayBuffer();
        
        // PDF.js global API'sini kullan
        const pdf = await window.pdfjsLib.getDocument({data: arrayBuffer}).promise;
        console.log("PDF yüklendi, sayfa sayısı:", pdf.numPages);
        
        // Sayfa bilgisini güncelle
        onDocumentLoadSuccess(pdf.numPages);
        
        // İlk sayfayı hemen render et
        if (canvasElementRef.current) {
          const page = await pdf.getPage(1);
          const viewport = page.getViewport({scale: zoomLevel / 100});
          
          const canvas = canvasElementRef.current;
          const context = canvas.getContext('2d');
          
          canvas.height = viewport.height;
          canvas.width = viewport.width;
          
          console.log("Canvas boyutları:", canvas.width, canvas.height);
          
          await page.render({
            canvasContext: context,
            viewport: viewport
          }).promise;
          
          console.log("Sayfa başarıyla render edildi");
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error("PDF yükleme hatası:", error);
        setLoadError(error as Error);
        setIsLoading(false);
      }
    };
    
    loadPdf();
    
    return () => {
      console.log("PDF Viewer temizlendi");
    };
  }, [pdfUrl, onDocumentLoadSuccess, zoomLevel]);
  
  // Sayfa değiştiğinde veya zoom seviyesi değiştiğinde sayfayı render et
  useEffect(() => {
    if (isLoading || loadError || !pdfUrl || !canvasElementRef.current) {
      return;
    }
    
    console.log("Sayfa render ediliyor:", currentPage, "Zoom:", zoomLevel);
    
    const renderCurrentPage = async () => {
      try {
        // Doğrudan fetch ile PDF'i yükle
        const response = await fetch(pdfUrl);
        const arrayBuffer = await response.arrayBuffer();
        
        // PDF.js global API'sini kullan
        const pdf = await window.pdfjsLib.getDocument({data: arrayBuffer}).promise;
        
        if (canvasElementRef.current) {
          const page = await pdf.getPage(currentPage);
          const viewport = page.getViewport({scale: zoomLevel / 100});
          
          const canvas = canvasElementRef.current;
          const context = canvas.getContext('2d');
          
          canvas.height = viewport.height;
          canvas.width = viewport.width;
          
          await page.render({
            canvasContext: context,
            viewport: viewport
          }).promise;
          
          console.log("Sayfa başarıyla render edildi:", currentPage);
        }
      } catch (error) {
        console.error("Sayfa render hatası:", error);
      }
    };
    
    renderCurrentPage();
  }, [pdfUrl, currentPage, zoomLevel, isLoading, loadError]);

  return (
    <div>
      <PageNavigation
        currentPage={currentPage}
        totalPages={totalPages}
        zoomLevel={zoomLevel}
        onPrevPage={onPrevPage}
        onNextPage={onNextPage}
        onZoomIn={onZoomIn}
        onZoomOut={onZoomOut}
      />

      <div className="overflow-auto bg-gray-100 dark:bg-gray-800 rounded-lg p-4 max-h-[600px]">
        {isLoading && (
          <div className="flex flex-col justify-center items-center h-72">
            <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
            <span className="text-gray-600 dark:text-gray-300">PDF yükleniyor...</span>
          </div>
        )}

        {loadError && (
          <div className="flex flex-col justify-center items-center h-72 text-center">
            <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 rounded-lg p-4 max-w-md">
              <h3 className="text-lg font-semibold mb-2">PDF yüklenirken hata oluştu</h3>
              <p className="text-sm">{loadError.message || "Dosyayı yüklerken beklenmeyen bir hata oluştu. Lütfen tekrar deneyin."}</p>
            </div>
          </div>
        )}

        {!isLoading && !loadError && (
          <div 
            className="pdf-page mb-6 relative mx-auto"
            style={{ 
              width: `${zoomLevel}%`, 
              maxWidth: `${595 * (zoomLevel / 100)}px`
            }}
            ref={canvasRef}
            onClick={handleCanvasClick}
          >
            {/* Canvas tabanlı PDF görüntüleyici */}
            <canvas 
              ref={canvasElementRef} 
              className="border border-gray-200 dark:border-gray-700 rounded"
              style={{ width: '100%', height: 'auto' }}
            />
            
            {/* Page number indicator */}
            <div className="absolute bottom-2 right-2 bg-gray-100 dark:bg-gray-700 rounded-full px-3 py-1 text-xs font-medium text-gray-600 dark:text-gray-300">
              Sayfa {currentPage}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PDFViewer;
