import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";

interface HelpModalProps {
  trigger?: React.ReactNode;
}

const HelpModal: React.FC<HelpModalProps> = ({ trigger }) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="icon" className="text-gray-500 hover:text-primary">
            <HelpCircle className="h-6 w-6" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>PDF Düzenleyici Yardım</DialogTitle>
          <DialogDescription>
            PDF dosyalarını nasıl düzenleyeceğiniz hakkında bilgiler
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <h4 className="text-base font-medium text-gray-900 mb-2">Ana Özellikler</h4>
            <ul className="list-disc pl-5 space-y-2 text-sm text-gray-600">
              <li><strong>PDF Düzenleme:</strong> Metinlere tıklayarak düzenleme yapabilir, yeni metinler ekleyebilirsiniz.</li>
              <li><strong>OCR:</strong> Taranmış PDF belgelerindeki metinleri tanıyabilirsiniz.</li>
              <li><strong>Metin Arama:</strong> PDF içeriğinde anahtar kelimeler ile arama yapabilirsiniz.</li>
              <li><strong>Metaveri Düzenleme:</strong> PDF dosya bilgilerini güncelleyebilirsiniz.</li>
              <li><strong>PDF Karşılaştırma:</strong> İki PDF belgesini karşılaştırabilirsiniz.</li>
              <li><strong>Görsel İşlemler:</strong> PDF'e resim ekleyebilir, resimlerden PDF oluşturabilirsiniz.</li>
              <li><strong>PDF Birleştirme/Bölme:</strong> Birden fazla PDF'i birleştirebilir veya tek dosyayı bölebilirsiniz.</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-base font-medium text-gray-900 mb-2">Nasıl Kullanılır?</h4>
            <ol className="list-decimal pl-5 space-y-2 text-sm text-gray-600">
              <li><strong>PDF işlemi seçin:</strong> Ana sayfada yapmak istediğiniz işleme ait düğmeye tıklayın.</li>
              <li><strong>Dosya yükleyin:</strong> İşlem sayfasında "Dosya Seç" düğmesine tıklayarak:<br/>
                - PDF Düzenleme için: .pdf uzantılı dosya<br/>
                - Resimden PDF için: .jpg, .jpeg, .png uzantılı resim dosyaları<br/>
                - OCR için: Taranmış .pdf dosyaları
              </li>
              <li><strong>Düzenleme yapın:</strong> Seçtiğiniz işleme göre gerekli düzenlemeleri yapın.</li>
              <li><strong>Değişiklikleri kaydedin:</strong> "Kaydet" veya "İndir" düğmesiyle işlemi tamamlayın.</li>
              <li><strong>Mobil kullanım:</strong> Ekranın sağ üstündeki "Mobil Görünüm" düğmesini kullanarak mobil arayüze geçebilirsiniz.</li>
            </ol>
          </div>
          
          <div>
            <h4 className="text-base font-medium text-gray-900 mb-2">İpuçları ve Sınırlamalar</h4>
            <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
              <li>PDF düzenlemede en iyi sonuç için metin içeren PDF dosyaları kullanın, taranmış belgeler için önce OCR uygulayın.</li>
              <li>Resimden PDF oluşturmak için .jpg, .jpeg veya .png uzantılı dosyaları kullanabilirsiniz.</li>
              <li>Premium özellikler için abonelik satın almanız gerekebilir.</li>
              <li>Büyük boyutlu dosyalarda işlemler daha uzun sürebilir.</li>
            </ul>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => setOpen(false)}>Anladım</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default HelpModal;
