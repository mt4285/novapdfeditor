import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, ArrowUpRight, ArrowDownRight, X, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TextSearcherProps {
  documentText?: string[];
  isLoading?: boolean;
  currentPage: number;
  totalPages: number;
  onNavigateToPage?: (page: number) => void;
}

interface SearchResult {
  pageNumber: number;
  textIndex: number;
  text: string;
  excerpt: string;
}

const TextSearcher: React.FC<TextSearcherProps> = ({
  documentText = [],
  isLoading = false,
  currentPage,
  totalPages,
  onNavigateToPage,
}) => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [selectedResultIndex, setSelectedResultIndex] = useState(-1);
  const [isSearching, setIsSearching] = useState(false);

  // Arama yapmak için kullanılacak fonksiyon
  const performSearch = useCallback(() => {
    if (!searchQuery.trim() || documentText.length === 0) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    const results: SearchResult[] = [];
    const query = searchQuery.toLowerCase();

    // Her sayfada arama yap
    documentText.forEach((pageText, pageIndex) => {
      if (!pageText) return;

      const lowerPageText = pageText.toLowerCase();
      let lastIndex = 0;

      while (lastIndex !== -1) {
        lastIndex = lowerPageText.indexOf(query, lastIndex);

        if (lastIndex !== -1) {
          // Alıntı oluştur (bulunan metni içeren kısa bir parça)
          const startExcerpt = Math.max(0, lastIndex - 30);
          const endExcerpt = Math.min(pageText.length, lastIndex + query.length + 30);
          const excerpt = pageText.slice(startExcerpt, endExcerpt);

          results.push({
            pageNumber: pageIndex + 1, // Sayfa numarası 1'den başlar
            textIndex: lastIndex,
            text: pageText.slice(lastIndex, lastIndex + query.length),
            excerpt: '...' + excerpt + '...'
          });

          lastIndex += query.length;
        }
      }
    });

    setSearchResults(results);
    setSelectedResultIndex(results.length > 0 ? 0 : -1);

    // Sonuç sayısına göre bildirim göster
    if (results.length === 0) {
      toast({
        title: 'Sonuç bulunamadı',
        description: `"${searchQuery}" metni için eşleşme bulunamadı.`,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Arama tamamlandı',
        description: `"${searchQuery}" için ${results.length} sonuç bulundu.`,
      });
      
      // İlk sonucun sayfasına otomatik git
      if (results.length > 0 && onNavigateToPage) {
        onNavigateToPage(results[0].pageNumber);
      }
    }

    setIsSearching(false);
  }, [searchQuery, documentText, toast, onNavigateToPage]);

  // Enter tuşuna basıldığında arama yap
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      performSearch();
    }
  };

  // Önceki sonuca git
  const goToPreviousResult = () => {
    if (searchResults.length === 0) return;
    
    const newIndex = selectedResultIndex > 0 
      ? selectedResultIndex - 1 
      : searchResults.length - 1;
      
    setSelectedResultIndex(newIndex);
    
    if (onNavigateToPage) {
      onNavigateToPage(searchResults[newIndex].pageNumber);
    }
  };

  // Sonraki sonuca git
  const goToNextResult = () => {
    if (searchResults.length === 0) return;
    
    const newIndex = selectedResultIndex < searchResults.length - 1 
      ? selectedResultIndex + 1 
      : 0;
      
    setSelectedResultIndex(newIndex);
    
    if (onNavigateToPage) {
      onNavigateToPage(searchResults[newIndex].pageNumber);
    }
  };

  // Belirli bir sonuca git
  const goToResult = (index: number) => {
    if (index >= 0 && index < searchResults.length) {
      setSelectedResultIndex(index);
      
      if (onNavigateToPage) {
        onNavigateToPage(searchResults[index].pageNumber);
      }
    }
  };

  // Aramayı temizle
  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setSelectedResultIndex(-1);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Search className="h-5 w-5 mr-2" />
          Metin Arama
        </CardTitle>
        <CardDescription>
          PDF içerisinde metin arayın ve bulunan sonuçlar arasında gezinin
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Aranacak metni girin..."
              disabled={isLoading || isSearching || documentText.length === 0}
              className="pr-8"
            />
            {searchQuery && (
              <button 
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                onClick={clearSearch}
                aria-label="Aramayı temizle"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Button
            onClick={performSearch}
            disabled={isLoading || isSearching || !searchQuery.trim() || documentText.length === 0}
          >
            {isSearching ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">İçerik yükleniyor...</span>
          </div>
        ) : documentText.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <p>Arama yapmak için önce OCR işlemi çalıştırın veya bir PDF yükleyin.</p>
          </div>
        ) : (
          <>
            {searchResults.length > 0 && (
              <div className="mt-4">
                <h3 className="text-sm font-medium mb-2">
                  Sonuçlar ({selectedResultIndex + 1}/{searchResults.length})
                </h3>
                
                <div className="space-y-4">
                  {searchResults.slice(
                    Math.max(0, selectedResultIndex - 1),
                    Math.min(selectedResultIndex + 3, searchResults.length)
                  ).map((result, index) => {
                    const actualIndex = Math.max(0, selectedResultIndex - 1) + index;
                    const isSelected = actualIndex === selectedResultIndex;
                    
                    return (
                      <div 
                        key={`${result.pageNumber}-${result.textIndex}`}
                        className={`p-3 rounded-md text-sm ${
                          isSelected 
                            ? 'bg-primary/10 border border-primary/30' 
                            : 'bg-gray-100 dark:bg-gray-800'
                        }`}
                        onClick={() => goToResult(actualIndex)}
                      >
                        <div className="flex justify-between mb-1">
                          <Badge variant="outline">
                            Sayfa {result.pageNumber}
                          </Badge>
                          {isSelected && (
                            <Badge variant="secondary">
                              Seçili
                            </Badge>
                          )}
                        </div>
                        <p>
                          {result.excerpt.split(new RegExp(`(${searchQuery})`, 'i')).map((part, i) => 
                            part.toLowerCase() === searchQuery.toLowerCase() 
                              ? <mark key={i} className="bg-yellow-200 dark:bg-yellow-600">{part}</mark>
                              : part
                          )}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
      
      {searchResults.length > 0 && (
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={goToPreviousResult}
            disabled={isLoading || isSearching || searchResults.length === 0}
          >
            <ArrowUpRight className="h-4 w-4 mr-1" />
            Önceki
          </Button>
          
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {selectedResultIndex + 1} / {searchResults.length}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={goToNextResult}
            disabled={isLoading || isSearching || searchResults.length === 0}
          >
            Sonraki
            <ArrowDownRight className="h-4 w-4 ml-1" />
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default TextSearcher;