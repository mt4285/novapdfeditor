import React, { useState } from 'react';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Button } from '@/components/ui/button';
import { Card } from "@/components/ui/card";
import { Camera as CameraIcon, Upload, X, Check, Redo } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface CameraCaptureProps {
  onImageCapture: (imageData: string, fileName: string) => void;
  onError?: (error: Error) => void;
  allowGallery?: boolean;
  captureButtonText?: string;
  galleryButtonText?: string;
  className?: string;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({
  onImageCapture,
  onError,
  allowGallery = true,
  captureButtonText = "Kamera ile Tara",
  galleryButtonText = "Galeriden Seç",
  className
}) => {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  // İzinleri kontrol et ve kamerayı aç
  const checkPermissionsAndOpenCamera = async () => {
    try {
      setIsProcessing(true);
      
      // Kamera izinlerini kontrol et
      const permissionStatus = await Camera.checkPermissions();
      
      if (permissionStatus.camera !== 'granted') {
        // İzin yoksa, kullanıcıdan izin iste
        const requestResult = await Camera.requestPermissions({
          permissions: ['camera']
        });
        
        if (requestResult.camera !== 'granted') {
          throw new Error('Kamera izni reddedildi');
        }
      }
      
      // Kamera açık, fotoğraf çek
      await capturePhoto();
      
    } catch (error) {
      console.error('Kamera izin hatası:', error);
      toast({
        title: "Kamera Erişim Hatası",
        description: "Kameraya erişirken bir sorun oluştu. Lütfen cihaz izinlerini kontrol edin.",
        variant: "destructive",
      });
      
      if (onError && error instanceof Error) {
        onError(error);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  // Fotoğraf çek
  const capturePhoto = async () => {
    try {
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: true,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera,
        saveToGallery: false,
        correctOrientation: true,
      });
      
      if (image.dataUrl) {
        setCapturedImage(image.dataUrl);
      } else {
        throw new Error('Fotoğraf çekilemedi');
      }
    } catch (error) {
      console.error('Fotoğraf çekme hatası:', error);
      
      // Kullanıcı işlemi iptal ettiyse, hata gösterme
      if ((error as any)?.message === 'User cancelled photos app') {
        return;
      }
      
      toast({
        title: "Fotoğraf Çekme Hatası",
        description: "Fotoğraf çekilirken bir sorun oluştu.",
        variant: "destructive",
      });
      
      if (onError && error instanceof Error) {
        onError(error);
      }
    }
  };

  // Galeriden fotoğraf seç
  const selectFromGallery = async () => {
    try {
      setIsProcessing(true);
      
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: true,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Photos,
        correctOrientation: true,
      });
      
      if (image.dataUrl) {
        setCapturedImage(image.dataUrl);
      } else {
        throw new Error('Fotoğraf seçilemedi');
      }
    } catch (error) {
      console.error('Galeri seçim hatası:', error);
      
      // Kullanıcı işlemi iptal ettiyse, hata gösterme
      if ((error as any)?.message === 'User cancelled photos app') {
        return;
      }
      
      toast({
        title: "Fotoğraf Seçme Hatası",
        description: "Galeriden fotoğraf seçilirken bir sorun oluştu.",
        variant: "destructive",
      });
      
      if (onError && error instanceof Error) {
        onError(error);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  // Yakalanan fotoğrafı kabul et ve üst bileşene bildir
  const acceptImage = () => {
    if (capturedImage) {
      // Dosya adı oluştur: tarih-saat.jpg
      const now = new Date();
      const fileName = `scan-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}.jpg`;
      
      onImageCapture(capturedImage, fileName);
      
      // İşlem tamamlandıktan sonra görüntüyü temizle
      setCapturedImage(null);
    }
  };

  // Yakalanan fotoğrafı iptal et
  const cancelImage = () => {
    setCapturedImage(null);
  };

  return (
    <div className={`flex flex-col ${className}`}>
      {capturedImage ? (
        <Card className="p-4">
          <div className="space-y-4">
            <div className="relative">
              <img 
                src={capturedImage} 
                alt="Yakalanan Görüntü" 
                className="w-full rounded-md"
              />
              <div className="absolute top-2 right-2 flex gap-2">
                <Button 
                  size="icon" 
                  variant="destructive" 
                  className="h-8 w-8 rounded-full"
                  onClick={cancelImage}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button 
                variant="outline" 
                onClick={checkPermissionsAndOpenCamera}
                className="flex items-center gap-2"
                disabled={isProcessing}
              >
                <Redo className="h-4 w-4" />
                Yeniden Çek
              </Button>
              
              <Button 
                onClick={acceptImage}
                className="flex items-center gap-2"
                disabled={isProcessing}
              >
                <Check className="h-4 w-4" />
                Kabul Et
              </Button>
            </div>
          </div>
        </Card>
      ) : (
        <div className="flex flex-col md:flex-row gap-4">
          <Button 
            onClick={checkPermissionsAndOpenCamera}
            className="flex items-center gap-2 flex-1"
            disabled={isProcessing}
            size="lg"
          >
            <CameraIcon className="h-5 w-5" />
            {captureButtonText}
          </Button>
          
          {allowGallery && (
            <Button 
              variant="outline" 
              onClick={selectFromGallery}
              className="flex items-center gap-2 flex-1"
              disabled={isProcessing}
              size="lg"
            >
              <Upload className="h-5 w-5" />
              {galleryButtonText}
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default CameraCapture;