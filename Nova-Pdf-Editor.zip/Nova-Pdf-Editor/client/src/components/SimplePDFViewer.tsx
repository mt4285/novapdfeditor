import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import * as pdfjs from 'pdfjs-dist';

interface SimplePDFViewerProps {
  pdfUrl: string;
}

const SimplePDFViewer: React.FC<SimplePDFViewerProps> = ({ pdfUrl }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [pageCount, setPageCount] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!pdfUrl) return;

    const loadPDF = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Doğrudan PDF'i fetch ile al
        const response = await fetch(pdfUrl);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const arrayBuffer = await response.arrayBuffer();
        
        // Worker'ı yapılandır ve PDF'i doğrudan yükle
        console.log("Doğrudan PDF.js ile yüklemeyi dene");
        
        // Doğrudan import edilen pdfjs'i kullan (window.pdfjsLib yerine)
        pdfjs.GlobalWorkerOptions.workerSrc = "https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js";
        console.log("Worker URL ayarlandı:", pdfjs.GlobalWorkerOptions.workerSrc);
        
        // PDF'i yükle
        const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
        const pdfDoc = await loadingTask.promise;
        console.log("PDF başarıyla yüklendi, sayfa sayısı:", pdfDoc.numPages);
        
        setPageCount(pdfDoc.numPages);
        
        // İlk sayfayı canvas'a render et
        if (canvasRef.current) {
          try {
            console.log("PDF sayfası yükleniyor...");
            const page = await pdfDoc.getPage(1);
            console.log("Sayfa yüklendi, boyut hesaplanıyor...");
            
            // Viewport boyutunu ayarla
            const viewport = page.getViewport({ scale: 1.5 }); // Daha büyük görünüm için ölçeği artır
            console.log("Viewport boyutları:", viewport.width, viewport.height);
            
            const canvas = canvasRef.current;
            const context = canvas.getContext('2d');
            
            if (!context) {
              console.error("Canvas context alınamadı!");
              return;
            }
            
            // Canvas'ı temizle
            context.fillStyle = "#ffffff";
            context.fillRect(0, 0, canvas.width, canvas.height);
            
            // Canvas boyutunu viewport ile eşle
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            console.log("Canvas boyutları ayarlandı:", canvas.width, canvas.height);
            
            // Sayfa render işlemi
            console.log("Sayfa render ediliyor...");
            const renderTask = page.render({
              canvasContext: context,
              viewport: viewport
            });
            
            await renderTask.promise;
            console.log("Sayfa başarıyla render edildi!");
          } catch (renderError) {
            console.error("Sayfa render hatası:", renderError);
            throw renderError;
          }
        }
        
        setIsLoading(false);
      } catch (err) {
        console.error("PDF yükleme hatası:", err);
        setError(err instanceof Error ? err.message : "PDF yükleme hatası");
        setIsLoading(false);
      }
    };

    loadPDF();
  }, [pdfUrl]);

  return (
    <div className="flex flex-col items-center w-full">
      <h3 className="text-lg font-medium mb-4">Basit PDF Görüntüleyici</h3>
      
      {isLoading && (
        <div className="flex flex-col items-center p-8">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
          <span>PDF yükleniyor...</span>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4 w-full max-w-lg">
          <p className="font-semibold">Hata:</p>
          <p>{error}</p>
        </div>
      )}
      
      {!isLoading && !error && (
        <div className="flex flex-col items-center w-full">
          <div className="bg-gray-100 p-2 rounded mb-4">
            <p>Toplam sayfa sayısı: {pageCount}</p>
          </div>
          <div className="border border-gray-200 dark:border-gray-700 rounded shadow-lg bg-white p-2">
            <canvas 
              ref={canvasRef} 
              style={{ display: 'block', width: '100%', height: 'auto' }}
              className="max-w-full"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default SimplePDFViewer;