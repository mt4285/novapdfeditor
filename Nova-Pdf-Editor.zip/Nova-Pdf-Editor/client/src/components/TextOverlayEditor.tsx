import React, { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Bold, Italic, Underline } from "lucide-react";

interface TextOverlayItem {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  fontFamily: string;
  fontWeight: string;
  fontStyle: string;
  color: string;
  backgroundColor: string;
  opacity: number;
}

interface TextOverlayEditorProps {
  currentPage: number;
  pdfWidth: number;
  pdfHeight: number;
  onClickPosition?: (x: number, y: number) => void;
  selectedPosition?: { x: number; y: number } | null;
}

const TextOverlayEditor: React.FC<TextOverlayEditorProps> = ({
  currentPage,
  pdfWidth,
  pdfHeight,
  onClickPosition,
  selectedPosition,
}) => {
  const [overlayItems, setOverlayItems] = useState<TextOverlayItem[]>([]);
  const [editingItem, setEditingItem] = useState<TextOverlayItem | null>(null);
  const [newText, setNewText] = useState("");
  const [fontSize, setFontSize] = useState("16");
  const [fontFamily, setFontFamily] = useState("Arial");
  const [fontWeight, setFontWeight] = useState("normal");
  const [fontStyle, setFontStyle] = useState("normal");
  const [textColor, setTextColor] = useState("#000000");
  const [bgColor, setBgColor] = useState("transparent");
  const [opacity, setOpacity] = useState("1");
  
  const containerRef = useRef<HTMLDivElement>(null);

  // PDF sayfasının üzerine tıklandığında, metin ekleme için konum belirle
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (containerRef.current && onClickPosition) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * pdfWidth;
      const y = ((e.clientY - rect.top) / rect.height) * pdfHeight;
      onClickPosition(x, y);
    }
  };

  // Yeni metin ekle
  const handleAddText = () => {
    if (!newText.trim() || !selectedPosition) return;
    
    const newItem: TextOverlayItem = {
      id: `text-${Date.now()}`,
      text: newText,
      x: selectedPosition.x,
      y: selectedPosition.y,
      fontSize: parseInt(fontSize, 10),
      fontFamily,
      fontWeight,
      fontStyle,
      color: textColor,
      backgroundColor: bgColor,
      opacity: parseFloat(opacity),
    };
    
    setOverlayItems([...overlayItems, newItem]);
    setNewText("");
  };

  // Metin düzenle
  const handleEditItem = (item: TextOverlayItem) => {
    setEditingItem(item);
    setNewText(item.text);
    setFontSize(item.fontSize.toString());
    setFontFamily(item.fontFamily);
    setFontWeight(item.fontWeight);
    setFontStyle(item.fontStyle);
    setTextColor(item.color);
    setBgColor(item.backgroundColor);
    setOpacity(item.opacity.toString());
  };

  // Metin sil
  const handleDeleteItem = (id: string) => {
    setOverlayItems(overlayItems.filter(item => item.id !== id));
    if (editingItem && editingItem.id === id) {
      setEditingItem(null);
    }
  };

  // Düzenlenen metni güncelle
  const handleUpdateText = () => {
    if (!editingItem || !newText.trim()) return;
    
    const updatedItems = overlayItems.map(item => 
      item.id === editingItem.id 
        ? {
            ...item,
            text: newText,
            fontSize: parseInt(fontSize, 10),
            fontFamily,
            fontWeight,
            fontStyle,
            color: textColor,
            backgroundColor: bgColor,
            opacity: parseFloat(opacity),
          }
        : item
    );
    
    setOverlayItems(updatedItems);
    setEditingItem(null);
    setNewText("");
  };

  // Metin düzenlemeyi iptal et
  const handleCancelEdit = () => {
    setEditingItem(null);
    setNewText("");
  };

  // Güçlü metin stili
  const toggleBold = () => {
    setFontWeight(fontWeight === "bold" ? "normal" : "bold");
  };

  // İtalik metin stili
  const toggleItalic = () => {
    setFontStyle(fontStyle === "italic" ? "normal" : "italic");
  };

  return (
    <div className="relative w-full">
      {/* PDF Overlay Container */}
      <div 
        ref={containerRef}
        className="relative w-full overflow-hidden border border-gray-300 rounded"
        style={{ height: `${(pdfHeight / pdfWidth) * 100}%`, aspectRatio: `${pdfWidth} / ${pdfHeight}` }}
        onClick={handleCanvasClick}
      >
        {/* Metin Overlay Öğeleri */}
        {overlayItems.map(item => (
          <div
            key={item.id}
            className="absolute cursor-pointer select-none group"
            style={{
              left: `${(item.x / pdfWidth) * 100}%`,
              top: `${(item.y / pdfHeight) * 100}%`,
              fontSize: `${item.fontSize}px`,
              fontFamily: item.fontFamily,
              fontWeight: item.fontWeight,
              fontStyle: item.fontStyle,
              color: item.color,
              backgroundColor: item.backgroundColor,
              opacity: item.opacity,
              padding: '2px',
              maxWidth: '300px',
              wordWrap: 'break-word',
              zIndex: 10,
            }}
            onClick={(e) => {
              e.stopPropagation();
              handleEditItem(item);
            }}
          >
            {item.text}
            <button 
              className="absolute top-0 right-0 w-5 h-5 flex items-center justify-center bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteItem(item.id);
              }}
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>

      {/* Metin Düzenleme Paneli */}
      <Card className="p-4 mt-4">
        <h3 className="text-lg font-semibold mb-3">
          {editingItem ? "Metni Düzenle" : "Yeni Metin Ekle"}
        </h3>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="text-input">Metin</Label>
            <Textarea
              id="text-input"
              placeholder="Eklenecek veya düzenlenecek metin..."
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              className="mt-1"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Yazı Tipi</Label>
              <Select value={fontFamily} onValueChange={setFontFamily}>
                <SelectTrigger>
                  <SelectValue placeholder="Yazı tipi seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Arial">Arial</SelectItem>
                  <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                  <SelectItem value="Courier New">Courier New</SelectItem>
                  <SelectItem value="Georgia">Georgia</SelectItem>
                  <SelectItem value="Verdana">Verdana</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Yazı Boyutu</Label>
              <Select value={fontSize} onValueChange={setFontSize}>
                <SelectTrigger>
                  <SelectValue placeholder="Boyut seçin" />
                </SelectTrigger>
                <SelectContent>
                  {[8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48, 64].map(size => (
                    <SelectItem key={size} value={size.toString()}>{size}px</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Metin Stili</Label>
              <div className="flex mt-1 space-x-2">
                <Button 
                  type="button" 
                  variant={fontWeight === "bold" ? "default" : "outline"} 
                  size="icon"
                  onClick={toggleBold}
                >
                  <Bold className="h-4 w-4" />
                </Button>
                <Button 
                  type="button" 
                  variant={fontStyle === "italic" ? "default" : "outline"} 
                  size="icon"
                  onClick={toggleItalic}
                >
                  <Italic className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <Label>Metin Rengi</Label>
              <div className="flex items-center mt-1">
                <Input
                  type="color"
                  value={textColor}
                  onChange={(e) => setTextColor(e.target.value)}
                  className="w-full h-10 p-0"
                />
              </div>
            </div>
            
            <div>
              <Label>Arkaplan</Label>
              <div className="flex items-center mt-1">
                <Input
                  type="color"
                  value={bgColor === "transparent" ? "#ffffff" : bgColor}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="w-full h-10 p-0"
                />
                <Button 
                  type="button"
                  variant="outline"
                  size="sm"
                  className="ml-2"
                  onClick={() => setBgColor(bgColor === "transparent" ? "#ffffff" : "transparent")}
                >
                  {bgColor === "transparent" ? "Renkli" : "Şeffaf"}
                </Button>
              </div>
            </div>
          </div>
          
          <div>
            <Label>Saydamlık: {parseFloat(opacity) * 100}%</Label>
            <Input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={opacity}
              onChange={(e) => setOpacity(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="flex justify-end space-x-2 pt-2">
            {editingItem ? (
              <>
                <Button variant="outline" onClick={handleCancelEdit}>
                  İptal
                </Button>
                <Button onClick={handleUpdateText}>
                  Güncelle
                </Button>
              </>
            ) : (
              <Button 
                onClick={handleAddText}
                disabled={!newText.trim() || !selectedPosition}
              >
                Metin Ekle
              </Button>
            )}
          </div>
        </div>
      </Card>
      
      {/* Eklenen metinlerin listesi */}
      {overlayItems.length > 0 && (
        <Card className="p-4 mt-4">
          <h3 className="text-lg font-semibold mb-3">Sayfa {currentPage} Metinleri</h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {overlayItems.map(item => (
              <div 
                key={item.id} 
                className="p-2 border rounded flex justify-between items-center hover:bg-gray-50 cursor-pointer"
                onClick={() => handleEditItem(item)}
              >
                <div className="flex-1 truncate" style={{ 
                  fontFamily: item.fontFamily,
                  fontWeight: item.fontWeight,
                  fontStyle: item.fontStyle,
                  color: item.color
                }}>
                  {item.text}
                </div>
                <Button 
                  variant="destructive"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteItem(item.id);
                  }}
                >
                  Sil
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default TextOverlayEditor;