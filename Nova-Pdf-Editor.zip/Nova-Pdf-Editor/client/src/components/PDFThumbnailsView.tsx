import React, { useEffect, useRef, useState } from "react";
import { pdfjs } from '@/lib/pdf-config';
import { Loader2, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface PDFThumbnailsViewProps {
  pdfUrl: string;
  totalPages: number;
  currentPage: number;
  onPageChange: (pageNumber: number) => void;
  className?: string;
}

const PDFThumbnailsView: React.FC<PDFThumbnailsViewProps> = ({
  pdfUrl,
  totalPages,
  currentPage,
  onPageChange,
  className
}) => {
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewRotation, setViewRotation] = useState(0);
  const pdfDocumentRef = useRef<any>(null);

  useEffect(() => {
    if (!pdfUrl) return;

    const loadPDF = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // PDF'i yükle
        const loadingTask = pdfjs.getDocument(pdfUrl);
        const pdfDoc = await loadingTask.promise;
        pdfDocumentRef.current = pdfDoc;
        
        // İlk 10 sayfanın thumbnail'larını oluştur (performans için tüm sayfaları değil)
        await generateThumbnails(pdfDoc, Math.min(10, pdfDoc.numPages));
        
        setIsLoading(false);
      } catch (err) {
        console.error("PDF thumbnail yükleme hatası:", err);
        setError(err instanceof Error ? err.message : "PDF yükleme hatası");
        setIsLoading(false);
      }
    };

    loadPDF();
  }, [pdfUrl]);

  // Belirli bir aralıktaki sayfaların thumbnail'larını oluştur
  const generateThumbnails = async (pdfDoc: any, pageCount: number) => {
    const newThumbnails: string[] = Array(pageCount).fill('');
    
    for (let i = 1; i <= pageCount; i++) {
      try {
        const page = await pdfDoc.getPage(i);
        const viewport = page.getViewport({ scale: 0.2, rotation: viewRotation }); // Küçük ölçek kullan
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (!context) {
          console.error("Canvas context alınamadı");
          continue;
        }
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Sayfayı temizle
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        // Render et
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;
        
        // Thumbnail'ı data URL olarak kaydet
        const dataUrl = canvas.toDataURL('image/png');
        
        // State'i güncelle
        setThumbnails(prev => {
          const updated = [...prev];
          updated[i - 1] = dataUrl;
          return updated;
        });
      } catch (err) {
        console.error(`Sayfa ${i} thumbnail render hatası:`, err);
      }
    }
  };

  // Sayfa döndürme işlemi
  const rotatePage = async () => {
    // 90 derece artır (360 derece tamamlanınca sıfırla)
    const newRotation = (viewRotation + 90) % 360;
    setViewRotation(newRotation);
    
    // Thumbnail'ları yeniden oluştur
    if (pdfDocumentRef.current) {
      setThumbnails([]); // Thumbnail'ları temizle
      await generateThumbnails(pdfDocumentRef.current, Math.min(10, pdfDocumentRef.current.numPages));
    }
    
    // Sayfayı döndürme bilgisini ana bileşene ilet
    // Bu uygulamada rotatePage fonksiyonu henüz kullanılmıyor, gerekirse eklenecek
  };

  // Belirli sayfanın thumbnail'ını lazily yükle
  const loadThumbnailIfNeeded = async (pageNumber: number) => {
    if (pageNumber <= 0 || pageNumber > totalPages || !pdfDocumentRef.current) return;
    
    // Eğer thumbnail zaten yüklü değilse, yükle
    if (!thumbnails[pageNumber - 1] || thumbnails[pageNumber - 1] === '') {
      try {
        const page = await pdfDocumentRef.current.getPage(pageNumber);
        const viewport = page.getViewport({ scale: 0.2, rotation: viewRotation });
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (!context) {
          console.error("Canvas context alınamadı");
          return;
        }
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Sayfayı temizle
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        // Render et
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;
        
        // Thumbnail'ı data URL olarak kaydet
        const dataUrl = canvas.toDataURL('image/png');
        
        // State'i güncelle
        setThumbnails(prev => {
          const updated = [...prev];
          updated[pageNumber - 1] = dataUrl;
          return updated;
        });
      } catch (err) {
        console.error(`Sayfa ${pageNumber} thumbnail render hatası:`, err);
      }
    }
  };

  // Sayfa görünür olduğunda thumbnail'ı yükle
  const handleThumbnailVisible = (pageNumber: number) => {
    loadThumbnailIfNeeded(pageNumber);
  };

  return (
    <div className={cn("flex flex-col items-center w-full", className)}>
      <div className="flex justify-between items-center w-full mb-2">
        <h3 className="text-sm font-medium">Sayfalar</h3>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={rotatePage}
            >
              <RotateCw className="h-4 w-4" />
              <span className="sr-only">Sayfayı Döndür</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Sayfayı Döndür</p>
          </TooltipContent>
        </Tooltip>
      </div>
      
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-4">
          <Loader2 className="h-6 w-6 animate-spin text-primary mb-2" />
          <span className="text-xs">Sayfalar yükleniyor...</span>
        </div>
      ) : error ? (
        <div className="text-red-500 text-xs p-2">
          <p>Thumbnail yükleme hatası</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full overflow-y-auto max-h-64 p-2">
          {Array.from({ length: totalPages }).map((_, index) => {
            const pageNumber = index + 1;
            
            // Sayfa görünür olduğunda thumbnail'ı yükle
            if (Math.abs(pageNumber - currentPage) < 5) {
              handleThumbnailVisible(pageNumber);
            }
            
            return (
              <div
                key={`thumbnail-${pageNumber}`}
                className={`relative cursor-pointer border rounded-sm hover:border-primary transition-colors ${
                  currentPage === pageNumber ? 'border-primary border-2' : 'border-gray-200'
                }`}
                onClick={() => onPageChange(pageNumber)}
                onMouseEnter={() => loadThumbnailIfNeeded(pageNumber)}
              >
                {thumbnails[index] ? (
                  <img 
                    src={thumbnails[index]} 
                    alt={`Sayfa ${pageNumber}`} 
                    className="w-full h-auto"
                  />
                ) : (
                  <div className="aspect-[3/4] bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                    <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs text-center py-0.5">
                  {pageNumber}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PDFThumbnailsView;