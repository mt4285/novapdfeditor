import React from "react";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut } from "lucide-react";

interface PageNavigationProps {
  currentPage: number;
  totalPages: number;
  zoomLevel: number;
  onPrevPage: () => void;
  onNextPage: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
}

const PageNavigation: React.FC<PageNavigationProps> = ({
  currentPage,
  totalPages,
  zoomLevel,
  onPrevPage,
  onNextPage,
  onZoomIn,
  onZoomOut,
}) => {
  return (
    <div className="mb-4 flex justify-between items-center">
      <h2 className="text-lg font-medium text-gray-800">PDF Önizleme</h2>
      <div className="flex items-center space-x-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={onZoomOut}
          disabled={zoomLevel <= 50}
          className="p-1 text-gray-500 hover:text-gray-700"
        >
          <ZoomOut className="h-5 w-5" />
        </Button>
        <span className="text-sm text-gray-600">{zoomLevel}%</span>
        <Button
          variant="ghost"
          size="icon"
          onClick={onZoomIn}
          disabled={zoomLevel >= 200}
          className="p-1 text-gray-500 hover:text-gray-700"
        >
          <ZoomIn className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
};

export default PageNavigation;
