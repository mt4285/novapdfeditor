import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { FileUpload } from '@/components/ui/file-input';
import { pdfjs } from 'react-pdf';
import { Loader2, FileText, ArrowRight } from 'lucide-react';
import { extractTextContent } from '@/lib/pdf-utils';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { badgeVariants } from '@/components/ui/badge-variants';
import { useToast } from '@/hooks/use-toast';

interface PDFComparerProps {
  firstPdfBuffer?: ArrayBuffer;
  secondPdfBuffer?: ArrayBuffer;
}

const PDFComparer: React.FC<PDFComparerProps> = ({
  firstPdfBuffer,
  secondPdfBuffer
}) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [firstPdf, setFirstPdf] = useState<{buffer: ArrayBuffer, name: string} | null>(
    firstPdfBuffer ? {buffer: firstPdfBuffer, name: 'İlk PDF'} : null
  );
  const [secondPdf, setSecondPdf] = useState<{buffer: ArrayBuffer, name: string} | null>(
    secondPdfBuffer ? {buffer: secondPdfBuffer, name: 'İkinci PDF'} : null
  );
  const [diffResult, setDiffResult] = useState<{
    addedLines: string[];
    removedLines: string[];
    unchangedLines: string[];
    similarity: number;
  } | null>(null);

  // PDF dosyasını yükle
  const handleFirstPdfUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setFirstPdf({
          buffer: event.target.result as ArrayBuffer,
          name: file.name
        });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // İkinci PDF dosyasını yükle
  const handleSecondPdfUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSecondPdf({
          buffer: event.target.result as ArrayBuffer,
          name: file.name
        });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // PDF metinleri arasındaki farkları hesapla
  const comparePdfs = async () => {
    if (!firstPdf || !secondPdf) {
      toast({
        title: 'Hata',
        description: 'Karşılaştırma için iki PDF dosyası da gereklidir',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      // İki PDF'den metin içeriğini çıkar
      const firstText = await extractPdfText(firstPdf.buffer);
      const secondText = await extractPdfText(secondPdf.buffer);

      // Metin içeriklerini satırlara böl
      const firstLines = firstText.split('\\n').filter(line => line.trim() !== '');
      const secondLines = secondText.split('\\n').filter(line => line.trim() !== '');

      // Basit bir diff algoritması 
      const result = compareTextLines(firstLines, secondLines);
      setDiffResult(result);

      toast({
        title: 'Karşılaştırma tamamlandı',
        description: `Benzerlik oranı: %${Math.round(result.similarity * 100)}`,
      });
    } catch (error) {
      console.error('PDF karşılaştırma hatası:', error);
      toast({
        title: 'Karşılaştırma hatası',
        description: 'PDF dosyaları karşılaştırılırken bir hata oluştu',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // PDF'den metin çıkar
  const extractPdfText = async (pdfBuffer: ArrayBuffer): Promise<string> => {
    try {
      const pdf = await pdfjs.getDocument(pdfBuffer).promise;
      let fullText = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        const text = content.items.map((item: any) => item.str).join(' ');
        fullText += text + '\\n';
      }

      return fullText;
    } catch (error) {
      console.error('PDF metin çıkarma hatası:', error);
      throw new Error('PDF dosyasından metin çıkarılamadı');
    }
  };

  // İki metin dizisi arasındaki farkları hesapla
  const compareTextLines = (firstLines: string[], secondLines: string[]): {
    addedLines: string[];
    removedLines: string[];
    unchangedLines: string[];
    similarity: number;
  } => {
    const addedLines: string[] = [];
    const removedLines: string[] = [];
    const unchangedLines: string[] = [];

    // Birinci dokümandan ikinci dokümana eklenen ve çıkarılan satırları bul
    const firstSet = new Set(firstLines);
    const secondSet = new Set(secondLines);

    // Ortak satırları bul
    firstLines.forEach(line => {
      if (secondSet.has(line)) {
        unchangedLines.push(line);
      } else {
        removedLines.push(line);
      }
    });

    // Eklenen satırları bul
    secondLines.forEach(line => {
      if (!firstSet.has(line)) {
        addedLines.push(line);
      }
    });

    // Benzerlik oranını hesapla
    const totalUniqueLines = new Set([...firstLines, ...secondLines]).size;
    const similarLines = unchangedLines.length;
    const similarity = totalUniqueLines > 0 ? similarLines / totalUniqueLines : 0;

    return {
      addedLines,
      removedLines,
      unchangedLines,
      similarity
    };
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          PDF Karşılaştırma
        </CardTitle>
        <CardDescription>
          İki PDF dosyasını karşılaştırarak aralarındaki farkları görün
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="text-sm font-medium mb-2">İlk PDF</h3>
            {firstPdf ? (
              <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-md">
                <p className="text-sm font-medium truncate">{firstPdf.name}</p>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="mt-1 h-7 text-xs"
                  onClick={() => setFirstPdf(null)}
                >
                  Değiştir
                </Button>
              </div>
            ) : (
              <div className="flex flex-col border border-dashed border-gray-300 rounded-md p-4 items-center justify-center">
                <FileUpload
                  onFileSelected={handleFirstPdfUpload}
                  acceptedFileTypes={['application/pdf']}
                >
                  <Button variant="outline" size="sm">
                    PDF Seç
                  </Button>
                </FileUpload>
              </div>
            )}
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">İkinci PDF</h3>
            {secondPdf ? (
              <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-md">
                <p className="text-sm font-medium truncate">{secondPdf.name}</p>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="mt-1 h-7 text-xs"
                  onClick={() => setSecondPdf(null)}
                >
                  Değiştir
                </Button>
              </div>
            ) : (
              <div className="flex flex-col border border-dashed border-gray-300 rounded-md p-4 items-center justify-center">
                <FileUpload
                  onFileSelected={handleSecondPdfUpload}
                  acceptedFileTypes={['application/pdf']}
                >
                  <Button variant="outline" size="sm">
                    PDF Seç
                  </Button>
                </FileUpload>
              </div>
            )}
          </div>
        </div>
        
        <Button 
          className="w-full"
          onClick={comparePdfs}
          disabled={!firstPdf || !secondPdf || isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Karşılaştırılıyor...
            </>
          ) : (
            <>
              <ArrowRight className="h-4 w-4 mr-2" />
              PDF'leri Karşılaştır
            </>
          )}
        </Button>
        
        {diffResult && (
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium">Karşılaştırma Sonuçları</h3>
              <div className={cn(
                badgeVariants({ variant: 
                  diffResult.similarity > 0.8 ? "success" : 
                  diffResult.similarity > 0.5 ? "warning" : 
                  "destructive"
                })
              )}>
                Benzerlik: %{Math.round(diffResult.similarity * 100)}
              </div>
            </div>
            
            <Tabs defaultValue="added">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="added">
                  Eklenen <Badge variant="outline" className="ml-1">{diffResult.addedLines.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="removed">
                  Çıkarılan <Badge variant="outline" className="ml-1">{diffResult.removedLines.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="unchanged">
                  Ortak <Badge variant="outline" className="ml-1">{diffResult.unchangedLines.length}</Badge>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="added" className="max-h-60 overflow-y-auto">
                {diffResult.addedLines.length === 0 ? (
                  <Alert>
                    <AlertDescription>İkinci PDF'de eklenen içerik bulunamadı.</AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-1 p-2">
                    {diffResult.addedLines.map((line, index) => (
                      <div key={index} className="p-2 bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-900 rounded-md">
                        <p className="text-sm text-green-800 dark:text-green-300">+ {line}</p>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="removed" className="max-h-60 overflow-y-auto">
                {diffResult.removedLines.length === 0 ? (
                  <Alert>
                    <AlertDescription>İlk PDF'den çıkarılan içerik bulunamadı.</AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-1 p-2">
                    {diffResult.removedLines.map((line, index) => (
                      <div key={index} className="p-2 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900 rounded-md">
                        <p className="text-sm text-red-800 dark:text-red-300">- {line}</p>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="unchanged" className="max-h-60 overflow-y-auto">
                {diffResult.unchangedLines.length === 0 ? (
                  <Alert>
                    <AlertDescription>İki PDF arasında ortak içerik bulunamadı.</AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-1 p-2">
                    {diffResult.unchangedLines.map((line, index) => (
                      <div key={index} className="p-2 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-md">
                        <p className="text-sm text-gray-800 dark:text-gray-300">{line}</p>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between text-xs text-muted-foreground">
        <span>PDF'ler metin içeriği üzerinden karşılaştırılır</span>
      </CardFooter>
    </Card>
  );
};

export default PDFComparer;