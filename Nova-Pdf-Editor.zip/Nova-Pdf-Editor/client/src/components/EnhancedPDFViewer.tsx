import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, ZoomIn, ZoomOut, Maximize2, Download, Printer, Languages, Globe } from "lucide-react";
import { pdfjs } from '@/lib/pdf-config';
import PDFThumbnailsView from "./PDFThumbnailsView";
import PDFPageNavigator from "./PDFPageNavigator";

interface EnhancedPDFViewerProps {
  pdfUrl: string;
  currentPage: number;
  totalPages: number;
  onPageChange: (pageNumber: number) => void;
  onTotalPagesChange?: (totalPages: number) => void;
  onPrint?: () => void;
  onDownload?: () => void;
  pdfName?: string;
  className?: string;
  onTextSelect?: (text: string) => void;
}

const EnhancedPDFViewer: React.FC<EnhancedPDFViewerProps> = ({
  pdfUrl,
  currentPage,
  totalPages,
  onPageChange,
  onTotalPagesChange,
  onPrint,
  onDownload,
  pdfName,
  className,
  onTextSelect
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1.0);
  const [rotation, setRotation] = useState(0);
  const [pdfDocument, setPdfDocument] = useState<any>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const objectRef = useRef<HTMLObjectElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [displayMode, setDisplayMode] = useState<'canvas' | 'object' | 'iframe'>('canvas');
  const [pdfDimensions, setPdfDimensions] = useState<{width: number, height: number}>({width: 0, height: 0});
  const [selectedText, setSelectedText] = useState<string>("");

  // PDF'i yükle
  useEffect(() => {
    if (!pdfUrl) return;

    const loadPDF = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // PDF'i yükle
        const loadingTask = pdfjs.getDocument(pdfUrl);
        const pdfDoc = await loadingTask.promise;
        
        console.log("PDF yükleme başarılı, sayfa sayısı:", pdfDoc.numPages);
        setPdfDocument(pdfDoc);
        
        // Toplam sayfa sayısını güncelle
        if (onTotalPagesChange && totalPages !== pdfDoc.numPages) {
          onTotalPagesChange(pdfDoc.numPages);
        }

        setIsLoading(false);
      } catch (err) {
        console.error("PDF yükleme hatası:", err);
        setError(err instanceof Error ? err.message : "PDF yükleme hatası");
        setIsLoading(false);
        
        // Yükleme başarısız olduğunda object veya iframe görünümüne geç
        setDisplayMode('object');
      }
    };

    loadPDF();
  }, [pdfUrl, onTotalPagesChange]);

  // Metin seçme işlemi
  useEffect(() => {
    const handleTextSelection = () => {
      const selection = window.getSelection();
      if (selection && selection.toString().trim()) {
        setSelectedText(selection.toString().trim());
        
        // Seçim metin callback'i varsa çağır
        if (onTextSelect) {
          onTextSelect(selection.toString().trim());
        }
      }
    };

    // Olay dinleyiciyi ekle
    document.addEventListener('mouseup', handleTextSelection);
    document.addEventListener('touchend', handleTextSelection);

    // Cleanup
    return () => {
      document.removeEventListener('mouseup', handleTextSelection);
      document.removeEventListener('touchend', handleTextSelection);
    };
  }, [onTextSelect]);

  // Geçerli sayfayı render et (Canvas modu için)
  useEffect(() => {
    if (!pdfDocument || !canvasRef.current || isLoading || displayMode !== 'canvas') return;

    const renderPage = async () => {
      try {
        const page = await pdfDocument.getPage(currentPage);
        
        const canvas = canvasRef.current;
        if (!canvas) {
          console.error("Canvas referansı alınamadı!");
          return;
        }
        
        const context = canvas.getContext('2d');
        if (!context) {
          console.error("Canvas context alınamadı!");
          return;
        }
        
        // Sayfa görünümünü ayarla
        const viewport = page.getViewport({ scale: zoom, rotation: rotation });
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        // Sayfayı temizle
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        // Render et
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;
        
        // PDF boyutlarını ayarla
        setPdfDimensions({
          width: viewport.width,
          height: viewport.height
        });
        
        console.log("Sayfa render edildi:", currentPage);
      } catch (err) {
        console.error("Sayfa render hatası:", err);
        // Canvas render başarısız olduğunda object veya iframe moduna geç
        setDisplayMode('object');
      }
    };

    renderPage();
  }, [pdfDocument, currentPage, isLoading, zoom, rotation, displayMode]);

  // Object ve iframe element'lerin hata kontrolü
  useEffect(() => {
    if (!pdfUrl || displayMode !== 'object') return;
    
    const checkObjectViewer = () => {
      const objectElement = objectRef.current;
      const iframeElement = iframeRef.current;
      
      if (objectElement) {
        // Hata durumunda iframe'e geç
        objectElement.onerror = () => {
          console.log("Object yüklenemedi, iframe'e geçiliyor");
          setDisplayMode('iframe');
        };
        
        // Yükleme tamamlandı
        objectElement.onload = () => {
          console.log("Object PDF görüntüleyici yüklendi");
        };
      }
      
      if (iframeElement) {
        iframeElement.onerror = () => {
          console.log("iframe yüklenemedi");
        };
        
        iframeElement.onload = () => {
          console.log("iframe PDF görüntüleyici yüklendi");
        };
      }
    };
    
    checkObjectViewer();
  }, [pdfUrl, displayMode]);

  // Yakınlaştırma/uzaklaştırma
  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.2, 3.0));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.2, 0.5));
  };

  const handleResetZoom = () => {
    setZoom(1.0);
  };

  // Sayfa döndürme
  const handleRotate = (newRotation: number) => {
    setRotation(newRotation);
  };

  // Yazdırma işlemi
  const handlePrint = () => {
    if (onPrint) {
      onPrint();
    } else if (pdfUrl) {
      // Varsayılan yazdırma davranışı: PDF'i yeni sekmede aç
      const pdfWindow = window.open(pdfUrl, '_blank');
      if (pdfWindow) {
        setTimeout(() => {
          pdfWindow.print();
        }, 1000);
      }
    }
  };

  // İndirme işlemi
  const handleDownload = () => {
    if (onDownload) {
      onDownload();
    } else if (pdfUrl) {
      // Varsayılan indirme davranışı
      const link = document.createElement('a');
      link.href = pdfUrl;
      link.download = pdfName || 'document.pdf';
      link.target = '_blank';
      link.click();
    }
  };

  return (
    <div className={`flex flex-col md:flex-row gap-4 w-full ${className}`}>
      {/* Thumbnail görünümü (mobil cihazlarda gizli) */}
      <div className="hidden md:block w-48">
        <PDFThumbnailsView
          pdfUrl={pdfUrl}
          totalPages={totalPages}
          currentPage={currentPage}
          onPageChange={onPageChange}
          className="border rounded-md p-2"
        />
      </div>
      
      {/* Ana PDF görüntüleyici */}
      <div className="flex-1 flex flex-col">
        {/* Sayfa navigasyonu */}
        <PDFPageNavigator
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={onPageChange}
          onRotate={handleRotate}
          currentRotation={rotation}
          className="mb-2"
        />
        
        {/* Görüntüleyici container */}
        <div className="relative border border-gray-200 dark:border-gray-700 rounded-lg overflow-auto bg-white p-2 mb-2">
          {isLoading && (
            <div className="flex flex-col items-center justify-center min-h-[400px]">
              <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
              <span>PDF yükleniyor...</span>
            </div>
          )}
          
          {error && (
            <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4">
              <p className="font-semibold">Hata:</p>
              <p>{error}</p>
              <p className="mt-2 text-sm">
                PDF görüntüleyici çalışmıyor. Alternatif görüntüleyici deneyebilir veya dosyayı indirebilirsiniz:
              </p>
              <div className="flex mt-2 gap-2">
                <Button size="sm" variant="outline" onClick={handleDownload}>
                  İndir
                </Button>
                <Button size="sm" variant="outline" onClick={() => setDisplayMode('object')}>
                  Alternatif Görüntüleyici
                </Button>
              </div>
            </div>
          )}
          
          {/* Canvas ile PDF render (varsayılan ve interaktif mod) */}
          {displayMode === 'canvas' && (
            <div 
              ref={canvasContainerRef}
              className="flex justify-center"
              style={{
                transform: `scale(${zoom})`,
                transformOrigin: 'center top',
                transition: 'transform 0.2s ease',
              }}
            >
              <canvas 
                ref={canvasRef}
                className={`max-w-full mx-auto ${isLoading ? 'hidden' : 'block'}`}
              />
            </div>
          )}
          
          {/* Object element ile PDF render (alternatif mod) */}
          {displayMode === 'object' && (
            <div className="relative h-[600px]">
              <object
                ref={objectRef}
                data={`${pdfUrl}#page=${currentPage}&view=FitH&zoom=${zoom * 100}`}
                type="application/pdf"
                title="PDF Görüntüleyici"
                className="w-full h-full"
              >
                <div className="p-4 text-center">
                  <p>PDF görüntüleyici yüklenemedi veya PDF dosyası açılamadı.</p>
                  <div className="flex justify-center mt-4 gap-2">
                    <Button size="sm" variant="outline" onClick={handleDownload}>
                      İndir
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setDisplayMode('iframe')}>
                      Alternatif Görüntüleyici
                    </Button>
                  </div>
                </div>
              </object>
            </div>
          )}
          
          {/* iframe element ile PDF render (yedek mod) */}
          {displayMode === 'iframe' && (
            <div className="relative h-[600px]">
              <iframe 
                ref={iframeRef}
                src={`${pdfUrl}#page=${currentPage}&view=FitH&zoom=${zoom * 100}`}
                className="w-full h-full"
                title="PDF Yedek Görüntüleyici"
              />
            </div>
          )}
          
          {/* Yakınlaştırma/uzaklaştırma kontrolleri */}
          {displayMode === 'canvas' && (
            <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 flex flex-col">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomIn}
                className="h-8 w-8"
                title="Yakınlaştır"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleResetZoom}
                className="h-8 w-8"
                title="Varsayılan Boyut"
              >
                <Maximize2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleZoomOut}
                className="h-8 w-8"
                title="Uzaklaştır"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        
        {/* Seçili metin gösterimi ve çeviri butonu */}
        {selectedText && (
          <div className="mb-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-800 space-y-2">
            <div className="flex justify-between items-center">
              <h3 className="font-medium">Seçili Metin:</h3>
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-1"
                onClick={() => setSelectedText("")}
              >
                Temizle
              </Button>
            </div>
            <p className="text-gray-700 dark:text-gray-300 text-sm border p-2 rounded bg-white dark:bg-gray-900">
              {selectedText.length > 150 ? selectedText.substring(0, 150) + "..." : selectedText}
            </p>
            <div className="flex justify-between">
              <div className="space-x-2">
                <Button
                  variant="default"
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => {
                    if (!onTextSelect) return;
                    onTextSelect(selectedText);
                  }}
                >
                  <Globe className="h-4 w-4" />
                  Çeviri Yap
                </Button>
              </div>
              <span className="text-xs text-gray-500 flex items-center italic">
                <Languages className="h-3 w-3 mr-1 inline" />
                Pro Özelliği - Bir deneme hakkınız var
              </span>
            </div>
          </div>
        )}

        {/* Alt aksiyon butonları */}
        <div className="flex justify-end gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            onClick={handlePrint}
          >
            <Printer className="h-4 w-4" />
            Yazdır
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
            İndir
          </Button>
        </div>
        
        {/* Mobil cihazlarda küçük thumbnail görünümü */}
        <div className="md:hidden mt-4">
          <PDFThumbnailsView
            pdfUrl={pdfUrl}
            totalPages={totalPages}
            currentPage={currentPage}
            onPageChange={onPageChange}
            className="border rounded-md p-2"
          />
        </div>
      </div>
    </div>
  );
};

export default EnhancedPDFViewer;