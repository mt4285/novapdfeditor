import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { pdfjs } from '@/lib/pdf-config';
import TextOverlayEditor from "./TextOverlayEditor";

interface InteractivePDFViewerProps {
  pdfUrl: string;
  currentPage: number;
  totalPages?: number; 
  onPageChange?: (pageNumber: number) => void;
  onClickPosition?: (x: number, y: number) => void;
  enableTextOverlay?: boolean;
}

const InteractivePDFViewer: React.FC<InteractivePDFViewerProps> = ({ 
  pdfUrl, 
  currentPage, 
  totalPages = 1, 
  onPageChange,
  onClickPosition,
  enableTextOverlay = false
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pageCount, setPageCount] = useState(totalPages);
  const [pdfDocument, setPdfDocument] = useState<any>(null);
  const [selectedPosition, setSelectedPosition] = useState<{x: number, y: number} | null>(null);
  const [pdfDimensions, setPdfDimensions] = useState<{width: number, height: number}>({width: 0, height: 0});
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);

  // PDF'i yükle
  useEffect(() => {
    if (!pdfUrl) return;

    const loadPDF = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Worker yapılandırması pdf-config.ts içinde merkezi olarak yapılıyor
        // Bu satırı çıkarıyoruz çünkü import ettiğimiz pdfjs içinde worker zaten ayarlanmış
        
        // PDF'i yükle
        const loadingTask = pdfjs.getDocument(pdfUrl);
        const pdfDoc = await loadingTask.promise;
        
        console.log("PDF yükleme başarılı, sayfa sayısı:", pdfDoc.numPages);
        setPageCount(pdfDoc.numPages);
        setPdfDocument(pdfDoc);
        
        if (onPageChange && totalPages !== pdfDoc.numPages) {
          // Sayfa sayısını güncelle
          onPageChange(Math.min(currentPage, pdfDoc.numPages));
        }

        setIsLoading(false);
      } catch (err) {
        console.error("PDF yükleme hatası:", err);
        setError(err instanceof Error ? err.message : "PDF yükleme hatası");
        setIsLoading(false);
      }
    };

    loadPDF();
  }, [pdfUrl]);

  // Geçerli sayfayı render et
  useEffect(() => {
    if (!pdfDocument || !canvasRef.current || isLoading) return;

    const renderPage = async () => {
      try {
        const page = await pdfDocument.getPage(currentPage);
        
        const canvas = canvasRef.current;
        if (!canvas) {
          console.error("Canvas referansı alınamadı!");
          return;
        }
        
        const context = canvas.getContext('2d');
        if (!context) {
          console.error("Canvas context alınamadı!");
          return;
        }
        
        // Görüntüle
        const viewport = page.getViewport({ scale: 1.5 });
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        // Sayfayı temizle
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        // Render et
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;
        
        // PDF boyutlarını ayarla
        setPdfDimensions({
          width: viewport.width,
          height: viewport.height
        });
        
        console.log("Sayfa render edildi:", currentPage);
      } catch (err) {
        console.error("Sayfa render hatası:", err);
      }
    };

    renderPage();
  }, [pdfDocument, currentPage, isLoading]);

  // Canvas üzerine tıklama işlemi
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    
    // Canvas üzerindeki tıklama koordinatlarını hesapla
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    // Canvas ölçeğini hesaba kat
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    // Gerçek koordinatları hesapla
    const realX = x * scaleX;
    const realY = y * scaleY;
    
    console.log("Canvas'ta tıklandı:", realX, realY);
    
    // Seçilen konumu güncelle
    setSelectedPosition({ x: realX, y: realY });
    
    // Gerektiğinde dışarıya bildir
    if (onClickPosition) {
      onClickPosition(realX, realY);
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      <div 
        ref={canvasContainerRef}
        className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-auto bg-white p-2 mb-2 max-h-[600px] w-full"
      >
        {isLoading && (
          <div className="flex flex-col items-center justify-center min-h-[400px]">
            <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
            <span>PDF yükleniyor...</span>
          </div>
        )}
        
        {error && (
          <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4">
            <p className="font-semibold">Hata:</p>
            <p>{error}</p>
          </div>
        )}
        
        <div className="relative">
          <canvas 
            ref={canvasRef}
            className={`max-w-full mx-auto cursor-crosshair ${isLoading ? 'hidden' : 'block'}`}
            onClick={handleCanvasClick}
          />
          
          {/* Metin düzenleme overlay'i buraya gelecek */}
        </div>
      </div>
      
      {!isLoading && !error && (
        <div className="flex items-center justify-between w-full bg-gray-50 dark:bg-gray-800 p-2 rounded">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange && onPageChange(Math.max(1, currentPage - 1))}
            disabled={currentPage <= 1}
          >
            Önceki Sayfa
          </Button>
          
          <span className="text-sm font-medium">
            Sayfa {currentPage} / {pageCount}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange && onPageChange(Math.min(pageCount, currentPage + 1))}
            disabled={currentPage >= pageCount}
          >
            Sonraki Sayfa
          </Button>
        </div>
      )}
      
      {!isLoading && !error && onClickPosition && (
        <div className="w-full mt-2 p-2 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
          <p>PDF üzerinde metin eklemek istediğiniz konuma tıklayın.</p>
        </div>
      )}
      
      {enableTextOverlay && !isLoading && !error && pdfDimensions.width > 0 && (
        <TextOverlayEditor
          currentPage={currentPage}
          pdfWidth={pdfDimensions.width}
          pdfHeight={pdfDimensions.height}
          selectedPosition={selectedPosition}
          onClickPosition={(x, y) => {
            setSelectedPosition({ x, y });
            if (onClickPosition) onClickPosition(x, y);
          }}
        />
      )}
    </div>
  );
};

export default InteractivePDFViewer;