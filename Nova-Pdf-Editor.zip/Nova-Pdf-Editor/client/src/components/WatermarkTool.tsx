import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useToast } from '@/hooks/use-toast';
import { Stamp, Trash2, Plus, RotateCw, Palette } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface WatermarkToolProps {
  onAddWatermark?: (params: WatermarkParams) => void;
  onRemoveWatermark?: () => void;
  hasWatermark?: boolean;
  isProcessing?: boolean;
  className?: string;
}

interface WatermarkParams {
  text: string;
  opacity: number;
  rotation: number;
  fontSize: number;
  fontColor: string;
  pages: 'all' | 'current' | number[];
  position: 'center' | 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight';
}

export function WatermarkTool({
  onAddWatermark,
  onRemoveWatermark,
  hasWatermark = false,
  isProcessing = false,
  className = ""
}: WatermarkToolProps) {
  const { toast } = useToast();
  const [text, setText] = useState<string>('TASLAK');
  const [opacity, setOpacity] = useState<number>(30);
  const [rotation, setRotation] = useState<number>(45);
  const [fontSize, setFontSize] = useState<number>(48);
  const [fontColor, setFontColor] = useState<string>('#FF0000');
  const [pages, setPages] = useState<'all' | 'current' | 'custom'>('all');
  const [customPages, setCustomPages] = useState<string>('');
  const [position, setPosition] = useState<'center' | 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight'>('center');

  // Filigran ekleme işlemi
  const handleAddWatermark = () => {
    if (!text.trim()) {
      toast({
        title: "Filigran Hatası",
        description: "Filigran metni boş olamaz.",
        variant: "destructive",
      });
      return;
    }
    
    if (onAddWatermark) {
      let pagesArray: number[] = [];
      
      if (pages === 'custom') {
        try {
          // Sayfa numaralarını virgül, tire veya boşlukla ayrılmış olarak işle
          pagesArray = customPages
            .split(/[,\s-]+/)
            .map(page => {
              const num = parseInt(page.trim());
              if (isNaN(num) || num <= 0) {
                throw new Error('Geçersiz sayfa numarası');
              }
              return num;
            });
            
          if (pagesArray.length === 0) throw new Error('Sayfa numarası belirtilmedi');
        } catch (err) {
          toast({
            title: "Geçersiz Sayfa Numaraları",
            description: "Lütfen geçerli sayfa numaraları girin (örn: 1,2,3-5).",
            variant: "destructive",
          });
          return;
        }
      }
      
      onAddWatermark({
        text,
        opacity: opacity / 100, // 0-1 aralığına çevir
        rotation,
        fontSize,
        fontColor,
        pages: pages === 'all' ? 'all' : pages === 'current' ? 'current' : pagesArray,
        position
      });
      
      toast({
        title: "Filigran Eklendi",
        description: `"${text}" filigranı belgeye eklendi.`,
      });
    }
  };

  // Filigran kaldırma işlemi
  const handleRemoveWatermark = () => {
    if (onRemoveWatermark) {
      onRemoveWatermark();
      
      toast({
        title: "Filigran Kaldırıldı",
        description: "Filigran belgeden kaldırıldı.",
      });
    }
  };

  // Filigran pozisyonu adını getir
  const getPositionName = (pos: string): string => {
    switch (pos) {
      case 'center': return 'Merkez';
      case 'topLeft': return 'Sol Üst';
      case 'topRight': return 'Sağ Üst';
      case 'bottomLeft': return 'Sol Alt';
      case 'bottomRight': return 'Sağ Alt';
      default: return pos;
    }
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <Stamp className="mr-2 h-5 w-5" />
          Filigran Aracı
        </CardTitle>
        <CardDescription>
          PDF belgesine filigran ekleyin veya mevcut filigranı kaldırın
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="watermark-text">Filigran Metni</Label>
            <Input
              id="watermark-text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="örn: TASLAK, GİZLİ, vb."
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="font-color" className="flex justify-between">
                <span>Renk</span>
                <span 
                  className="inline-block w-4 h-4 rounded-full border" 
                  style={{ backgroundColor: fontColor }}
                ></span>
              </Label>
              <Input
                id="font-color"
                type="color"
                value={fontColor}
                onChange={(e) => setFontColor(e.target.value)}
                className="h-8 cursor-pointer"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="position">Konum</Label>
              <Select 
                value={position} 
                onValueChange={(value: 'center' | 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight') => 
                  setPosition(value)
                }
              >
                <SelectTrigger id="position">
                  <SelectValue placeholder="Konum seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="center">Merkez</SelectItem>
                  <SelectItem value="topLeft">Sol Üst</SelectItem>
                  <SelectItem value="topRight">Sağ Üst</SelectItem>
                  <SelectItem value="bottomLeft">Sol Alt</SelectItem>
                  <SelectItem value="bottomRight">Sağ Alt</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="opacity-slider" className="flex justify-between">
              <span>Şeffaflık</span>
              <span className="text-xs text-muted-foreground">{opacity}%</span>
            </Label>
            <Slider
              id="opacity-slider"
              value={[opacity]}
              min={10}
              max={100}
              step={5}
              onValueChange={(value) => setOpacity(value[0])}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="rotation-slider" className="flex justify-between">
              <span>Döndürme</span>
              <span className="text-xs text-muted-foreground">{rotation}°</span>
            </Label>
            <Slider
              id="rotation-slider"
              value={[rotation]}
              min={0}
              max={360}
              step={15}
              onValueChange={(value) => setRotation(value[0])}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="size-slider" className="flex justify-between">
              <span>Boyut</span>
              <span className="text-xs text-muted-foreground">{fontSize}pt</span>
            </Label>
            <Slider
              id="size-slider"
              value={[fontSize]}
              min={12}
              max={120}
              step={4}
              onValueChange={(value) => setFontSize(value[0])}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="pages">Uygulama Sayfaları</Label>
            <Select 
              value={pages} 
              onValueChange={(value: 'all' | 'current' | 'custom') => setPages(value)}
            >
              <SelectTrigger id="pages">
                <SelectValue placeholder="Sayfaları seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Sayfalar</SelectItem>
                <SelectItem value="current">Geçerli Sayfa</SelectItem>
                <SelectItem value="custom">Özel Sayfalar</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {pages === 'custom' && (
            <div className="space-y-2">
              <Label htmlFor="custom-pages" className="text-sm flex justify-between">
                <span>Sayfa Numaraları</span>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <span className="text-xs text-muted-foreground underline decoration-dotted">
                        Format Bilgisi
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">
                        Sayfa numaralarını virgülle ayrılmış olarak girin.<br/>
                        Aralıkları tire ile belirtebilirsiniz.<br/>
                        Örnek: 1,3,5-7,10
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </Label>
              <Input
                id="custom-pages"
                value={customPages}
                onChange={(e) => setCustomPages(e.target.value)}
                placeholder="örn: 1,3,5-7"
              />
            </div>
          )}
        </div>
        
        <div className="border rounded-md p-4 mt-2 flex flex-col items-center">
          <div 
            className="border border-dashed rounded p-6 w-full flex justify-center items-center relative h-28 overflow-hidden"
            style={{ backgroundColor: fontColor === '#FFFFFF' ? '#F2F2F2' : 'white' }}
          >
            <div 
              className="absolute transform pointer-events-none"
              style={{ 
                opacity: opacity / 100,
                transform: `rotate(${rotation}deg)`,
                color: fontColor,
                fontSize: `${fontSize / 2}px`, // Küçültülmüş önizleme için
                fontFamily: 'Arial',
                maxWidth: '100%',
                textAlign: 'center',
                fontWeight: 'bold',
                ...getPositionStyle(position)
              }}
            >
              {text || 'TASLAK'}
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Filigran Önizleme</p>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="destructive"
            disabled={isProcessing || !hasWatermark}
            onClick={handleRemoveWatermark}
            className="w-full"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Filigranı Kaldır
          </Button>
          
          <Button
            disabled={isProcessing || !text.trim()}
            onClick={handleAddWatermark}
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Filigran Ekle
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Konum stilini hesapla
function getPositionStyle(position: string): React.CSSProperties {
  switch (position) {
    case 'center':
      return {
        top: '50%',
        left: '50%',
        transform: `translate(-50%, -50%) rotate(${45}deg)`,
      };
    case 'topLeft':
      return {
        top: '15%',
        left: '15%',
      };
    case 'topRight':
      return {
        top: '15%',
        right: '15%',
      };
    case 'bottomLeft':
      return {
        bottom: '15%',
        left: '15%',
      };
    case 'bottomRight':
      return {
        bottom: '15%',
        right: '15%',
      };
    default:
      return {
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
      };
  }
}

export default WatermarkTool;