import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bold, Italic, Underline } from "lucide-react";
import ImageUploadButton from "./ImageUploadButton";

interface EditingToolsProps {
  onAddText: (text: string) => void;
  onAddImage?: (file: File) => void;
  currentPage: number;
  totalPages: number;
  onPrevPage: () => void;
  onNextPage: () => void;
  onFontSizeChange?: (size: number) => void;
  onColorChange?: (color: string) => void;
}

const EditingTools: React.FC<EditingToolsProps> = ({
  onAddText,
  onAddImage,
  currentPage,
  totalPages,
  onPrevPage,
  onNextPage,
  onFontSizeChange,
  onColorChange
}) => {
  const [newText, setNewText] = useState("");
  const [fontSize, setFontSize] = useState("12px");
  const [textColor, setTextColor] = useState("#000000");

  const handleAddText = () => {
    if (newText.trim()) {
      onAddText(newText);
      setNewText("");
    }
  };

  const handleFontSizeChange = (size: string) => {
    setFontSize(size);
    if (onFontSizeChange) {
      onFontSizeChange(parseInt(size, 10));
    }
  };

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTextColor(e.target.value);
    if (onColorChange) {
      onColorChange(e.target.value);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <h2 className="text-lg font-medium text-gray-800 mb-4">Düzenleme Araçları</h2>
      
      {/* Text Tools */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Metin Düzenleme</label>
        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="p-2 border border-gray-300 rounded hover:bg-gray-50" 
            title="Kalın"
          >
            <Bold className="h-5 w-5" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="p-2 border border-gray-300 rounded hover:bg-gray-50" 
            title="İtalik"
          >
            <Italic className="h-5 w-5" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="p-2 border border-gray-300 rounded hover:bg-gray-50" 
            title="Altı Çizili"
          >
            <Underline className="h-5 w-5" />
          </Button>
          
          <Select onValueChange={handleFontSizeChange} defaultValue="12px">
            <SelectTrigger className="w-[80px]">
              <SelectValue placeholder="12px" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="12px">12px</SelectItem>
              <SelectItem value="14px">14px</SelectItem>
              <SelectItem value="16px">16px</SelectItem>
              <SelectItem value="18px">18px</SelectItem>
              <SelectItem value="20px">20px</SelectItem>
              <SelectItem value="24px">24px</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex items-center border border-gray-300 rounded overflow-hidden">
            <input 
              type="color" 
              id="textColor" 
              className="w-8 h-8 border-0 p-0 m-0" 
              value={textColor} 
              onChange={handleColorChange}
              title="Metin Rengi"
            />
          </div>
        </div>
      </div>
      
      {/* Text Addition */}
      <div className="mb-4">
        <label htmlFor="addText" className="block text-sm font-medium text-gray-700 mb-1">
          Metin Ekle
        </label>
        <div className="flex">
          <Input 
            type="text" 
            id="addText" 
            placeholder="Eklenecek metin..." 
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            className="rounded-r-none"
          />
          <Button 
            onClick={handleAddText}
            className="rounded-l-none"
          >
            Ekle
          </Button>
        </div>
      </div>
      
      {/* Image Addition */}
      {onAddImage && (
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Görüntü Ekle
          </label>
          <div className="flex">
            <ImageUploadButton 
              onImageSelect={onAddImage} 
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">
            PDF'e eklemek istediğiniz görüntüyü (JPG, PNG vb.) seçin.
          </p>
        </div>
      )}
      
      {/* Page Navigation */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Sayfa Navigasyonu
        </label>
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            onClick={onPrevPage} 
            disabled={currentPage <= 1}
            className="flex items-center text-sm text-gray-600 hover:text-primary disabled:opacity-50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Önceki
          </Button>
          
          <span className="text-sm text-gray-600">
            {currentPage} / {totalPages}
          </span>
          
          <Button 
            variant="ghost" 
            onClick={onNextPage} 
            disabled={currentPage >= totalPages}
            className="flex items-center text-sm text-gray-600 hover:text-primary disabled:opacity-50"
          >
            Sonraki
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditingTools;
