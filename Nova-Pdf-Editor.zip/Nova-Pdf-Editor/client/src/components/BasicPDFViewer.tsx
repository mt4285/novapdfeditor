import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";

interface BasicPDFViewerProps {
  pdfUrl: string;
}

const BasicPDFViewer: React.FC<BasicPDFViewerProps> = ({ pdfUrl }) => {
  const objectRef = useRef<HTMLObjectElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfVisible, setPdfVisible] = useState(false);
  
  useEffect(() => {
    if (!pdfUrl) return;
    
    // PDF yüklenip yüklenmediğini 3 saniye içinde kontrol eder
    const timer = setTimeout(() => {
      if (isLoading) {
        // PDF yükleme zaman aşımı - PDF görüntüleme sorunu olabilir
        setIsLoading(false);
      }
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [pdfUrl, isLoading]);
  
  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto border border-gray-200 dark:border-gray-700 rounded overflow-hidden">
      {/* İlk olarak her iki yöntemle PDF yüklemeyi deneyelim */}
      {!error && (
        <div className="w-full h-[600px] relative bg-white dark:bg-gray-900">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/90 dark:bg-gray-900/90 z-10">
              <div className="flex flex-col items-center">
                <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
                <span>PDF yükleniyor...</span>
              </div>
            </div>
          )}
          
          {/* İlk önce object elementini kullan */}
          <object
            ref={objectRef}
            data={pdfUrl}
            type="application/pdf"
            className="w-full h-full"
            style={{ minHeight: '600px' }}
            onLoad={() => {
              setIsLoading(false);
              setPdfVisible(true);
            }}
            onError={() => {
              console.error("PDF object elementinde yüklenemedi, iframe denenecek");
              if (objectRef.current) objectRef.current.style.display = 'none';
              if (iframeRef.current) iframeRef.current.style.display = 'block';
            }}
          >
            <div className="p-4 text-center">
              <p>PDF görüntüleyici yüklenemedi veya PDF dosyası açılamadı.</p>
              <a 
                href={pdfUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline mt-2 inline-block"
              >
                PDF dosyasını indir
              </a>
            </div>
          </object>
          
          {/* Yedek olarak iframe elementini kullan */}
          <iframe 
            src={pdfUrl}
            ref={iframeRef}
            title="PDF Yedek Görüntüleyici"
            className="w-full h-full border-0"
            style={{ 
              display: 'none',
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%'
            }}
            onLoad={() => {
              setIsLoading(false);
              setPdfVisible(true);
            }}
            onError={() => {
              setError("PDF hem object hem iframe elementlerinde yüklenemedi.");
              setIsLoading(false);
            }}
          />
        </div>
      )}
      
      {/* PDF yükleme hatası veya zaman aşımı durumunda alternatif görünüm */}
      {(error || (!pdfVisible && !isLoading)) && (
        <div className="flex flex-col items-center w-full p-8 bg-gray-50 dark:bg-gray-800">
          <h3 className="text-lg font-medium mb-6">PDF Dosyası Hazır</h3>
          
          <div className="text-center mb-8">
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              PDF dosyanız hazır! Tarayıcınızda görüntüleme sorunu nedeniyle, PDF'i görüntülemek veya indirmek için aşağıdaki düğmeleri kullanabilirsiniz.
            </p>
            
            <div className="flex flex-col items-center gap-4">
              <Button 
                onClick={() => window.open(pdfUrl, '_blank')}
                className="w-full max-w-xs flex items-center justify-center gap-2"
                variant="default"
              >
                <Download className="h-5 w-5" />
                PDF'i Görüntüle
              </Button>
              
              <a 
                href={pdfUrl}
                download
                className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
              >
                veya dosyayı doğrudan indir
              </a>
            </div>
          </div>
          
          <div className="w-full max-w-md p-4 border border-gray-200 dark:border-gray-700 rounded bg-white dark:bg-gray-900">
            <h4 className="text-sm font-medium mb-2">PDF Bilgileri</h4>
            <ul className="text-xs space-y-2 text-gray-600 dark:text-gray-400">
              <li>URL: <span className="font-mono text-xs break-all">{pdfUrl}</span></li>
              <li>Durum: {error ? "Hata" : "Yüklendi, görüntüleme sorunu"}</li>
              <li>Görüntüleme: {error ? "Hata: " + error : "Tarayıcı desteği gerektirir"}</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default BasicPDFViewer;