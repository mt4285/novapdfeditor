import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const PricingFeature: React.FC<{
  included: boolean;
  children: React.ReactNode;
}> = ({ included, children }) => {
  return (
    <div className="flex items-center space-x-2">
      {included ? (
        <Check className="h-4 w-4 text-primary" />
      ) : (
        <X className="h-4 w-4 text-muted-foreground" />
      )}
      <span className={cn(
        "text-sm",
        included ? "text-foreground" : "text-muted-foreground"
      )}>{children}</span>
    </div>
  );
};

const PricingPlans: React.FC = () => {
  const handleSelect = (planId: string) => {
    // Burada ödeme işlemine yönlendirme veya paket seçimi işlemi yapılabilir
    console.log('Selected plan:', planId);
  };

  return (
    <div className="py-10">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold">Fiyatlandırma Planları</h2>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          İhtiyaçlarınıza uygun bir plan seçin ve hemen PDF işlemlerinizi daha verimli hale getirmeye başlayın.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {/* Standart Plan */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Standart</CardTitle>
            <CardDescription>Temel PDF düzenleme ihtiyaçları için</CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">Ücretsiz</span>
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            <div className="space-y-3">
              <PricingFeature included={true}>Temel PDF düzenleme</PricingFeature>
              <PricingFeature included={true}>Metaveri düzenleme</PricingFeature>
              <PricingFeature included={true}>Basit metin arama</PricingFeature>
              <PricingFeature included={false}>OCR desteği</PricingFeature>
              <PricingFeature included={false}>PDF karşılaştırma</PricingFeature>
              <PricingFeature included={false}>Form alanları oluşturma</PricingFeature>
              <PricingFeature included={false}>PDF şablonları</PricingFeature>
              <PricingFeature included={false}>Sınırsız dosya işleme</PricingFeature>
              <PricingFeature included={false}>Öncelikli destek</PricingFeature>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => handleSelect('standard')}
            >
              Başla
            </Button>
          </CardFooter>
        </Card>

        {/* Yarı Pro Plan */}
        <Card className="flex flex-col border-primary">
          <CardHeader className="bg-primary/5">
            <div className="bg-primary text-primary-foreground text-xs uppercase font-bold py-1 px-3 rounded-full max-w-fit mb-2">
              En Popüler
            </div>
            <CardTitle>Yarı Pro</CardTitle>
            <CardDescription>Gelişmiş özellikler ve daha fazla verimlilik</CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">29,99 TL</span>
              <span className="text-sm text-muted-foreground">/ay</span>
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            <div className="space-y-3">
              <PricingFeature included={true}>Temel PDF düzenleme</PricingFeature>
              <PricingFeature included={true}>Metaveri düzenleme</PricingFeature>
              <PricingFeature included={true}>Gelişmiş metin arama</PricingFeature>
              <PricingFeature included={true}>OCR desteği</PricingFeature>
              <PricingFeature included={true}>PDF karşılaştırma</PricingFeature>
              <PricingFeature included={true}>Form alanları oluşturma</PricingFeature>
              <PricingFeature included={false}>PDF şablonları</PricingFeature>
              <PricingFeature included={false}>Sınırsız dosya işleme</PricingFeature>
              <PricingFeature included={false}>Öncelikli destek</PricingFeature>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={() => handleSelect('semi-pro')}
            >
              Şimdi Satın Al
            </Button>
          </CardFooter>
        </Card>

        {/* Pro Plan */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Pro</CardTitle>
            <CardDescription>Profesyonel kullanıcılar için tam kapsamlı çözüm</CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">49,99 TL</span>
              <span className="text-sm text-muted-foreground">/ay</span>
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            <div className="space-y-3">
              <PricingFeature included={true}>Temel PDF düzenleme</PricingFeature>
              <PricingFeature included={true}>Metaveri düzenleme</PricingFeature>
              <PricingFeature included={true}>Gelişmiş metin arama</PricingFeature>
              <PricingFeature included={true}>OCR desteği</PricingFeature>
              <PricingFeature included={true}>PDF karşılaştırma</PricingFeature>
              <PricingFeature included={true}>Form alanları oluşturma</PricingFeature>
              <PricingFeature included={true}>PDF şablonları</PricingFeature>
              <PricingFeature included={true}>Sınırsız dosya işleme</PricingFeature>
              <PricingFeature included={true}>Öncelikli destek</PricingFeature>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => handleSelect('pro')}
            >
              Şimdi Satın Al
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-10 text-center text-sm text-muted-foreground">
        <p>Tüm planlar 14 gün ücretsiz deneme içerir. Kredi kartı bilgileriniz gerekli değildir.</p>
        <p className="mt-2">Ödeme işlemleri güvenli ödeme altyapımız üzerinden gerçekleştirilir.</p>
      </div>
    </div>
  );
};

export default PricingPlans;