import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Save, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { readPDFMetadata, PDFMetadata, updatePDFMetadata } from '@/lib/metadata-utils';
import { apiRequest } from '@/lib/queryClient';

interface MetadataEditorProps {
  pdfBuffer?: ArrayBuffer;
  pdfId?: number;
  pdfName?: string;
  onMetadataUpdated?: (updatedBuffer: ArrayBuffer) => void;
}

const MetadataEditor: React.FC<MetadataEditorProps> = ({
  pdfBuffer,
  pdfId,
  pdfName = 'belge.pdf',
  onMetadataUpdated
}) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [metadata, setMetadata] = useState<PDFMetadata>({
    title: '',
    author: '',
    subject: '',
    keywords: '',
    creator: '',
    producer: '',
  });

  // PDF yüklendiğinde metaverileri oku
  useEffect(() => {
    const loadMetadata = async () => {
      if (!pdfBuffer) return;
      
      setIsLoading(true);
      
      try {
        const metadata = await readPDFMetadata(pdfBuffer);
        setMetadata({
          title: metadata.title || '',
          author: metadata.author || '',
          subject: metadata.subject || '',
          keywords: metadata.keywords || '',
          creator: metadata.creator || '',
          producer: metadata.producer || '',
          creationDate: metadata.creationDate,
          modificationDate: metadata.modificationDate
        });
      } catch (error) {
        console.error('Metaveri okuma hatası:', error);
        toast({
          title: 'Hata',
          description: 'PDF metaverileri okunamadı.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadMetadata();
  }, [pdfBuffer, toast]);

  // Form alanlarında değişiklik yapıldığında
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setMetadata(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Metaverileri kaydet
  const handleSave = async () => {
    if (!pdfBuffer || !pdfId) {
      toast({
        title: 'Hata',
        description: 'PDF dosyası bulunamadı.',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);

    try {
      // 1. İlk olarak istemci tarafında metaverileri güncelle
      const updatedBuffer = await updatePDFMetadata(pdfBuffer, metadata);
      
      // 2. Sunucuya güncellenmiş metaverileri gönder
      await apiRequest('POST', `/api/pdf/${pdfId}/metadata`, { metadata });
      
      // 3. Başarılı mesajını göster ve güncellenmiş buffer'ı parent bileşene gönder
      toast({
        title: 'Başarılı',
        description: 'PDF metaverileri başarıyla güncellendi.',
      });
      
      if (onMetadataUpdated) {
        onMetadataUpdated(updatedBuffer);
      }
    } catch (error) {
      console.error('Metaveri güncelleme hatası:', error);
      toast({
        title: 'Hata',
        description: 'PDF metaverileri güncellenirken bir hata oluştu.',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Tarih formatını kullanıcı dostu hale getir
  const formatDate = (date?: Date) => {
    if (!date) return '-';
    return date.toLocaleString('tr-TR');
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Info className="h-5 w-5 mr-2" />
            PDF Metaverileri
          </CardTitle>
          <CardDescription>
            Doküman bilgilerini görüntüleyin ve düzenleyin
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Metaveriler yükleniyor...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Info className="h-5 w-5 mr-2" />
          PDF Metaverileri
        </CardTitle>
        <CardDescription>
          Doküman bilgilerini görüntüleyin ve düzenleyin
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="title">Başlık</Label>
            <Input
              id="title"
              name="title"
              value={metadata.title}
              onChange={handleChange}
              placeholder="Doküman başlığı"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="author">Yazar</Label>
            <Input
              id="author"
              name="author"
              value={metadata.author}
              onChange={handleChange}
              placeholder="Doküman yazarı"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="subject">Konu</Label>
            <Input
              id="subject"
              name="subject"
              value={metadata.subject}
              onChange={handleChange}
              placeholder="Dokümanın konusu"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="keywords">Anahtar Kelimeler</Label>
            <Input
              id="keywords"
              name="keywords"
              value={metadata.keywords}
              onChange={handleChange}
              placeholder="Virgülle ayrılmış anahtar kelimeler"
            />
            <p className="text-xs text-muted-foreground">Anahtar kelimeleri virgülle ayırın</p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="creator">Oluşturan Uygulama</Label>
            <Input
              id="creator"
              name="creator"
              value={metadata.creator}
              onChange={handleChange}
              placeholder="PDF'i oluşturan uygulama"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-2">
            <div>
              <Label className="text-xs text-muted-foreground">Oluşturma Tarihi</Label>
              <p className="text-sm font-medium">{formatDate(metadata.creationDate)}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Son Değiştirme Tarihi</Label>
              <p className="text-sm font-medium">{formatDate(metadata.modificationDate)}</p>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          className="w-full"
          onClick={handleSave}
          disabled={isSaving || !pdfBuffer}
        >
          {isSaving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Metaverileri Kaydet
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default MetadataEditor;