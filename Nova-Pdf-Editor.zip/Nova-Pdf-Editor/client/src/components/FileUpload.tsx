import React, { useState } from "react";
import { FileInput } from "@/components/ui/FileInput";
import { Button } from "@/components/ui/button";
import { formatFileSize } from "@/lib/utils";
import { X, FileText, Upload, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface FileUploadProps {
  onFileUpload: (file: File) => void;
  isUploading: boolean;
  fileData?: {
    name: string;
    size: number;
  } | null;
  onReset: () => void;
}

const FileUpload: React.FC<FileUploadProps> = ({
  onFileUpload,
  isUploading,
  fileData,
  onReset,
}) => {
  // Dosya yükleme sınırını burada tanımlıyoruz
  const MAX_FILE_SIZE = 30 * 1024 * 1024; // 30MB
  const [dragActive, setDragActive] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);

  const handleFileSelected = (file: File) => {
    setFileError(null);
    
    // Dosya boyutu kontrolü
    if (file.size > MAX_FILE_SIZE) {
      setFileError(`Dosya boyutu çok büyük. Maksimum 30MB olmalıdır. Mevcut boyut: ${(file.size / (1024 * 1024)).toFixed(2)}MB`);
      return;
    }
    
    // Dosya tipi kontrolü
    if (file.type !== "application/pdf") {
      setFileError("Lütfen sadece PDF dosyası yükleyin.");
      return;
    }
    
    onFileUpload(file);
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 mb-6">
      <h2 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">PDF Yükleme</h2>
      
      {fileError && (
        <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-md text-red-700 dark:text-red-300 text-sm">
          <p>{fileError}</p>
        </div>
      )}

      {!fileData ? (
        <FileInput
          onFileSelected={handleFileSelected}
          accept=".pdf"
          disabled={isUploading}
          dropAreaClassName={`border-2 ${dragActive ? 'border-primary border-dashed bg-primary/5' : 'border-gray-200 dark:border-gray-700'} rounded-lg p-8`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          maxSizeMB={30}
          acceptedFileTypes={["application/pdf"]}
        >
          <div className="text-center">
            <Upload className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
              PDF dosyanızı sürükleyip bırakın
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">veya</p>
            <Button
              variant="outline"
              className="mt-2"
              disabled={isUploading}
            >
              {isUploading ? "Yükleniyor..." : "Dosya Seç"}
            </Button>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
              Maksimum dosya boyutu: 30MB
            </p>
          </div>
        </FileInput>
      ) : (
        <div className="mt-4">
          <div className="flex items-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-md">
            <FileText className="h-8 w-8 text-primary mr-3" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                {fileData.name}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {formatFileSize(fileData.size)}
              </p>
              {isUploading && (
                <div className="mt-2">
                  <Progress value={33} className="h-1.5 w-full" />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 flex items-center">
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Yükleniyor...
                  </p>
                </div>
              )}
            </div>
            <button
              onClick={onReset}
              className="ml-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
              disabled={isUploading}
              aria-label="Dosyayı kaldır"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}
      
      <div className="text-xs text-gray-500 dark:text-gray-400 mt-4">
        <p>Desteklenen dosya formatı: PDF</p>
      </div>
    </div>
  );
};

export default FileUpload;
