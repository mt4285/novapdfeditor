import React from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Save, Download, Home } from "lucide-react";

interface MobileActionBarProps {
  onSave?: () => void;
  onDownload?: () => void;
  onBack?: () => void;
  showSave?: boolean;
  showDownload?: boolean;
  title?: string;
  isSaving?: boolean;
}

const MobileActionBar: React.FC<MobileActionBarProps> = ({
  onSave,
  onDownload,
  onBack,
  showSave = true,
  showDownload = true,
  title = "PDF Düzenleme",
  isSaving = false,
}) => {
  const [_, setLocation] = useLocation();

  const handleGoBack = () => {
    if (onBack) {
      // Özel geri işlemini kullan
      onBack();
    } else {
      // Ana sayfaya dön (mobil görünüme)
      setLocation("/mobile");
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg border-t border-gray-200 dark:border-gray-700 p-3 z-50">
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleGoBack}
          className="flex items-center gap-1 text-gray-600 dark:text-gray-300"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Geri</span>
        </Button>

        <h2 className="text-sm font-medium text-gray-700 dark:text-gray-300">{title}</h2>

        <div className="flex items-center gap-2">
          {showSave && (
            <Button
              variant="secondary"
              size="sm"
              onClick={onSave}
              disabled={isSaving}
              className="flex items-center gap-1"
            >
              <Save className="h-4 w-4" />
              <span>{isSaving ? "Kaydediyor..." : "Kaydet"}</span>
            </Button>
          )}

          {showDownload && (
            <Button
              variant="default"
              size="sm"
              onClick={onDownload}
              disabled={isSaving}
              className="flex items-center gap-1"
            >
              <Download className="h-4 w-4" />
              <span>İndir</span>
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MobileActionBar;