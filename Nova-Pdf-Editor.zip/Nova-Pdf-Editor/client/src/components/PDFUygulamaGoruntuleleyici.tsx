import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Download, ExternalLink } from "lucide-react";

interface PDFUygulamaGoruntuleleyiciProps {
  pdfUrl: string;
}

const PDFUygulamaGoruntuleleyici: React.FC<PDFUygulamaGoruntuleleyiciProps> = ({ pdfUrl }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfVisible, setPdfVisible] = useState(false);
  const objectRef = useRef<HTMLObjectElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (!pdfUrl) return;

    // PDF'in yüklenip yüklenmediğini kontrol et
    const timer = setTimeout(() => {
      if (isLoading) {
        console.log("PDF yükleme zaman aşımı - yedek görüntüleme seçenekleri gösteriliyor");
        setIsLoading(false);
      }
    }, 5000); // 5 saniye zaman aşımı - mobil cihazlarda daha hızlı zaman aşımı

    return () => {
      clearTimeout(timer);
    };
  }, [pdfUrl, isLoading]);

  // Object elementi hata verdiğinde iframe'e geçiş yap
  const handleObjectError = () => {
    console.log("PDF object elementinde yüklenemedi, iframe'e geçiliyor");
    
    if (objectRef.current) {
      objectRef.current.style.display = 'none';
    }
    
    if (iframeRef.current) {
      iframeRef.current.style.display = 'block';
    }
  };

  // PDF başarıyla yüklendiğinde
  const handlePdfLoad = () => {
    setIsLoading(false);
    setPdfVisible(true);
  };

  // İframe de hata verirse
  const handleIframeError = () => {
    setError("PDF görüntülenemedi. Lütfen alternatif yöntemleri kullanın.");
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto">
      <h3 className="text-lg font-medium mb-4">PDF Görüntüleyici</h3>
      
      {isLoading && (
        <div className="flex flex-col items-center p-8">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
          <span>PDF yükleniyor...</span>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4 w-full">
          <p className="font-semibold">Hata:</p>
          <p>{error}</p>
        </div>
      )}
      
      <div className="w-full h-[600px] border border-gray-200 dark:border-gray-700 rounded shadow-lg bg-white relative">
        {/* İlk önce object elementini kullan */}
        <object
          ref={objectRef}
          data={pdfUrl}
          type="application/pdf"
          className="w-full h-full"
          onLoad={handlePdfLoad}
          onError={handleObjectError}
        >
          <div className="p-4 text-center">
            <p>PDF görüntüleyici yüklenemedi veya PDF dosyası açılamadı.</p>
            <a 
              href={pdfUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline mt-2 inline-block"
            >
              PDF dosyasını indir
            </a>
          </div>
        </object>

        {/* Yedek olarak iframe kullan */}
        <iframe
          ref={iframeRef}
          src={pdfUrl}
          className="w-full h-full"
          style={{ 
            display: 'none',
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%'
          }}
          title="PDF Yedek Görüntüleyici"
          onLoad={handlePdfLoad}
          onError={handleIframeError}
        />
      </div>
      
      {/* Alternatif PDF erişim seçenekleri */}
      {(!pdfVisible && !isLoading) && (
        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg w-full">
          <h4 className="text-md font-medium mb-2">PDF Görüntüleme Sorunu</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
            PDF dosyayı görüntülemekte sorun yaşıyoruz. Aşağıdaki alternatif yöntemleri deneyebilirsiniz:
          </p>
          
          <div className="flex flex-col sm:flex-row gap-2 justify-center">
            <Button 
              onClick={() => window.open(pdfUrl, '_blank')}
              variant="outline"
              className="flex items-center gap-2"
            >
              <ExternalLink className="h-4 w-4" />
              Yeni Sekmede Aç
            </Button>
            
            <a 
              href={pdfUrl} 
              download
              className="bg-primary text-primary-foreground rounded-md px-4 py-2 text-sm flex items-center justify-center gap-2 hover:bg-primary/90"
            >
              <Download className="h-4 w-4" />
              İndir
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default PDFUygulamaGoruntuleleyici;