import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, Search, FileText } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { scanPdfWithOCR } from '@/lib/ocr-utils';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

interface OCRProcessorProps {
  pdfBuffer?: ArrayBuffer;
  pdfName?: string;
  onOCRComplete?: (text: string[]) => void;
}

const OCRProcessor: React.FC<OCRProcessorProps> = ({ pdfBuffer, pdfName, onOCRComplete }) => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [pageProgress, setPageProgress] = useState(0);
  const [extractedText, setExtractedText] = useState<string[]>([]);
  const [selectedPage, setSelectedPage] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const startOCR = async () => {
    if (!pdfBuffer) {
      toast({
        title: 'PDF bulunamadı',
        description: 'OCR işlemi için geçerli bir PDF dosyası yükleyin.',
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsProcessing(true);
      setError(null);
      setCurrentPage(0);
      setTotalPages(0);
      setPageProgress(0);
      setExtractedText([]);

      const result = await scanPdfWithOCR(pdfBuffer, (page, total, progress) => {
        setCurrentPage(page);
        setTotalPages(total);
        setPageProgress(progress * 100);
      });

      setExtractedText(result);
      setSelectedPage(0);
      
      if (onOCRComplete) {
        onOCRComplete(result);
      }

      toast({
        title: 'OCR Tamamlandı',
        description: `${result.length} sayfadaki metinler başarıyla çıkarıldı.`,
      });
    } catch (err) {
      console.error('OCR işlemi sırasında hata:', err);
      setError(err instanceof Error ? err.message : 'OCR işlemi sırasında beklenmeyen bir hata oluştu.');
      toast({
        title: 'OCR Hatası',
        description: 'Metin çıkarma işlemi sırasında bir hata oluştu.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePageChange = (pageIndex: number) => {
    if (pageIndex >= 0 && pageIndex < extractedText.length) {
      setSelectedPage(pageIndex);
    }
  };

  const copyToClipboard = () => {
    if (extractedText.length > 0) {
      navigator.clipboard.writeText(extractedText[selectedPage]);
      toast({
        title: 'Metin Kopyalandı',
        description: 'Çıkarılan metin panoya kopyalandı.',
      });
    }
  };

  const copyAllToClipboard = () => {
    if (extractedText.length > 0) {
      navigator.clipboard.writeText(extractedText.join('\n\n--- Sayfa Sonu ---\n\n'));
      toast({
        title: 'Tüm Metin Kopyalandı',
        description: 'Tüm sayfalardan çıkarılan metin panoya kopyalandı.',
      });
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Search className="h-5 w-5 mr-2" />
          OCR - Optik Karakter Tanıma
        </CardTitle>
        <CardDescription>
          Taranmış PDF dosyasından metin çıkarma işlemi
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {!isProcessing && !extractedText.length ? (
          <div className="text-center py-4">
            <FileText className="h-12 w-12 mx-auto text-gray-400 dark:text-gray-600 mb-3" />
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {pdfBuffer 
                ? `"${pdfName || 'PDF dosyası'}" içerisindeki metinleri çıkarmak için OCR'ı başlatın.`
                : 'OCR işlemi için önce bir PDF dosyası yükleyin.'}
            </p>
            <Button 
              onClick={startOCR} 
              disabled={!pdfBuffer || isProcessing}
              className="mx-auto"
            >
              OCR İşlemini Başlat
            </Button>
          </div>
        ) : null}

        {isProcessing && (
          <div className="py-4">
            <div className="flex justify-between mb-2 text-sm">
              <span>İşleniyor: Sayfa {currentPage}/{totalPages || '?'}</span>
              <span>{Math.round(pageProgress)}%</span>
            </div>
            <Progress value={pageProgress} className="h-2 mb-4" />
            <div className="text-center py-4">
              <Loader2 className="h-8 w-8 mx-auto animate-spin text-primary mb-2" />
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Bu işlem birkaç dakika sürebilir. Lütfen bekleyin...
              </p>
            </div>
          </div>
        )}

        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertTitle>OCR Hatası</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!isProcessing && extractedText.length > 0 && (
          <>
            <div className="flex justify-between items-center mb-3">
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handlePageChange(selectedPage - 1)}
                  disabled={selectedPage <= 0}
                >
                  Önceki
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handlePageChange(selectedPage + 1)}
                  disabled={selectedPage >= extractedText.length - 1}
                >
                  Sonraki
                </Button>
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Sayfa {selectedPage + 1} / {extractedText.length}
              </span>
            </div>

            <Textarea
              value={extractedText[selectedPage] || ''}
              readOnly
              className="min-h-[200px] mb-3 font-mono text-sm"
            />
          </>
        )}
      </CardContent>

      {!isProcessing && extractedText.length > 0 && (
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={copyToClipboard}
          >
            Bu Sayfayı Kopyala
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={copyAllToClipboard}
          >
            Tüm Metni Kopyala
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default OCRProcessor;