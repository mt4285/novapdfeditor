import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

interface ObjectPDFViewerProps {
  pdfUrl: string;
}

const ObjectPDFViewer: React.FC<ObjectPDFViewerProps> = ({ pdfUrl }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const objectRef = useRef<HTMLObjectElement>(null);

  useEffect(() => {
    if (!pdfUrl) return;

    // PDF'in yüklenip yüklenmediğini kontrol et
    const checkLoad = () => {
      setIsLoading(false);
    };

    // object elementinin yüklenmesini bekle
    if (objectRef.current) {
      objectRef.current.onload = checkLoad;
    }

    // Hata kontrolü
    const timer = setTimeout(() => {
      if (isLoading) {
        console.log("PDF yükleme zaman aşımı");
        setError("PDF yükleme zaman aşımına uğradı. Lütfen tekrar deneyin.");
        setIsLoading(false);
      }
    }, 10000); // 10 saniye zaman aşımı

    return () => {
      clearTimeout(timer);
    };
  }, [pdfUrl, isLoading]);

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto">
      <h3 className="text-lg font-medium mb-4">PDF Görüntüleyici (Object Tag)</h3>
      
      {isLoading && (
        <div className="flex flex-col items-center p-8">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
          <span>PDF yükleniyor...</span>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4 w-full">
          <p className="font-semibold">Hata:</p>
          <p>{error}</p>
        </div>
      )}
      
      <div className="w-full h-[600px] border border-gray-200 dark:border-gray-700 rounded shadow-lg bg-white p-2">
        <object
          ref={objectRef}
          data={pdfUrl}
          type="application/pdf"
          className="w-full h-full"
          onLoad={() => setIsLoading(false)}
          onError={() => {
            setError("PDF dosyası yüklenemedi.");
            setIsLoading(false);
          }}
        >
          <div className="p-4 text-center">
            <p>PDF görüntüleme desteklenmiyor veya PDF dosyası açılamadı.</p>
            <a 
              href={pdfUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline mt-2 inline-block"
            >
              PDF dosyasını indir
            </a>
          </div>
        </object>
      </div>
    </div>
  );
};

export default ObjectPDFViewer;