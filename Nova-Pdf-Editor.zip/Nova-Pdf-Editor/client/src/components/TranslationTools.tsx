import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Globe, BookText, ArrowRight, Search, CheckCircle, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Input } from '@/components/ui/input';

interface TranslationToolsProps {
  pdfText?: string[];
  onTranslatedText?: (translatedText: string[]) => void;
  className?: string;
}

// Desteklenen diller
const supportedLanguages = [
  { code: "tr", name: "Türkçe" },
  { code: "en", name: "İngilizce" },
  { code: "de", name: "Almanca" },
  { code: "fr", name: "Fransızca" },
  { code: "es", name: "İspanyolca" },
  { code: "it", name: "İtalyanca" },
  { code: "ru", name: "Rusça" },
  { code: "ar", name: "Arapça" },
  { code: "zh", name: "Çince" },
  { code: "ja", name: "Japonca" },
];

// Demo sözlük veritabanı
const demoDict: Record<string, any> = {
  "hello": {
    word: "hello",
    phonetic: "/həˈləʊ/",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "An utterance of 'hello'; a greeting.",
            example: "She gave me a warm hello."
          }
        ]
      },
      {
        partOfSpeech: "interjection",
        definitions: [
          {
            definition: "A greeting used when meeting someone or acknowledging someone's arrival or presence.",
            example: "Hello, John! How are you today?"
          },
          {
            definition: "A greeting used when answering the telephone.",
            example: "Hello? Who's calling?"
          }
        ]
      }
    ],
    translations: [
      { text: "merhaba", partOfSpeech: "ünlem" },
      { text: "selam", partOfSpeech: "ünlem" }
    ]
  },
  "world": {
    word: "world",
    phonetic: "/wɜːld/",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The Earth and all life on it, including human civilization.",
            example: "People all over the world mourned her death."
          },
          {
            definition: "A planet similar to the Earth.",
            example: "Scientists are now discovering many worlds around other stars."
          }
        ]
      }
    ],
    translations: [
      { text: "dünya", partOfSpeech: "isim" },
      { text: "alem", partOfSpeech: "isim" }
    ]
  },
  "computer": {
    word: "computer",
    phonetic: "/kəmˈpjuːtə/",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "An electronic device for storing and processing data, typically in binary form, according to instructions given to it in a variable program.",
            example: "She bought a new computer for her home office."
          }
        ]
      }
    ],
    translations: [
      { text: "bilgisayar", partOfSpeech: "isim" }
    ]
  },
  "programming": {
    word: "programming",
    phonetic: "/ˈprəʊɡræmɪŋ/",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The process of writing computer programs.",
            example: "She's studying programming at university."
          },
          {
            definition: "The action or process of scheduling something.",
            example: "The programming of theatrical events."
          }
        ]
      }
    ],
    translations: [
      { text: "programlama", partOfSpeech: "isim" }
    ]
  },
  "merhaba": {
    word: "merhaba",
    phonetic: "/meɾhaˈba/",
    meanings: [
      {
        partOfSpeech: "ünlem",
        definitions: [
          {
            definition: "Selamlaşma, karşılaşma sözü.",
            example: "Merhaba, nasılsın?"
          }
        ]
      }
    ],
    translations: [
      { text: "hello", partOfSpeech: "interjection" },
      { text: "hi", partOfSpeech: "interjection" }
    ]
  },
  "dünya": {
    word: "dünya",
    phonetic: "/dynˈja/",
    meanings: [
      {
        partOfSpeech: "isim",
        definitions: [
          {
            definition: "Üzerinde yaşadığımız gezegen, yeryüzü.",
            example: "Dünya Güneş'in etrafında döner."
          },
          {
            definition: "İnsanlığın yaşadığı ortam, alem.",
            example: "İş dünyasında rekabet çok fazla."
          }
        ]
      }
    ],
    translations: [
      { text: "world", partOfSpeech: "noun" },
      { text: "earth", partOfSpeech: "noun" }
    ]
  }
};

// Basit çeviri yapan fonksiyon (gerçek API olmadan demo amaçlı)
function demoTranslate(text: string, targetLang: string, sourceLang: string = "auto"): Promise<string> {
  return new Promise((resolve) => {
    // Simüle edilmiş gecikme
    setTimeout(() => {
      // Çok basit bir çeviri demo - gerçekçi değil, sadece demo gösterimi
      if (text.trim() === "") {
        resolve("");
        return;
      }
      
      if (targetLang === "tr" && sourceLang !== "tr") {
        // İngilizce -> Türkçe
        const translations: Record<string, string> = {
          "hello": "merhaba",
          "world": "dünya",
          "welcome": "hoş geldiniz",
          "to": "için",
          "the": "",
          "pdf": "PDF",
          "editor": "düzenleyici",
          "translator": "çevirmen",
          "document": "belge",
          "text": "metin",
          "translation": "çeviri",
          "language": "dil",
          "tools": "araçlar",
          "dictionary": "sözlük"
        };
        
        const result = text.split(/\s+/).map(word => {
          const lowerWord = word.toLowerCase().replace(/[.,!?;:()]/g, '');
          const punctuation = word.match(/[.,!?;:()]+/)?.[0] || '';
          
          return (translations[lowerWord] || word) + punctuation;
        }).join(' ');
        
        resolve(result);
      } else if (targetLang === "en" && sourceLang !== "en") {
        // Türkçe -> İngilizce
        const translations: Record<string, string> = {
          "merhaba": "hello",
          "dünya": "world",
          "hoş geldiniz": "welcome",
          "için": "for",
          "pdf": "PDF",
          "düzenleyici": "editor",
          "çevirmen": "translator",
          "belge": "document",
          "metin": "text",
          "çeviri": "translation",
          "dil": "language",
          "araçlar": "tools",
          "sözlük": "dictionary"
        };
        
        const result = text.split(/\s+/).map(word => {
          const lowerWord = word.toLowerCase().replace(/[.,!?;:()]/g, '');
          const punctuation = word.match(/[.,!?;:()]+/)?.[0] || '';
          
          return (translations[lowerWord] || word) + punctuation;
        }).join(' ');
        
        resolve(result);
      } else {
        // Diğer diller için basit bir demo mesajı
        resolve(`[${text}] metninin ${sourceLang} dilinden ${targetLang} diline çevirisi. (Demo)`);
      }
    }, 500); // 500ms gecikme
  });
}

export const TranslationTools: React.FC<TranslationToolsProps> = ({
  pdfText,
  onTranslatedText,
  className
}) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("pdf-translate");
  
  // PDF Çeviri durumu
  const [pdfSourceLang, setPdfSourceLang] = useState<string>("en");
  const [pdfTargetLang, setPdfTargetLang] = useState<string>("tr");
  const [translatedPdfText, setTranslatedPdfText] = useState<string[]>([]);
  const [isTranslatingPdf, setIsTranslatingPdf] = useState<boolean>(false);
  
  // Metin Çeviri durumu
  const [textToTranslate, setTextToTranslate] = useState<string>("");
  const [textSourceLang, setTextSourceLang] = useState<string>("en");
  const [textTargetLang, setTextTargetLang] = useState<string>("tr");
  const [translatedText, setTranslatedText] = useState<string>("");
  const [isTranslatingText, setIsTranslatingText] = useState<boolean>(false);
  
  // Sözlük durumu
  const [wordToLookup, setWordToLookup] = useState<string>("");
  const [dictionarySourceLang, setDictionarySourceLang] = useState<string>("en");
  const [dictionaryTargetLang, setDictionaryTargetLang] = useState<string>("tr");
  const [lookupResult, setLookupResult] = useState<any | null>(null);
  const [isLookingUp, setIsLookingUp] = useState<boolean>(false);
  
  // PDF çevirisi
  const handleTranslatePdf = async () => {
    if (!pdfText || pdfText.length === 0) {
      toast({
        title: "Çeviri Hatası",
        description: "Çevrilecek PDF içeriği bulunamadı.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsTranslatingPdf(true);
      const translatedTexts: string[] = [];
      
      // Her sayfayı ayrı ayrı çevir
      for (const text of pdfText) {
        if (!text.trim()) {
          translatedTexts.push("");
          continue;
        }
        
        const result = await demoTranslate(text, pdfTargetLang, pdfSourceLang);
        translatedTexts.push(result);
      }
      
      setTranslatedPdfText(translatedTexts);
      
      if (onTranslatedText) {
        onTranslatedText(translatedTexts);
      }
      
      toast({
        title: "Çeviri Tamamlandı",
        description: `PDF içeriği ${pdfSourceLang} dilinden ${pdfTargetLang} diline çevrildi.`,
      });
    } catch (error) {
      console.error("PDF çeviri hatası:", error);
      toast({
        title: "Çeviri Hatası",
        description: "PDF içeriği çevrilirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsTranslatingPdf(false);
    }
  };
  
  // Metin çevirisi
  const handleTranslateText = async () => {
    if (!textToTranslate.trim()) {
      toast({
        title: "Çeviri Hatası",
        description: "Lütfen çevrilecek bir metin girin.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsTranslatingText(true);
      const result = await demoTranslate(textToTranslate, textTargetLang, textSourceLang);
      setTranslatedText(result);
      
      toast({
        title: "Çeviri Tamamlandı",
        description: `Metin ${textSourceLang} dilinden ${textTargetLang} diline çevrildi.`,
      });
    } catch (error) {
      console.error("Metin çeviri hatası:", error);
      toast({
        title: "Çeviri Hatası",
        description: "Metin çevrilirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsTranslatingText(false);
    }
  };
  
  // Sözlük araması
  const handleLookupWord = async () => {
    if (!wordToLookup.trim()) {
      toast({
        title: "Sözlük Hatası",
        description: "Lütfen aranacak bir kelime girin.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsLookingUp(true);
      
      // Demo sözlük araması
      const word = wordToLookup.toLowerCase().trim();
      const entry = demoDict[word];
      
      // Bekletme hissi vermek için
      await new Promise(resolve => setTimeout(resolve, 700));
      
      if (entry) {
        setLookupResult(entry);
        toast({
          title: "Kelime Bulundu",
          description: `"${wordToLookup}" kelimesi için sonuçlar gösteriliyor.`,
        });
      } else {
        setLookupResult(null);
        toast({
          title: "Kelime Bulunamadı",
          description: `"${wordToLookup}" kelimesi sözlükte bulunamadı.`,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Sözlük hatası:", error);
      toast({
        title: "Sözlük Hatası",
        description: "Kelime aranırken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsLookingUp(false);
    }
  };
  
  return (
    <Card className={`${className || ''}`}>
      <CardHeader>
        <CardTitle>Çeviri ve Dil Araçları</CardTitle>
        <CardDescription>
          PDF içeriklerini çevirin, metinleri farklı dillere aktarın ve sözlük araması yapın
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="pdf-translate" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span className="hidden sm:inline">PDF Çeviri</span>
            </TabsTrigger>
            
            <TabsTrigger value="text-translate" className="flex items-center gap-2">
              <ArrowRight className="h-4 w-4" />
              <span className="hidden sm:inline">Metin Çeviri</span>
            </TabsTrigger>
            
            <TabsTrigger value="dictionary" className="flex items-center gap-2">
              <BookText className="h-4 w-4" />
              <span className="hidden sm:inline">Sözlük</span>
            </TabsTrigger>
          </TabsList>
          
          {/* PDF Çeviri Sekmesi */}
          <TabsContent value="pdf-translate" className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end gap-4 mb-4">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Kaynak Dil</label>
                <Select value={pdfSourceLang} onValueChange={setPdfSourceLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kaynak dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Hedef Dil</label>
                <Select value={pdfTargetLang} onValueChange={setPdfTargetLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Hedef dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button
                onClick={handleTranslatePdf}
                disabled={isTranslatingPdf || !pdfText || pdfText.length === 0}
                className="w-full md:w-auto shrink-0"
              >
                {isTranslatingPdf ? (
                  <>
                    <span className="animate-spin mr-2">⟳</span>
                    Çevriliyor...
                  </>
                ) : (
                  <>PDF'i Çevir</>
                )}
              </Button>
            </div>
            
            {!pdfText || pdfText.length === 0 ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>PDF Bulunamadı</AlertTitle>
                <AlertDescription>
                  Çeviri yapmak için önce bir PDF yüklemeniz veya açmanız gerekiyor.
                </AlertDescription>
              </Alert>
            ) : translatedPdfText.length > 0 ? (
              <div className="space-y-4">
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertTitle>Çeviri Tamamlandı</AlertTitle>
                  <AlertDescription>
                    PDF içeriği {pdfSourceLang} dilinden {pdfTargetLang} diline başarıyla çevrildi.
                  </AlertDescription>
                </Alert>
                
                <div className="border rounded-md p-4 max-h-60 overflow-y-auto bg-muted/30">
                  <h3 className="text-sm font-medium mb-2">Çeviri Önizleme (ilk sayfa):</h3>
                  <p className="text-sm whitespace-pre-wrap">
                    {translatedPdfText[0]?.substring(0, 500)}
                    {translatedPdfText[0]?.length > 500 ? '...' : ''}
                  </p>
                </div>
              </div>
            ) : null}
          </TabsContent>
          
          {/* Metin Çeviri Sekmesi */}
          <TabsContent value="text-translate" className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end gap-4 mb-4">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Kaynak Dil</label>
                <Select value={textSourceLang} onValueChange={setTextSourceLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kaynak dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Hedef Dil</label>
                <Select value={textTargetLang} onValueChange={setTextTargetLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Hedef dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button
                onClick={handleTranslateText}
                disabled={isTranslatingText || !textToTranslate.trim()}
                className="w-full md:w-auto shrink-0"
              >
                {isTranslatingText ? (
                  <>
                    <span className="animate-spin mr-2">⟳</span>
                    Çevriliyor...
                  </>
                ) : (
                  <>Metni Çevir</>
                )}
              </Button>
            </div>
            
            <div className="space-y-4">
              <Textarea
                placeholder="Çevrilecek metni girin..."
                value={textToTranslate}
                onChange={(e) => setTextToTranslate(e.target.value)}
                rows={5}
              />
              
              {translatedText && (
                <>
                  <div className="border-t pt-4 mt-4">
                    <h3 className="text-sm font-medium mb-2">Çeviri Sonucu:</h3>
                    <div className="border rounded-md p-4 bg-muted/30">
                      <p className="whitespace-pre-wrap">{translatedText}</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(translatedText);
                        toast({
                          title: "Kopyalandı",
                          description: "Çeviri sonucu panoya kopyalandı.",
                        });
                      }}
                    >
                      Çeviriyi Kopyala
                    </Button>
                  </div>
                </>
              )}
            </div>
          </TabsContent>
          
          {/* Sözlük Sekmesi */}
          <TabsContent value="dictionary" className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Aranacak kelime..."
                value={wordToLookup}
                onChange={(e) => setWordToLookup(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleLookupWord();
                  }
                }}
                className="flex-1"
              />
              
              <Button
                onClick={handleLookupWord}
                disabled={isLookingUp || !wordToLookup.trim()}
              >
                {isLookingUp ? (
                  <>
                    <span className="animate-spin mr-2">⟳</span>
                    Aranıyor...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Ara
                  </>
                )}
              </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Kaynak Dil</label>
                <Select value={dictionarySourceLang} onValueChange={setDictionarySourceLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kaynak dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Hedef Dil</label>
                <Select value={dictionaryTargetLang} onValueChange={setDictionaryTargetLang}>
                  <SelectTrigger>
                    <SelectValue placeholder="Hedef dil seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {lookupResult ? (
              <div className="border rounded-md p-4 bg-muted/30">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-lg font-bold">{lookupResult.word}</h3>
                    {lookupResult.phonetic && (
                      <p className="text-sm text-muted-foreground">{lookupResult.phonetic}</p>
                    )}
                  </div>
                </div>
                
                {/* Anlamlar */}
                <div className="space-y-4 mt-4">
                  {lookupResult.meanings.map((meaning: any, i: number) => (
                    <div key={i}>
                      <h4 className="font-medium text-sm">{meaning.partOfSpeech}</h4>
                      <ul className="list-disc list-inside mt-2 space-y-2">
                        {meaning.definitions.map((def: any, j: number) => (
                          <li key={j} className="text-sm">
                            {def.definition}
                            {def.example && (
                              <p className="text-muted-foreground italic pl-5 mt-1">
                                "{def.example}"
                              </p>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
                
                {/* Çeviriler */}
                {lookupResult.translations && lookupResult.translations.length > 0 && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="font-medium mb-2">Çeviriler</h4>
                    <div className="flex flex-wrap gap-2">
                      {lookupResult.translations.map((translation: any, i: number) => (
                        <div key={i} className="bg-primary/10 rounded px-2 py-1 text-sm">
                          {translation.text} 
                          {translation.partOfSpeech && <span className="text-xs text-muted-foreground"> ({translation.partOfSpeech})</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : wordToLookup.trim() && !isLookingUp ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Sonuç Bulunamadı</AlertTitle>
                <AlertDescription>
                  "{wordToLookup}" kelimesi için sözlükte sonuç bulunamadı.
                </AlertDescription>
              </Alert>
            ) : null}

            <div className="text-xs text-muted-foreground mt-2">
              Not: Şu anda demo sözlüğünde 'hello', 'world', 'computer', 'programming', 'merhaba' ve 'dünya' kelimelerini arayabilirsiniz.
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TranslationTools;