import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Edit, Trash2, AlertCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface TextElement {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize?: number;
  fontFamily?: string;
}

interface TextElementsEditorProps {
  textElements: TextElement[];
  isLoading: boolean;
  onUpdateText: (textId: string, newText: string, options?: { fontSize?: number; fontColor?: string }) => Promise<void>;
  onDeleteText: (textId: string) => Promise<void>;
}

const TextElementsEditor: React.FC<TextElementsEditorProps> = ({
  textElements,
  isLoading,
  onUpdateText,
  onDeleteText,
}) => {
  const [selectedElement, setSelectedElement] = useState<TextElement | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editedText, setEditedText] = useState("");
  const [editedFontSize, setEditedFontSize] = useState<number>(12);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleEditClick = (element: TextElement) => {
    setSelectedElement(element);
    setEditedText(element.text);
    setEditedFontSize(element.fontSize || 12);
    setEditDialogOpen(true);
  };

  const handleDeleteClick = (element: TextElement) => {
    setSelectedElement(element);
    setDeleteDialogOpen(true);
  };

  const handleEditSave = async () => {
    if (!selectedElement) return;
    
    setIsSaving(true);
    try {
      await onUpdateText(selectedElement.id, editedText, {
        fontSize: editedFontSize,
      });
      setEditDialogOpen(false);
    } catch (error) {
      console.error("Düzenleme hatası:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!selectedElement) return;
    
    setIsDeleting(true);
    try {
      await onDeleteText(selectedElement.id);
      setDeleteDialogOpen(false);
    } catch (error) {
      console.error("Silme hatası:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <Card className="p-6 flex flex-col items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary mb-2" />
        <p>PDF metinleri yükleniyor...</p>
      </Card>
    );
  }

  if (textElements.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex flex-col items-center text-center text-muted-foreground">
          <AlertCircle className="w-10 h-10 mb-2 text-amber-500" />
          <h3 className="text-lg font-medium mb-1">PDF içinde düzenlenebilir metin bulunamadı</h3>
          <p className="text-sm">
            PDF dosyası taranmış bir görüntü veya düzenlenebilir metinler içermiyor olabilir.
            OCR kullanarak PDF içeriğinden metin çıkarabilirsiniz.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">PDF İçindeki Metinler</h3>
      <p className="text-sm text-muted-foreground mb-4">
        PDF içerisindeki metinleri düzenlemek veya silmek için aşağıdaki listeyi kullanabilirsiniz.
      </p>
      
      <div className="space-y-2 max-h-[400px] overflow-auto pr-2">
        {textElements.map((element) => (
          <Card key={element.id} className="p-3 hover:bg-accent/30 transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="font-medium text-sm mb-1 line-clamp-1">{element.text}</p>
                <div className="flex gap-2 text-xs text-muted-foreground">
                  <span>
                    Konum: ({Math.round(element.x)}, {Math.round(element.y)})
                  </span>
                  <span>•</span>
                  <span>
                    Boyut: {element.fontSize ? `${Math.round(element.fontSize)}px` : "Bilinmiyor"}
                  </span>
                </div>
              </div>
              <div className="flex space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleEditClick(element)}
                >
                  <Edit className="h-4 w-4" />
                  <span className="sr-only">Düzenle</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 hover:text-destructive"
                  onClick={() => handleDeleteClick(element)}
                >
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Sil</span>
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Düzenleme Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Metni Düzenle</DialogTitle>
            <DialogDescription>
              PDF içerisindeki metni düzenleyin. Değişiklikler PDF'e kaydedilecektir.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Metin İçeriği</label>
              <Input
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                placeholder="Metin içeriği"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Font Boyutu (px)</label>
              <Input
                type="number"
                value={editedFontSize}
                onChange={(e) => setEditedFontSize(Number(e.target.value))}
                min={8}
                max={72}
                step={1}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              İptal
            </Button>
            <Button onClick={handleEditSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Kaydediliyor...
                </>
              ) : (
                "Değişiklikleri Kaydet"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Silme Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Metni Silmek İstediğinize Emin misiniz?</AlertDialogTitle>
            <AlertDialogDescription>
              Bu işlem geri alınamaz. PDF'den seçili metin silinecektir.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>İptal</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={isDeleting}
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Siliniyor...
                </>
              ) : (
                "Evet, Metni Sil"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default TextElementsEditor;