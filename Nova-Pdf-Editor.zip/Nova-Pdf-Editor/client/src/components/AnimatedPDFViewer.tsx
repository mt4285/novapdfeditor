import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from 'lucide-react';
import { Document, Page, pdfjs } from 'react-pdf';
import { Skeleton } from "@/components/ui/skeleton";
import PDFPageNavigator from './PDFPageNavigator';

// PDF.js worker URL tanımla
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

// Transition efekt tipleri
export type TransitionEffect = 'slide' | 'fade' | 'zoom' | 'flip' | 'cube';

interface AnimatedPDFViewerProps {
  pdfUrl: string;
  currentPage: number;
  totalPages: number;
  onPageChange: (pageNumber: number) => void;
  transitionEffect?: TransitionEffect;
  transitionDuration?: number;
  onTotalPagesChange?: (totalPages: number) => void;
  className?: string;
}

const AnimatedPDFViewer: React.FC<AnimatedPDFViewerProps> = ({
  pdfUrl,
  currentPage,
  totalPages,
  onPageChange,
  transitionEffect = 'slide',
  transitionDuration = 0.5,
  onTotalPagesChange,
  className = ''
}) => {
  const [numPages, setNumPages] = useState<number>(totalPages);
  const [zoom, setZoom] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [direction, setDirection] = useState<1 | -1>(1); // 1: ileri, -1: geri
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Animasyon varyantları
  const variants = {
    // Kaydırma animasyonu
    slide: {
      enter: (direction: number) => ({
        x: direction > 0 ? '100%' : '-100%',
        opacity: 0
      }),
      center: {
        x: 0,
        opacity: 1
      },
      exit: (direction: number) => ({
        x: direction < 0 ? '100%' : '-100%',
        opacity: 0
      })
    },
    // Solma animasyonu
    fade: {
      enter: { opacity: 0 },
      center: { opacity: 1 },
      exit: { opacity: 0 }
    },
    // Yakınlaştırma animasyonu
    zoom: {
      enter: { 
        scale: 0.8, 
        opacity: 0 
      },
      center: { 
        scale: 1, 
        opacity: 1 
      },
      exit: { 
        scale: 0.8, 
        opacity: 0 
      }
    },
    // 3D çevirme animasyonu
    flip: {
      enter: (direction: number) => ({
        rotateY: direction > 0 ? 90 : -90,
        opacity: 0
      }),
      center: {
        rotateY: 0,
        opacity: 1
      },
      exit: (direction: number) => ({
        rotateY: direction < 0 ? 90 : -90,
        opacity: 0
      })
    },
    // 3D küp efekti
    cube: {
      enter: (direction: number) => ({
        rotateY: direction > 0 ? 90 : -90,
        z: -200,
        opacity: 0.5
      }),
      center: {
        rotateY: 0,
        z: 0,
        opacity: 1
      },
      exit: (direction: number) => ({
        rotateY: direction < 0 ? 90 : -90,
        z: -200,
        opacity: 0.5
      })
    }
  };

  // Sayfa değişikliklerini izle
  useEffect(() => {
    if (currentPage > numPages) {
      onPageChange(numPages);
    }
  }, [currentPage, numPages, onPageChange]);

  // PDF yükleme başarısı
  const handleDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setIsLoading(false);
    if (onTotalPagesChange) {
      onTotalPagesChange(numPages);
    }
  };

  // PDF yükleme hatası
  const handleDocumentLoadError = (error: Error) => {
    console.error('PDF yükleme hatası:', error);
    setError(`PDF yüklenirken hata oluştu: ${error.message}`);
    setIsLoading(false);
  };

  // Yakınlaştırma işlevleri
  const handleZoomIn = () => {
    setZoom(prevZoom => Math.min(prevZoom + 0.2, 3));
  };

  const handleZoomOut = () => {
    setZoom(prevZoom => Math.max(prevZoom - 0.2, 0.6));
  };

  // Sayfa geçişleri
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setDirection(-1);
      onPageChange(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < numPages) {
      setDirection(1);
      onPageChange(currentPage + 1);
    }
  };

  // Klavye navigasyonu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handlePrevPage();
      } else if (e.key === 'ArrowRight') {
        handleNextPage();
      } else if (e.key === '+') {
        handleZoomIn();
      } else if (e.key === '-') {
        handleZoomOut();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentPage, numPages]);

  return (
    <div className={`flex flex-col w-full h-full ${className}`}>
      {/* PDF Kontrol Araçları */}
      <div className="flex justify-between items-center p-2 bg-muted/30 rounded-t-lg mb-2">
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={handleZoomOut}
            disabled={zoom <= 0.6}
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm">{Math.round(zoom * 100)}%</span>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={handleZoomIn}
            disabled={zoom >= 3}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
        
        <PDFPageNavigator 
          currentPage={currentPage} 
          totalPages={numPages} 
          onPageChange={onPageChange} 
        />
      </div>
      
      {/* PDF Görüntüleyici */}
      <div 
        ref={containerRef}
        className="relative flex-1 flex justify-center items-center overflow-hidden bg-muted/20 rounded-lg"
        style={{ perspective: '1000px' }} // 3D efektler için
      >
        {error ? (
          <div className="p-4 text-red-500">{error}</div>
        ) : (
          <>
            <Document
              file={pdfUrl}
              onLoadSuccess={handleDocumentLoadSuccess}
              onLoadError={handleDocumentLoadError}
              loading={
                <div className="flex flex-col items-center justify-center w-full h-full">
                  <Skeleton className="h-[80vh] w-[80%] rounded-md" />
                  <span className="mt-4 text-muted-foreground">PDF yükleniyor...</span>
                </div>
              }
              className="flex justify-center"
            >
              <AnimatePresence initial={false} custom={direction} mode="wait">
                <motion.div
                  key={currentPage}
                  custom={direction}
                  variants={variants[transitionEffect]}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{
                    duration: transitionDuration,
                    type: transitionEffect === 'cube' || transitionEffect === 'flip' ? 'spring' : 'tween',
                    stiffness: transitionEffect === 'cube' || transitionEffect === 'flip' ? 300 : undefined,
                    damping: transitionEffect === 'cube' || transitionEffect === 'flip' ? 30 : undefined
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    justifyContent: 'center',
                    transformStyle: 'preserve-3d',
                  }}
                >
                  <Page
                    pageNumber={currentPage}
                    scale={zoom}
                    renderTextLayer={false}
                    renderAnnotationLayer={false}
                    loading={
                      <Skeleton className="h-[60vh] w-[60%] rounded-md" />
                    }
                    className="shadow-lg"
                  />
                </motion.div>
              </AnimatePresence>
            </Document>
            
            {/* Navigasyon Butonları */}
            <div className="absolute inset-0 pointer-events-none flex justify-between items-center px-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handlePrevPage}
                disabled={currentPage <= 1 || isLoading}
                className="h-12 w-12 rounded-full bg-background/50 backdrop-blur-sm pointer-events-auto"
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={handleNextPage}
                disabled={currentPage >= numPages || isLoading}
                className="h-12 w-12 rounded-full bg-background/50 backdrop-blur-sm pointer-events-auto"
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AnimatedPDFViewer;