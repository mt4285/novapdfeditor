import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, ChevronRight, RotateCcw, RotateCw } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface PDFPageNavigatorProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (pageNumber: number) => void;
  onRotate?: (rotation: number) => void;
  currentRotation?: number;
  className?: string;
}

const PDFPageNavigator: React.FC<PDFPageNavigatorProps> = ({
  currentPage,
  totalPages,
  onPageChange,
  onRotate,
  currentRotation = 0,
  className
}) => {
  const [inputPage, setInputPage] = useState<string>(currentPage.toString());
  const [rotation, setRotation] = useState<number>(currentRotation);

  // Sayfa navigasyonu
  const goToPreviousPage = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  const goToFirstPage = () => {
    onPageChange(1);
  };

  const goToLastPage = () => {
    onPageChange(totalPages);
  };

  // Belirli bir sayfaya gitme
  const handleGoToPage = (e: React.FormEvent) => {
    e.preventDefault();
    
    const pageNum = parseInt(inputPage, 10);
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages) {
      onPageChange(pageNum);
    } else {
      // Geçersiz giriş durumunda mevcut sayfayı göster
      setInputPage(currentPage.toString());
    }
  };

  // Sayfa giriş değişikliği
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputPage(e.target.value);
  };

  // Sayfa döndürme
  const handleRotate = (direction: 'clockwise' | 'counterclockwise') => {
    if (!onRotate) return;
    
    let newRotation: number;
    
    if (direction === 'clockwise') {
      newRotation = (rotation + 90) % 360;
    } else {
      newRotation = (rotation - 90 + 360) % 360;
    }
    
    setRotation(newRotation);
    onRotate(newRotation);
  };

  return (
    <TooltipProvider>
      <div className={`flex items-center justify-between bg-gray-50 dark:bg-gray-800 p-2 rounded ${className}`}>
        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={goToFirstPage}
                disabled={currentPage <= 1}
              >
                <ChevronLeft className="h-4 w-4" />
                <ChevronLeft className="h-4 w-4 -ml-2" />
                <span className="sr-only">İlk Sayfa</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>İlk Sayfa</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={goToPreviousPage}
                disabled={currentPage <= 1}
              >
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Önceki Sayfa</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Önceki Sayfa</p>
            </TooltipContent>
          </Tooltip>
          
          <form onSubmit={handleGoToPage} className="flex items-center mx-2">
            <Input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={inputPage}
              onChange={handleInputChange}
              className="w-12 h-8 text-center text-sm"
              aria-label="Sayfa numarası"
            />
            <span className="mx-1 text-sm font-medium">/</span>
            <span className="text-sm font-medium">{totalPages}</span>
          </form>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={goToNextPage}
                disabled={currentPage >= totalPages}
              >
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Sonraki Sayfa</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Sonraki Sayfa</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={goToLastPage}
                disabled={currentPage >= totalPages}
              >
                <ChevronRight className="h-4 w-4" />
                <ChevronRight className="h-4 w-4 -ml-2" />
                <span className="sr-only">Son Sayfa</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Son Sayfa</p>
            </TooltipContent>
          </Tooltip>
        </div>
        
        {onRotate && (
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleRotate('counterclockwise')}
                >
                  <RotateCcw className="h-4 w-4" />
                  <span className="sr-only">Saat Yönünün Tersine Döndür</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Saat Yönünün Tersine Döndür</p>
              </TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleRotate('clockwise')}
                >
                  <RotateCw className="h-4 w-4" />
                  <span className="sr-only">Saat Yönünde Döndür</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Saat Yönünde Döndür</p>
              </TooltipContent>
            </Tooltip>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
};

export default PDFPageNavigator;