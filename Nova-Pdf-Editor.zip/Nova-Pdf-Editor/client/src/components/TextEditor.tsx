import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Check, X, Pencil, Type, AlignLeft, AlignCenter, AlignRight, AlignJustify, Bold, Italic, Underline } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

interface TextEditorProps {
  selectedText: string | null;
  selectedItemIndex: number | null;
  onTextUpdate?: (newText: string, itemIndex: number, formatting?: TextFormatting) => void;
  onCancel?: () => void;
}

export interface TextFormatting {
  fontSize?: number;
  fontFamily?: string;
  fontColor?: string;
  textAlign?: 'left' | 'center' | 'right' | 'justify';
  fontWeight?: 'normal' | 'bold';
  fontStyle?: 'normal' | 'italic';
  textDecoration?: 'none' | 'underline';
}

const TextEditor: React.FC<TextEditorProps> = ({
  selectedText,
  selectedItemIndex,
  onTextUpdate,
  onCancel
}) => {
  const [editedText, setEditedText] = useState<string>('');
  
  // Text formatting state
  const [fontSize, setFontSize] = useState<number>(12);
  const [fontColor, setFontColor] = useState<string>('#000000');
  const [fontFamily, setFontFamily] = useState<string>('Arial');
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'right' | 'justify'>('left');
  const [isBold, setIsBold] = useState<boolean>(false);
  const [isItalic, setIsItalic] = useState<boolean>(false);
  const [isUnderlined, setIsUnderlined] = useState<boolean>(false);

  // Font ailesi seçenekleri
  const fontOptions = [
    { value: 'Arial', label: 'Arial' },
    { value: 'Helvetica', label: 'Helvetica' },
    { value: 'Times New Roman', label: 'Times New Roman' },
    { value: 'Courier New', label: 'Courier New' },
    { value: 'Georgia', label: 'Georgia' },
    { value: 'Verdana', label: 'Verdana' },
    { value: 'Tahoma', label: 'Tahoma' }
  ];

  // Font boyutu seçenekleri
  const fontSizeOptions = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];

  // Seçilen metin değiştiğinde, düzenleme alanını güncelle
  useEffect(() => {
    if (selectedText) {
      setEditedText(selectedText);
    } else {
      setEditedText('');
    }
  }, [selectedText]);

  // Metin değişikliklerini işle
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setEditedText(e.target.value);
  };

  // Metin güncelleme işlemi
  const handleUpdate = () => {
    if (onTextUpdate && selectedItemIndex !== null) {
      const formatting: TextFormatting = {
        fontSize,
        fontFamily,
        fontColor,
        textAlign,
        fontWeight: isBold ? 'bold' : 'normal',
        fontStyle: isItalic ? 'italic' : 'normal',
        textDecoration: isUnderlined ? 'underline' : 'none'
      };
      
      onTextUpdate(editedText, selectedItemIndex, formatting);
    }
  };

  // İptal etme işlemi
  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    }
  };

  // Font boyutu değiştirme işlemi
  const handleFontSizeChange = (value: string) => {
    const size = parseInt(value);
    if (!isNaN(size)) {
      setFontSize(size);
    }
  };

  // Font rengi değiştirme işlemi
  const handleFontColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFontColor(e.target.value);
  };

  // Font ailesi değiştirme işlemi
  const handleFontFamilyChange = (value: string) => {
    setFontFamily(value);
  };

  // Metin hizalama işlemi
  const handleTextAlignChange = (value: string) => {
    setTextAlign(value as 'left' | 'center' | 'right' | 'justify');
  };

  // Metin stilleri değiştirme işlemleri
  const toggleBold = () => setIsBold(!isBold);
  const toggleItalic = () => setIsItalic(!isItalic);
  const toggleUnderline = () => setIsUnderlined(!isUnderlined);

  // İşlemler etkin mi?
  const isEditorEnabled = selectedText !== null && selectedItemIndex !== null;

  return (
    <Card className={`p-4 ${isEditorEnabled ? '' : 'opacity-70'}`}>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center">
          <Type className="h-5 w-5 mr-2" />
          Metin Düzenleyici
        </h3>
        {isEditorEnabled && (
          <div className="text-sm text-blue-600">
            Öğe #{selectedItemIndex !== null ? selectedItemIndex + 1 : 0}
          </div>
        )}
      </div>

      <div className="space-y-4">
        {/* Metin Biçimlendirme Araç Çubuğu */}
        <div className="space-y-2">
          <Label>Metin Biçimlendirme</Label>
          <div className="flex flex-wrap gap-2 p-2 border rounded-md bg-gray-50">
            {/* Metin Stili */}
            <div className="flex space-x-1">
              <Button
                type="button"
                variant={isBold ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={toggleBold}
                disabled={!isEditorEnabled}
                title="Kalın"
              >
                <Bold className="h-4 w-4" />
              </Button>
              
              <Button
                type="button"
                variant={isItalic ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={toggleItalic}
                disabled={!isEditorEnabled}
                title="İtalik"
              >
                <Italic className="h-4 w-4" />
              </Button>
              
              <Button
                type="button"
                variant={isUnderlined ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={toggleUnderline}
                disabled={!isEditorEnabled}
                title="Altı Çizili"
              >
                <Underline className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Metin Hizalama */}
            <div className="flex space-x-1">
              <Button
                type="button"
                variant={textAlign === 'left' ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleTextAlignChange('left')}
                disabled={!isEditorEnabled}
                title="Sola Hizala"
              >
                <AlignLeft className="h-4 w-4" />
              </Button>
              
              <Button
                type="button"
                variant={textAlign === 'center' ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleTextAlignChange('center')}
                disabled={!isEditorEnabled}
                title="Ortala"
              >
                <AlignCenter className="h-4 w-4" />
              </Button>
              
              <Button
                type="button"
                variant={textAlign === 'right' ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleTextAlignChange('right')}
                disabled={!isEditorEnabled}
                title="Sağa Hizala"
              >
                <AlignRight className="h-4 w-4" />
              </Button>
              
              <Button
                type="button"
                variant={textAlign === 'justify' ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleTextAlignChange('justify')}
                disabled={!isEditorEnabled}
                title="İki Yana Yasla"
              >
                <AlignJustify className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Font Rengi Seçimi */}
            <div className="flex items-center ml-2">
              <input 
                type="color"
                value={fontColor}
                onChange={handleFontColorChange}
                disabled={!isEditorEnabled}
                className="w-8 h-8 border-0 p-0 m-0 rounded"
                title="Metin Rengi"
              />
            </div>
          </div>
        </div>
        
        {/* Metin Alanı */}
        <div className="space-y-2">
          <Label>Metin İçeriği</Label>
          <Textarea
            value={editedText}
            onChange={handleTextChange}
            disabled={!isEditorEnabled}
            className="min-h-[120px] font-mono"
            placeholder={isEditorEnabled ? "Metni düzenleyin..." : "Önce bir metin öğesi seçin..."}
          />
        </div>

        {/* Font Ayarları */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Font Ailesi</Label>
            <Select 
              value={fontFamily}
              onValueChange={handleFontFamilyChange}
              disabled={!isEditorEnabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Arial" />
              </SelectTrigger>
              <SelectContent>
                {fontOptions.map(option => (
                  <SelectItem 
                    key={option.value} 
                    value={option.value}
                    style={{ fontFamily: option.value }}
                  >
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Font Boyutu</Label>
            <Select 
              value={fontSize.toString()}
              onValueChange={handleFontSizeChange}
              disabled={!isEditorEnabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="12" />
              </SelectTrigger>
              <SelectContent>
                {fontSizeOptions.map(size => (
                  <SelectItem key={size} value={size.toString()}>
                    {size}px
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Örnek Görünüm */}
        <div className="p-3 border rounded-md bg-gray-50 min-h-[60px]">
          <div
            style={{
              fontSize: `${fontSize}px`,
              color: fontColor,
              fontFamily: `${fontFamily}, sans-serif`,
              textAlign: textAlign,
              fontWeight: isBold ? 'bold' : 'normal',
              fontStyle: isItalic ? 'italic' : 'normal',
              textDecoration: isUnderlined ? 'underline' : 'none'
            }}
          >
            {editedText || (isEditorEnabled ? "Metin önizleme" : "Metin seçilmedi")}
          </div>
        </div>

        {/* Düğmeler */}
        <div className="flex justify-end space-x-2 mt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCancel}
            disabled={!isEditorEnabled}
            className="flex items-center gap-1"
          >
            <X className="h-4 w-4" />
            İptal
          </Button>
          
          <Button
            onClick={handleUpdate}
            disabled={!isEditorEnabled || !editedText}
            className="flex items-center gap-1"
            size="sm"
          >
            <Check className="h-4 w-4" />
            Güncelle
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default TextEditor;