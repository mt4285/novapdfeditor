import React from 'react';
import { Button, ButtonProps } from "@/components/ui/button";
import { ChevronLeft } from 'lucide-react';
import { useLocation } from 'wouter';

interface BackButtonProps extends Omit<ButtonProps, 'onClick'> {
  target?: string;
  onBack?: () => void;
}

const BackButton: React.FC<BackButtonProps> = ({
  target = "/",
  onBack,
  className,
  children,
  ...props
}) => {
  const [_, navigate] = useLocation();

  const handleClick = () => {
    if (onBack) {
      onBack();
    } else if (target) {
      navigate(target);
    } else {
      // Tarayıcı geçmişinde geri git
      window.history.back();
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className={`flex items-center gap-1 ${className || ''}`}
      onClick={handleClick}
      {...props}
    >
      <ChevronLeft className="w-4 h-4" />
      {children || "Geri"}
    </Button>
  );
};

export default BackButton;