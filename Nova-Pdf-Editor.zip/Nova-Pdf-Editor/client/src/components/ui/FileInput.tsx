import React, { useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface FileInputProps {
  onFileSelected: (file: File) => void;
  accept?: string;
  disabled?: boolean;
  children?: React.ReactNode;
  className?: string;
  dropAreaClassName?: string;
  onDragEnter?: (event: React.DragEvent) => void;
  onDragLeave?: (event: React.DragEvent) => void;
  maxSizeMB?: number;
  acceptedFileTypes?: string[];
}

export const FileInput: React.FC<FileInputProps> = ({
  onFileSelected,
  accept = '*',
  disabled = false,
  children,
  className,
  dropAreaClassName,
  onDragEnter: onDragEnterProp,
  onDragLeave: onDragLeaveProp,
  maxSizeMB,
  acceptedFileTypes = [],
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      handleFileValidation(file);
    }
  };

  const handleFileValidation = (file: File) => {
    // Dosya boyutu kontrolü
    if (maxSizeMB && file.size > maxSizeMB * 1024 * 1024) {
      console.error(`Dosya çok büyük. Maksimum: ${maxSizeMB}MB, Seçilen: ${(file.size / (1024 * 1024)).toFixed(2)}MB`);
      return;
    }

    // Dosya türü kontrolü
    if (acceptedFileTypes.length > 0 && !acceptedFileTypes.includes(file.type)) {
      console.error(`Desteklenmeyen dosya türü: ${file.type}`);
      return;
    }

    onFileSelected(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
    onDragEnterProp?.(e);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    onDragLeaveProp?.(e);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      handleFileValidation(file);
    }
  };

  const handleClick = () => {
    inputRef.current?.click();
  };

  return (
    <div className={cn('relative', className)}>
      <input
        type="file"
        ref={inputRef}
        className="sr-only"
        accept={accept}
        onChange={handleFileChange}
        disabled={disabled}
      />
      <div
        className={cn(
          'cursor-pointer flex flex-col items-center justify-center',
          dropAreaClassName,
          dragOver && 'border-primary'
        )}
        onClick={handleClick}
        onDragOver={handleDragOver}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {children}
      </div>
    </div>
  );
};