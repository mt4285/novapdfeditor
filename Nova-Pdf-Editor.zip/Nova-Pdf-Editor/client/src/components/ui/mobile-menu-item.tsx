import React from "react";
import { cn } from "@/lib/utils";

interface MobileMenuItemProps {
  icon: React.ReactNode;
  label: string;
  description?: string;
  onClick: () => void;
  isPremium?: boolean;
  disabled?: boolean;
  className?: string;
}

export function MobileMenuItem({
  icon,
  label,
  description,
  onClick,
  isPremium = false,
  disabled = false,
  className,
}: MobileMenuItemProps) {
  return (
    <button
      className={cn(
        "w-full flex items-center p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors",
        disabled && "opacity-50",
        isPremium ? "text-amber-700 dark:text-amber-500" : "text-gray-700 dark:text-gray-300",
        className
      )}
      onClick={onClick}
      disabled={disabled}
    >
      <div
        className={cn(
          "p-2 rounded-lg mr-4",
          isPremium
            ? "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400"
            : "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
        )}
      >
        {icon}
      </div>
      <div className="flex-1 text-left">
        <div className="font-medium">{label}</div>
        {description && (
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{description}</div>
        )}
      </div>
      {isPremium && (
        <div className="text-xs font-semibold bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300 px-2 py-1 rounded">
          PRO
        </div>
      )}
    </button>
  );
}

export default MobileMenuItem;