// Yeni dosya
import { FileInput } from './FileInput';

export { FileInput as FileUpload };