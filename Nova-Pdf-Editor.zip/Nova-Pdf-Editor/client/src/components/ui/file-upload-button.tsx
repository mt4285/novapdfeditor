import React, { useRef, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Loader2, Upload } from "lucide-react";

interface FileUploadButtonProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  multiple?: boolean;
  label?: string;
  disabled?: boolean;
}

export const FileUploadButton: React.FC<FileUploadButtonProps> = ({
  onFileSelect,
  accept = "*",
  multiple = false,
  label = "Dosya Seç",
  disabled = false
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);

    // Tek dosya veya çoklu dosya işleme
    if (multiple) {
      // Çoklu dosya durumunda her bir dosyayı işle (opsiyonel)
      Array.from(files).forEach(file => {
        onFileSelect(file);
      });
    } else {
      // Tek dosya durumu
      onFileSelect(files[0]);
    }

    // İşlem tamamlandı
    setIsUploading(false);
    
    // Formu temizle (aynı dosyayı tekrar seçebilmek için)
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept={accept}
        multiple={multiple}
        className="hidden"
        disabled={disabled || isUploading}
      />
      <Button
        type="button"
        onClick={handleClick}
        disabled={disabled || isUploading}
        className="flex items-center gap-2"
      >
        {isUploading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Yükleniyor...
          </>
        ) : (
          <>
            <Upload className="h-4 w-4" />
            {label}
          </>
        )}
      </Button>
    </div>
  );
};