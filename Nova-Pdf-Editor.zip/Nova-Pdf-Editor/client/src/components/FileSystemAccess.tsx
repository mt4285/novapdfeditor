import React, { useState, useEffect } from 'react';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Button } from '@/components/ui/button';
import { Card } from "@/components/ui/card";
import { Folder, File, FilePlus, Download, Trash2, FolderOpen, RefreshCw } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

interface FileSystemAccessProps {
  onFileSelect?: (fileData: { path: string; data: string | Blob; name: string }) => void;
  onSaveFile?: (result: { uri: string; path: string; name: string }) => void;
  initialDirectory?: Directory;
  allowedExtensions?: string[];
  saveMode?: boolean;
  saveFileName?: string;
  saveFileData?: string;
  className?: string;
}

interface FileItem {
  name: string;
  path: string;
  isDirectory: boolean;
  type?: string; // mimeType yerine type kullanılır
  size?: number;
  ctime?: number;
  mtime?: number;
}

const FileSystemAccess: React.FC<FileSystemAccessProps> = ({
  onFileSelect,
  onSaveFile,
  initialDirectory = Directory.Documents,
  allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png'],
  saveMode = false,
  saveFileName,
  saveFileData,
  className
}) => {
  const [currentDirectory, setCurrentDirectory] = useState<string>('');
  const [directoryStack, setDirectoryStack] = useState<string[]>([]);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Yeni dizin adı için durum
  const [newDirectoryName, setNewDirectoryName] = useState<string>('');
  const [showNewDirectoryInput, setShowNewDirectoryInput] = useState(false);

  // Bileşen yüklendiğinde, başlangıç dizinini oku
  useEffect(() => {
    readDirectory('');
  }, []);

  // Belirtilen dizindeki dosyaları ve dizinleri oku
  const readDirectory = async (path: string) => {
    try {
      setIsLoading(true);
      setError(null);

      let directoryUri: string;
      
      if (path === '') {
        // Kök dizin
        directoryUri = '';
        setCurrentDirectory('');
        setDirectoryStack([]);
      } else {
        directoryUri = path;
        setCurrentDirectory(path);
      }

      // Dosya sisteminden dizin içeriğini oku
      const result = await Filesystem.readdir({
        path: directoryUri,
        directory: initialDirectory,
      });

      // Dosya ve dizinleri listele
      if (result.files) {
        // Dosyaları işle
        const fileItems: FileItem[] = await Promise.all(
          result.files.map(async (file) => {
            const filePath = directoryUri ? `${directoryUri}/${file.name}` : file.name;
            return {
              name: file.name,
              path: filePath,
              isDirectory: file.type === 'directory',
              type: file.type,
              size: file.size,
              ctime: file.ctime,
              mtime: file.mtime,
            };
          })
        );

        // Önce dizinler, sonra dosyalar olarak sırala
        fileItems.sort((a, b) => {
          if (a.isDirectory && !b.isDirectory) return -1;
          if (!a.isDirectory && b.isDirectory) return 1;
          return a.name.localeCompare(b.name);
        });

        setFiles(fileItems);
      } else {
        setFiles([]);
      }
    } catch (err) {
      console.error('Dizin okuma hatası:', err);
      setError('Dizin okunamadı. Lütfen izinleri kontrol edin.');
      toast({
        title: "Dosya Sistemi Hatası",
        description: "Dizin okunamadı. Lütfen izinleri kontrol edin.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Bir dosyayı seç ve içeriğini oku
  const selectFile = async (file: FileItem) => {
    if (file.isDirectory) {
      // Bir dizinse, o dizine gir
      navigateToDirectory(file.path);
      return;
    }

    // Bu bir dosya ise ve onFileSelect callback'i varsa
    if (onFileSelect) {
      try {
        setIsLoading(true);

        // Dosya uzantısını kontrol et
        const fileExtension = file.name.split('.').pop()?.toLowerCase();
        if (fileExtension && allowedExtensions.includes(fileExtension)) {
          // Dosyayı oku
          const result = await Filesystem.readFile({
            path: file.path,
            directory: initialDirectory,
            encoding: Encoding.UTF8,
          });

          // İçeriği callback ile bildir
          onFileSelect({
            path: file.path,
            data: result.data as string, // readFile işleminin sonucunu string olarak dönüştür
            name: file.name,
          });

          toast({
            title: "Dosya Seçildi",
            description: `${file.name} dosyası başarıyla seçildi.`,
          });
        } else {
          toast({
            title: "Desteklenmeyen Dosya Türü",
            description: `Bu dosya türü desteklenmiyor. Desteklenen türler: ${allowedExtensions.join(', ')}`,
            variant: "destructive",
          });
        }
      } catch (err) {
        console.error('Dosya okuma hatası:', err);
        toast({
          title: "Dosya Okuma Hatası",
          description: "Dosya okunamadı.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Belirtilen dizine git
  const navigateToDirectory = (directoryPath: string) => {
    // Mevcut dizini yığına ekle
    if (currentDirectory) {
      setDirectoryStack([...directoryStack, currentDirectory]);
    }
    
    // Yeni dizine git
    readDirectory(directoryPath);
  };

  // Bir üst dizine git
  const navigateUp = () => {
    if (directoryStack.length > 0) {
      // Yığından son dizini al
      const previousDirectory = directoryStack[directoryStack.length - 1];
      
      // Yığını güncelle
      setDirectoryStack(directoryStack.slice(0, -1));
      
      // Dizini oku
      readDirectory(previousDirectory);
    } else {
      // Kök dizine git
      readDirectory('');
    }
  };

  // Yeni dizin oluştur
  const createDirectory = async () => {
    if (!newDirectoryName.trim()) {
      toast({
        title: "Hata",
        description: "Lütfen geçerli bir dizin adı girin.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      const directoryPath = currentDirectory 
        ? `${currentDirectory}/${newDirectoryName}` 
        : newDirectoryName;
      
      await Filesystem.mkdir({
        path: directoryPath,
        directory: initialDirectory,
        recursive: false,
      });

      toast({
        title: "Dizin Oluşturuldu",
        description: `${newDirectoryName} dizini başarıyla oluşturuldu.`,
      });

      // Dizin listesini yenile
      readDirectory(currentDirectory);
      
      // Yeni dizin adını sıfırla
      setNewDirectoryName('');
      setShowNewDirectoryInput(false);
      
    } catch (err) {
      console.error('Dizin oluşturma hatası:', err);
      toast({
        title: "Dizin Oluşturma Hatası",
        description: "Dizin oluşturulamadı.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Dosya veya dizin sil
  const deleteItem = async (item: FileItem) => {
    try {
      setIsLoading(true);
      
      await Filesystem.deleteFile({
        path: item.path,
        directory: initialDirectory,
      });

      toast({
        title: item.isDirectory ? "Dizin Silindi" : "Dosya Silindi",
        description: `${item.name} başarıyla silindi.`,
      });

      // Dosya listesini yenile
      readDirectory(currentDirectory);
      
    } catch (err) {
      console.error('Silme hatası:', err);
      toast({
        title: "Silme Hatası",
        description: "Öğe silinemedi.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Dosya kaydet
  const saveFile = async () => {
    if (!saveFileName || !saveFileData) {
      toast({
        title: "Hata",
        description: "Dosya adı ve verisi gereklidir.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      const filePath = currentDirectory 
        ? `${currentDirectory}/${saveFileName}` 
        : saveFileName;
      
      const result = await Filesystem.writeFile({
        path: filePath,
        data: saveFileData,
        directory: initialDirectory,
        encoding: Encoding.UTF8,
      });

      if (onSaveFile) {
        onSaveFile({
          uri: result.uri,
          path: filePath,
          name: saveFileName,
        });
      }

      toast({
        title: "Dosya Kaydedildi",
        description: `${saveFileName} dosyası başarıyla kaydedildi.`,
      });
      
      // Dosya listesini yenile
      readDirectory(currentDirectory);
      
    } catch (err) {
      console.error('Dosya kaydetme hatası:', err);
      toast({
        title: "Dosya Kaydetme Hatası",
        description: "Dosya kaydedilemedi.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Dizin yolunu göster
  const renderPathBreadcrumbs = () => {
    if (!currentDirectory) {
      return <span className="text-sm font-medium">Ana Dizin</span>;
    }
    
    const parts = currentDirectory.split('/');
    return (
      <div className="flex items-center gap-1 text-sm overflow-x-auto pb-1">
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-6 px-2"
          onClick={() => readDirectory('')}
        >
          Ana Dizin
        </Button>
        
        {parts.map((part, index) => {
          const path = parts.slice(0, index + 1).join('/');
          return (
            <React.Fragment key={index}>
              <span>/</span>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 px-2"
                onClick={() => readDirectory(path)}
              >
                {part}
              </Button>
            </React.Fragment>
          );
        })}
      </div>
    );
  };

  return (
    <Card className={`p-4 ${className}`}>
      <div className="space-y-4">
        {/* Üst Çubuk - Gezinme Kontrolleri */}
        <div className="flex justify-between items-center">
          <Button
            variant="outline"
            size="sm"
            onClick={navigateUp}
            disabled={isLoading}
            className="h-8"
          >
            <Folder className="h-4 w-4 mr-1" />
            Üst Dizin
          </Button>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => readDirectory(currentDirectory)}
              disabled={isLoading}
              className="h-8"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            
            {!saveMode && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowNewDirectoryInput(!showNewDirectoryInput)}
                disabled={isLoading}
                className="h-8"
              >
                <FolderOpen className="h-4 w-4 mr-1" />
                Yeni Klasör
              </Button>
            )}
            
            {saveMode && saveFileName && saveFileData && (
              <Button
                variant="default"
                size="sm"
                onClick={saveFile}
                disabled={isLoading}
                className="h-8"
              >
                <Download className="h-4 w-4 mr-1" />
                Kaydet
              </Button>
            )}
          </div>
        </div>
        
        {/* Yeni Dizin Oluşturma Formu */}
        {showNewDirectoryInput && (
          <div className="flex gap-2">
            <input
              type="text"
              value={newDirectoryName}
              onChange={(e) => setNewDirectoryName(e.target.value)}
              placeholder="Yeni klasör adı"
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            />
            <Button
              variant="default"
              onClick={createDirectory}
              disabled={isLoading || !newDirectoryName.trim()}
              className="h-9"
            >
              <FilePlus className="h-4 w-4 mr-1" />
              Oluştur
            </Button>
          </div>
        )}
        
        {/* Mevcut Dizin Yolu */}
        <div className="border rounded-md p-2 bg-muted/50">
          {renderPathBreadcrumbs()}
        </div>
        
        <Separator />
        
        {/* Dosya Listesi */}
        <div className="min-h-[300px] max-h-[400px] overflow-y-auto">
          {isLoading ? (
            <div className="space-y-2">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="flex items-center gap-2 p-2">
                  <Skeleton className="h-6 w-6 rounded-md" />
                  <Skeleton className="h-5 w-full" />
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-10">
              <p className="text-red-500">{error}</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => readDirectory(currentDirectory)}
              >
                Yeniden Dene
              </Button>
            </div>
          ) : files.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <p>Bu dizin boş</p>
            </div>
          ) : (
            <div className="space-y-1">
              {files.map((file) => (
                <div
                  key={file.path}
                  className={`flex justify-between items-center p-2 rounded-md hover:bg-muted cursor-pointer ${
                    file.isDirectory ? 'bg-muted/50' : ''
                  }`}
                  onClick={() => selectFile(file)}
                >
                  <div className="flex items-center gap-2">
                    {file.isDirectory ? (
                      <Folder className="h-5 w-5 text-primary" />
                    ) : (
                      <File className="h-5 w-5 text-muted-foreground" />
                    )}
                    <span className="text-sm truncate max-w-[200px]">
                      {file.name}
                    </span>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 opacity-0 group-hover:opacity-100 hover:opacity-100"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteItem(file);
                    }}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default FileSystemAccess;