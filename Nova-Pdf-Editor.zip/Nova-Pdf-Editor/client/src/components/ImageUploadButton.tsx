import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Image, Upload } from "lucide-react";

interface ImageUploadButtonProps {
  onImageSelect: (file: File) => void;
  disabled?: boolean;
}

export default function ImageUploadButton({ onImageSelect, disabled = false }: ImageUploadButtonProps) {
  const [isHovering, setIsHovering] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const selectedFile = files[0];
      // Görüntü dosyası kontrolü
      if (!selectedFile.type.startsWith("image/")) {
        alert("Lütfen bir görüntü dosyası seçin (jpg, png, gif vb.)");
        return;
      }
      
      // Seçilen dosyayı üst bileşene ilet
      onImageSelect(selectedFile);
      
      // Dosya seçim alanını sıfırla (aynı dosyayı tekrar seçebilmek için)
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div>
      <Button
        variant="outline"
        size="sm"
        className="w-full flex items-center justify-center"
        onClick={handleButtonClick}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
        disabled={disabled}
      >
        <Image className="h-4 w-4 mr-2" />
        {isHovering ? "Görüntü Seçin" : "Görüntü Ekle"}
      </Button>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: "none" }}
        accept="image/*"
      />
    </div>
  );
}