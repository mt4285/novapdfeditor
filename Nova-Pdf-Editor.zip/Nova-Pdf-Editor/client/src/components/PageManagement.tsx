import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Trash, 
  Plus, 
  ArrowUp, 
  ArrowDown, 
  MoveHorizontal, 
  RotateCw, 
  RotateCcw 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PageManagementProps {
  totalPages: number;
  currentPage: number;
  onPageDelete?: (pageNumber: number) => void;
  onPageAdd?: (position: 'before' | 'after', sourcePage?: number) => void;
  onPagesReorder?: (fromPage: number, toPage: number) => void;
  onPageRotate?: (pageNumber: number, rotation: number) => void;
  onBlankPageAdd?: (position: 'start' | 'end' | 'after', afterPage?: number) => void;
  isProcessing?: boolean;
  className?: string;
}

export function PageManagement({ 
  totalPages, 
  currentPage, 
  onPageDelete, 
  onPageAdd, 
  onPagesReorder, 
  onPageRotate,
  onBlankPageAdd,
  isProcessing = false,
  className = ""
}: PageManagementProps) {
  const { toast } = useToast();
  const [showReorderDialog, setShowReorderDialog] = useState(false);
  const [showRotateDialog, setShowRotateDialog] = useState(false);
  const [showAddBlankDialog, setShowAddBlankDialog] = useState(false);
  const [fromPage, setFromPage] = useState<number>(currentPage);
  const [toPage, setToPage] = useState<number>(currentPage);
  const [rotation, setRotation] = useState<number>(0);
  const [addPosition, setAddPosition] = useState<'start' | 'end' | 'after'>('end');
  const [afterPage, setAfterPage] = useState<number>(currentPage);

  // Sayfa silme işlemi
  const handleDeletePage = () => {
    if (totalPages <= 1) {
      toast({
        title: "İşlem Başarısız",
        description: "En az bir sayfa bulunmalıdır.",
        variant: "destructive",
      });
      return;
    }

    if (onPageDelete) {
      onPageDelete(currentPage);
      toast({
        title: "Sayfa Silindi",
        description: `Sayfa ${currentPage} başarıyla silindi.`,
      });
    }
  };

  // Sayfa ekleme işlemi
  const handleAddPage = (position: 'before' | 'after') => {
    if (onPageAdd) {
      onPageAdd(position, currentPage);
      toast({
        title: "Sayfa Ekleme",
        description: `Sayfa ${position === 'before' ? 'öncesine' : 'sonrasına'} yeni sayfa ekleniyor.`,
      });
    }
  };

  // Sayfa yeniden sıralama işlemi
  const handleReorderPages = () => {
    if (!fromPage || !toPage || fromPage < 1 || toPage < 1 || fromPage > totalPages || toPage > totalPages) {
      toast({
        title: "Geçersiz Sayfa Numarası",
        description: "Lütfen geçerli sayfa numaraları girin.",
        variant: "destructive",
      });
      return;
    }

    if (fromPage === toPage) {
      toast({
        title: "Aynı Sayfa",
        description: "Kaynak ve hedef sayfa numaraları farklı olmalıdır.",
        variant: "destructive",
      });
      return;
    }

    if (onPagesReorder) {
      onPagesReorder(fromPage, toPage);
      toast({
        title: "Sayfalar Yeniden Sıralandı",
        description: `Sayfa ${fromPage}, sayfa ${toPage} ${fromPage < toPage ? 'sonrasına' : 'öncesine'} taşındı.`,
      });
      setShowReorderDialog(false);
    }
  };

  // Sayfa döndürme işlemi
  const handleRotatePage = () => {
    if (onPageRotate) {
      onPageRotate(currentPage, rotation);
      toast({
        title: "Sayfa Döndürüldü",
        description: `Sayfa ${currentPage}, ${rotation}° döndürüldü.`,
      });
      setShowRotateDialog(false);
    }
  };

  // Boş sayfa ekleme işlemi
  const handleAddBlankPage = () => {
    if (onBlankPageAdd) {
      onBlankPageAdd(addPosition, addPosition === 'after' ? afterPage : undefined);
      toast({
        title: "Boş Sayfa Eklendi",
        description: addPosition === 'start' 
          ? "Başa boş sayfa eklendi."
          : addPosition === 'end'
            ? "Sona boş sayfa eklendi."
            : `Sayfa ${afterPage} sonrasına boş sayfa eklendi.`,
      });
      setShowAddBlankDialog(false);
    }
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Sayfa Yönetimi</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Button 
            variant="secondary" 
            onClick={() => handleDeletePage()}
            disabled={isProcessing || totalPages <= 1}
            className="flex items-center gap-2"
          >
            <Trash className="h-4 w-4" />
            Sayfayı Sil
          </Button>
          
          <Dialog open={showReorderDialog} onOpenChange={setShowReorderDialog}>
            <DialogTrigger asChild>
              <Button 
                variant="secondary" 
                disabled={isProcessing || totalPages <= 1}
                className="flex items-center gap-2"
              >
                <MoveHorizontal className="h-4 w-4" />
                Yeniden Sırala
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Sayfaları Yeniden Sırala</DialogTitle>
                <DialogDescription>
                  Bir sayfayı başka bir konuma taşıyın.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col space-y-2">
                    <Label htmlFor="fromPage">Kaynak Sayfa</Label>
                    <Input
                      id="fromPage"
                      type="number"
                      min={1}
                      max={totalPages}
                      value={fromPage}
                      onChange={(e) => setFromPage(Number(e.target.value))}
                    />
                  </div>
                  <div className="flex flex-col space-y-2">
                    <Label htmlFor="toPage">Hedef Sayfa</Label>
                    <Input
                      id="toPage"
                      type="number"
                      min={1}
                      max={totalPages}
                      value={toPage}
                      onChange={(e) => setToPage(Number(e.target.value))}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  type="submit" 
                  onClick={handleReorderPages}
                  disabled={!fromPage || !toPage || isProcessing}
                >
                  Taşı
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showRotateDialog} onOpenChange={setShowRotateDialog}>
            <DialogTrigger asChild>
              <Button 
                variant="secondary" 
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                <RotateCw className="h-4 w-4" />
                Döndür
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Sayfayı Döndür</DialogTitle>
                <DialogDescription>
                  Geçerli sayfayı belirtilen açıda döndürün.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Döndürme Açısı</Label>
                  <RadioGroup 
                    value={rotation.toString()} 
                    onValueChange={(value) => setRotation(Number(value))}
                    className="flex justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="90" id="r90" />
                      <Label htmlFor="r90">90°</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="180" id="r180" />
                      <Label htmlFor="r180">180°</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="270" id="r270" />
                      <Label htmlFor="r270">270°</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  type="submit" 
                  onClick={handleRotatePage}
                  disabled={!rotation || isProcessing}
                >
                  Döndür
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showAddBlankDialog} onOpenChange={setShowAddBlankDialog}>
            <DialogTrigger asChild>
              <Button 
                variant="secondary" 
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Boş Sayfa
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Boş Sayfa Ekle</DialogTitle>
                <DialogDescription>
                  Belgeye boş bir sayfa ekleyin.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Ekleme Konumu</Label>
                  <Select
                    value={addPosition}
                    onValueChange={(value: 'start' | 'end' | 'after') => setAddPosition(value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Konum seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="start">Başa Ekle</SelectItem>
                      <SelectItem value="end">Sona Ekle</SelectItem>
                      <SelectItem value="after">Belirli Sayfa Sonrasına Ekle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {addPosition === 'after' && (
                  <div className="space-y-2">
                    <Label htmlFor="afterPage">Sayfa Numarası</Label>
                    <Input
                      id="afterPage"
                      type="number"
                      min={1}
                      max={totalPages}
                      value={afterPage}
                      onChange={(e) => setAfterPage(Number(e.target.value))}
                    />
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button 
                  type="submit" 
                  onClick={handleAddBlankPage}
                  disabled={isProcessing || (addPosition === 'after' && !afterPage)}
                >
                  Ekle
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="flex justify-between items-center mt-2 space-x-2">
          <div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleAddPage('before')}
              disabled={isProcessing}
              className="flex items-center gap-1"
            >
              <ArrowUp className="h-3 w-3" />
              Öncesine Ekle
            </Button>
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onPageRotate && onPageRotate(currentPage, -90)}
              disabled={isProcessing} 
              className="p-0 w-8 h-8"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onPageRotate && onPageRotate(currentPage, 90)}
              disabled={isProcessing}
              className="p-0 w-8 h-8"
            >
              <RotateCw className="h-4 w-4" />
            </Button>
          </div>
          <div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleAddPage('after')}
              disabled={isProcessing}
              className="flex items-center gap-1"
            >
              Sonrasına Ekle
              <ArrowDown className="h-3 w-3" />
            </Button>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground text-center pt-2">
          {isProcessing ? 'İşlem yapılıyor...' : `Mevcut sayfa: ${currentPage} / ${totalPages}`}
        </div>
      </CardContent>
    </Card>
  );
}

export default PageManagement;