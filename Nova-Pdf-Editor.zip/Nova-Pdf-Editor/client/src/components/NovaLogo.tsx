import React from 'react';

interface NovaLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

const NovaLogo: React.FC<NovaLogoProps> = ({ 
  className = "",
  size = "md"
}) => {
  const sizeMap = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-20 w-20"
  };

  return (
    <img 
      src="/images/nova-logo.png" 
      alt="Nova PDF Editor Logo" 
      className={`${sizeMap[size]} ${className}`}
    />
  );
};

export default NovaLogo;