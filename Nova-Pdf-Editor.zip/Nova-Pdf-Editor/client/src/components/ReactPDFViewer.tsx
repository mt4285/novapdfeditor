import React, { useState, useEffect } from 'react';
import { Document, Page } from 'react-pdf';
import 'react-pdf/dist/Page/TextLayer.css';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { PDFTextItem } from '@/lib/pdf-edit-utils';
import { pdfjs } from '@/lib/pdf-config';

interface ReactPDFViewerProps {
  pdfUrl: string;
  currentPage: number;
  totalPages?: number;
  onPageChange?: (pageNumber: number) => void;
  onTextSelect?: (text: string, itemIndex: number, textItem?: PDFTextItem) => void;
}

const ReactPDFViewer: React.FC<ReactPDFViewerProps> = ({ 
  pdfUrl, 
  currentPage, 
  totalPages = 1,
  onPageChange,
  onTextSelect
}) => {
  const [numPages, setNumPages] = useState<number>(totalPages);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTextItem, setSelectedTextItem] = useState<number | null>(null);
  const [textItems, setTextItems] = useState<PDFTextItem[]>([]);

  // PDF yüklendiğinde toplam sayfa sayısını güncelliyoruz
  const handleDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    console.log("PDF başarıyla yüklendi. Toplam sayfa sayısı:", numPages);
    setNumPages(numPages);
    setIsLoading(false);
    
    if (onPageChange && totalPages !== numPages) {
      // Sayfa sayısını güncelle
      onPageChange(Math.min(currentPage, numPages));
    }
  };

  // PDF yüklenirken hata oluşursa
  const handleDocumentLoadError = (error: Error) => {
    console.error("PDF yükleme hatası:", error);
    setError(error.message);
    setIsLoading(false);
  };

  // Metin seçildiğinde
  const handleTextLayerItemClick = (itemIndex: number) => {
    if (onTextSelect && itemIndex >= 0) {
      // Metin katmanındaki öğeleri alalım
      const textItems = document.querySelectorAll('.react-pdf__Page__textContent span');
      if (textItems && textItems[itemIndex]) {
        const selectedText = textItems[itemIndex].textContent || '';
        setSelectedTextItem(itemIndex);
        onTextSelect(selectedText, itemIndex);
      }
    }
  };

  // Sayfa yükleme durumunda
  const handlePageLoadSuccess = async (page: any) => {
    console.log("Sayfa başarıyla yüklendi:", currentPage);
    
    try {
      // Sayfa boyutlarını al
      const viewport = page.getViewport({ scale: 1.0 });
      const width = viewport.width;
      const height = viewport.height;
      
      // Sayfadan metin içeriğini çıkarmaya çalış
      const textContent = await page.getTextContent();
      
      // PDF metin öğelerini oluştur
      const pdfTextItems: PDFTextItem[] = [];
      
      // Metin içeriği kontrolü ve uyarı gösterme
      if (!textContent.items || textContent.items.length === 0) {
        // Metin içermeyen PDF için kullanıcıya uyarı göster
        const warningDiv = document.createElement('div');
        warningDiv.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-amber-100 dark:bg-amber-800 text-amber-800 dark:text-amber-100 p-4 rounded-md shadow-md max-w-md text-center border border-amber-300 dark:border-amber-600';
        warningDiv.innerHTML = `
          <div class="flex items-center gap-2 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
            </svg>
            <span class="font-semibold">Metin İçeriği Bulunamadı</span>
          </div>
          <p class="text-sm">Bu PDF dosyasında düzenlenebilir metin içeriği bulunamadı. Dosya sadece görüntü içeriyor olabilir. OCR işlemi uygulamanız önerilir.</p>
          <button class="mt-2 text-xs bg-amber-200 dark:bg-amber-700 px-2 py-1 rounded hover:bg-amber-300 dark:hover:bg-amber-600">Kapat</button>
        `;
        
        document.body.appendChild(warningDiv);
        
        // 10 saniye sonra uyarıyı otomatik olarak kaldır
        setTimeout(() => {
          if (document.body.contains(warningDiv)) {
            document.body.removeChild(warningDiv);
          }
        }, 10000);
        
        // Kapat düğmesine tıklama işlevi
        const closeButton = warningDiv.querySelector('button');
        if (closeButton) {
          closeButton.addEventListener('click', () => {
            if (document.body.contains(warningDiv)) {
              document.body.removeChild(warningDiv);
            }
          });
        }
      }
      
      textContent.items.forEach((item: any, index: number) => {
        // Koordinatları dönüştür
        const transform = pdfjs.Util.transform(viewport.transform, item.transform);
        
        // Font yüksekliği (yaklaşık)
        const fontHeight = Math.sqrt((transform[2] * transform[2]) + (transform[3] * transform[3]));
        
        // Text genişliği (tahmin)
        const textWidth = item.str.length * fontHeight * 0.5; 
        
        pdfTextItems.push({
          text: item.str,
          x: transform[4],
          y: transform[5],
          width: textWidth,
          height: fontHeight,
          pageNumber: currentPage,
          itemIndex: index
        });
      });
      
      setTextItems(pdfTextItems);
      
      // Metin katmanındaki öğelere tıklanabilir olma özelliği ekle
      setTimeout(() => {
        const domTextItems = document.querySelectorAll('.react-pdf__Page__textContent span');
        domTextItems.forEach((item, index) => {
          if (item instanceof HTMLElement) {
            item.style.cursor = 'pointer';
            item.onclick = () => {
              handleTextLayerItemClick(index);
              
              // İlgili metin öğesi bilgilerini de geçir
              if (onTextSelect && index < pdfTextItems.length) {
                onTextSelect(pdfTextItems[index].text, index, pdfTextItems[index]);
              }
            };
            
            // Seçilmiş öğeyi vurgula
            if (selectedTextItem === index) {
              item.style.backgroundColor = 'rgba(0, 123, 255, 0.2)';
              item.style.border = '1px solid #007bff';
            } else {
              item.style.backgroundColor = '';
              item.style.border = '';
            }
          }
        });
      }, 500);
    } catch (error) {
      console.error("Sayfa metin çıkarma hatası:", error);
    }
  };

  // Önceki sayfaya git
  const goToPrevPage = () => {
    if (currentPage > 1 && onPageChange) {
      onPageChange(currentPage - 1);
    }
  };

  // Sonraki sayfaya git
  const goToNextPage = () => {
    if (currentPage < numPages && onPageChange) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-auto bg-white p-2 mb-2 max-h-[600px] w-full">
        {isLoading && (
          <div className="flex flex-col items-center justify-center min-h-[400px]">
            <Loader2 className="h-10 w-10 animate-spin text-primary mb-2" />
            <span>PDF yükleniyor...</span>
          </div>
        )}
        
        {error && (
          <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded mb-4">
            <p className="font-semibold">Hata:</p>
            <p>{error}</p>
          </div>
        )}
        
        <Document
          file={pdfUrl}
          onLoadSuccess={handleDocumentLoadSuccess}
          onLoadError={handleDocumentLoadError}
          loading={
            <div className="flex items-center justify-center h-96">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          }
          className="flex justify-center"
          error={
            <div className="p-8 text-center bg-red-50 border border-red-200 rounded-md">
              <div className="text-red-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-red-800 mb-2">PDF görüntülenemiyor</h3>
              <p className="text-sm text-red-600 mb-4">PDF dosyası react-pdf kütüphanesi ile yüklenemedi.</p>
              <div className="flex flex-col sm:flex-row gap-2 justify-center">
                <a 
                  href={pdfUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm inline-flex items-center justify-center"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  Yeni Sekmede Aç
                </a>
                <a 
                  href={pdfUrl} 
                  download 
                  className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm inline-flex items-center justify-center"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  İndir
                </a>
              </div>
            </div>
          }
        >
          {!isLoading && !error && (
            <Page
              pageNumber={currentPage}
              renderTextLayer={true}
              renderAnnotationLayer={true}
              onLoadSuccess={handlePageLoadSuccess}
              className="shadow-md"
              width={window.innerWidth > 768 ? 768 : window.innerWidth - 40}
              error={
                <div className="bg-red-100 p-4 rounded-md">
                  <p className="text-red-700 font-medium">Sayfa yüklenemedi.</p>
                  <p className="text-red-600 text-sm mt-1">Sayfa {currentPage} görüntülenirken bir hata oluştu.</p>
                </div>
              }
              // Not: customTextRenderer burada React bileşenleri döndürdüğünden TypeScript hatası verebilir
              // fakat react-pdf'in güncel versiyonlarında bu şekilde kullanımlar desteklenmektedir.
            />
          )}
        </Document>
      </div>
      
      {!isLoading && !error && (
        <div className="flex items-center justify-between w-full bg-gray-50 dark:bg-gray-800 p-2 rounded">
          <Button
            variant="outline"
            size="sm"
            onClick={goToPrevPage}
            disabled={currentPage <= 1}
          >
            Önceki Sayfa
          </Button>
          
          <span className="text-sm font-medium">
            Sayfa {currentPage} / {numPages}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={goToNextPage}
            disabled={currentPage >= numPages}
          >
            Sonraki Sayfa
          </Button>
        </div>
      )}
      
      {/* Seçilen metin göstergesi kaldırıldı */}
    </div>
  );
};

export default ReactPDFViewer;