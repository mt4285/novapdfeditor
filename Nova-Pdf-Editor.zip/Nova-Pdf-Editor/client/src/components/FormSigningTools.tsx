import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { 
  PenLine, 
  FormInput, 
  FileSignature,
  Square, 
  CircleIcon,
  ListOrdered,
  Info,
  CheckCircle2
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface FormSigningToolsProps {
  onAddFormField?: (type: string, params: any) => void;
  onAddSignature?: (signatureData: string, position: { x: number, y: number, width: number, height: number }) => void;
  currentPage: number;
  isProcessing?: boolean;
  className?: string;
}

export function FormSigningTools({
  onAddFormField,
  onAddSignature,
  currentPage,
  isProcessing = false,
  className = ""
}: FormSigningToolsProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("form-fields");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [formFieldType, setFormFieldType] = useState<string>("text");
  const [formFieldName, setFormFieldName] = useState<string>("");
  const [formFieldLabel, setFormFieldLabel] = useState<string>("");
  const [dropdownOptions, setDropdownOptions] = useState<string>("");
  const [signatureMode, setSignatureMode] = useState<'draw' | 'type'>('draw');
  const [typedName, setTypedName] = useState<string>("");
  const [typedSignatureFont, setTypedSignatureFont] = useState<string>("'Brush Script MT', cursive");
  
  // Form alanı ekleme
  const handleAddFormField = () => {
    if (!formFieldName) {
      toast({
        title: "Form Alanı Hatası",
        description: "Form alanı için bir isim gereklidir.",
        variant: "destructive",
      });
      return;
    }
    
    if (onAddFormField) {
      const params: any = {
        name: formFieldName,
        label: formFieldLabel || formFieldName,
        page: currentPage,
      };
      
      // Alan türüne göre ek parametreler
      if (formFieldType === "dropdown" && dropdownOptions) {
        params.options = dropdownOptions.split(',').map(opt => opt.trim());
      }
      
      onAddFormField(formFieldType, params);
      
      toast({
        title: "Form Alanı Eklendi",
        description: `"${formFieldName}" adlı ${getFormFieldTypeName(formFieldType)} alanı eklendi.`,
      });
      
      // Form alanlarını sıfırla
      setFormFieldName("");
      setFormFieldLabel("");
      setDropdownOptions("");
    }
  };
  
  // İmza ekleme
  const handleAddSignature = () => {
    if (signatureMode === 'draw') {
      if (!canvasRef.current) return;
      
      const canvas = canvasRef.current;
      const signatureData = canvas.toDataURL();
      
      if (isEmptyCanvas(canvas)) {
        toast({
          title: "İmza Hatası",
          description: "Lütfen imzanızı çizin veya yazın.",
          variant: "destructive",
        });
        return;
      }
      
      if (onAddSignature) {
        onAddSignature(signatureData, { 
          x: 100, // Örnek konum
          y: 100, // Örnek konum
          width: 200, 
          height: 100 
        });
        
        toast({
          title: "İmza Eklendi",
          description: "Çizilen imza belgeye eklendi.",
        });
        
        // Canvas'ı temizle
        clearCanvas();
      }
    } else if (signatureMode === 'type') {
      if (!typedName) {
        toast({
          title: "İmza Hatası",
          description: "Lütfen imza için adınızı girin.",
          variant: "destructive",
        });
        return;
      }
      
      if (onAddSignature) {
        // Yazılı imzayı Canvas'a çiz ve veri URL'si olarak al
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 100;
        const ctx = canvas.getContext('2d');
        
        if (ctx) {
          ctx.fillStyle = 'white';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          ctx.font = `30px ${typedSignatureFont}`;
          ctx.fillStyle = 'black';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(typedName, canvas.width / 2, canvas.height / 2);
          
          const signatureData = canvas.toDataURL();
          
          onAddSignature(signatureData, { 
            x: 100, // Örnek konum
            y: 100, // Örnek konum
            width: 200, 
            height: 100 
          });
          
          toast({
            title: "İmza Eklendi",
            description: "Yazılı imza belgeye eklendi.",
          });
          
          // İmza adını sıfırla
          setTypedName("");
        }
      }
    }
  };
  
  // Imza çizimi için mouse olayları
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      setIsDrawing(true);
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };
  
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };
  
  const stopDrawing = () => {
    setIsDrawing(false);
  };
  
  const clearCanvas = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      // Daha iyi görünüm için ince çerçeve çiz
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      ctx.strokeRect(0, 0, canvas.width, canvas.height);
      // Çizim ayarlarını geri al
      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
    }
  };
  
  // Canvas'ın boş olup olmadığını kontrol et
  const isEmptyCanvas = (canvas: HTMLCanvasElement): boolean => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return true;
    
    const pixelBuffer = new Uint32Array(
      ctx.getImageData(0, 0, canvas.width, canvas.height).data.buffer
    );
    
    // Alpha değeri sıfır olmayan piksel var mı kontrol et
    // (varsayılan olarak alpha'sı 0 olmayan her piksel çizilmiş kabul edilir)
    return !pixelBuffer.some(color => color & 0xFF000000);
  };
  
  // Canvas'ı başlat
  React.useEffect(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        // Canvas ayarları
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        // Daha iyi görünüm için ince çerçeve çiz
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1;
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
        // Çizim ayarlarını geri al
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
      }
    }
  }, [canvasRef]);
  
  // Form alanı türü adını döndür
  const getFormFieldTypeName = (type: string): string => {
    switch (type) {
      case 'text': return 'Metin';
      case 'checkbox': return 'Onay Kutusu';
      case 'radio': return 'Radyo Düğmesi';
      case 'dropdown': return 'Açılır Liste';
      default: return type;
    }
  };
  
  // Form alanı türü simgesini döndür
  const getFormFieldTypeIcon = (type: string): React.ReactNode => {
    switch (type) {
      case 'text': return <FormInput className="h-4 w-4" />;
      case 'checkbox': return <Square className="h-4 w-4" />;
      case 'radio': return <CircleIcon className="h-4 w-4" />;
      case 'dropdown': return <ListOrdered className="h-4 w-4" />;
      default: return <FormInput className="h-4 w-4" />;
    }
  };
  
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <FileSignature className="mr-2 h-5 w-5" />
          Form ve İmza Araçları
        </CardTitle>
        <CardDescription>
          PDF belgesine form alanları ekleyin veya belgeyi imzalayın
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-2 w-full">
            <TabsTrigger value="form-fields" className="flex items-center gap-2">
              <FormInput className="h-4 w-4" />
              <span>Form Alanları</span>
            </TabsTrigger>
            
            <TabsTrigger value="signature" className="flex items-center gap-2">
              <PenLine className="h-4 w-4" />
              <span>İmza</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Form Alanları Sekmesi */}
          <TabsContent value="form-fields" className="space-y-4">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="form-field-type">Alan Türü</Label>
                  <Select 
                    value={formFieldType} 
                    onValueChange={setFormFieldType}
                  >
                    <SelectTrigger id="form-field-type">
                      <SelectValue placeholder="Alan türü seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Metin Kutusu</SelectItem>
                      <SelectItem value="checkbox">Onay Kutusu</SelectItem>
                      <SelectItem value="radio">Radyo Düğmesi</SelectItem>
                      <SelectItem value="dropdown">Açılır Liste</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="form-field-name">
                    Alan Adı
                    <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="form-field-name"
                    value={formFieldName}
                    onChange={(e) => setFormFieldName(e.target.value)}
                    placeholder="örn: ad_soyad"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="form-field-label">Alan Etiketi</Label>
                <Input
                  id="form-field-label"
                  value={formFieldLabel}
                  onChange={(e) => setFormFieldLabel(e.target.value)}
                  placeholder="örn: Ad Soyad"
                />
              </div>
              
              {formFieldType === "dropdown" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="dropdown-options">
                      Seçenekler (virgülle ayırın)
                    </Label>
                    <Popover>
                      <PopoverTrigger>
                        <Info className="h-4 w-4 text-muted-foreground" />
                      </PopoverTrigger>
                      <PopoverContent className="w-80 text-sm">
                        <p>Seçenekleri virgül ile ayırın:</p>
                        <p className="text-muted-foreground mt-1">Örnek: Seçenek 1, Seçenek 2, Seçenek 3</p>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <Input
                    id="dropdown-options"
                    value={dropdownOptions}
                    onChange={(e) => setDropdownOptions(e.target.value)}
                    placeholder="Seçenek 1, Seçenek 2, Seçenek 3"
                  />
                </div>
              )}
              
              <Button 
                onClick={handleAddFormField}
                disabled={isProcessing || !formFieldName}
                className="w-full mt-2"
              >
                {getFormFieldTypeIcon(formFieldType)}
                <span className="ml-2">
                  {getFormFieldTypeName(formFieldType)} Alanı Ekle
                </span>
              </Button>
            </div>
            
            <div className="rounded-md border-2 border-dashed p-4 text-center text-sm text-muted-foreground mt-4">
              <p className="flex items-center justify-center gap-1">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Form alanları sayfa üzerine yerleştirilecektir
              </p>
              <p className="mt-1">
                Mevcut Sayfa: {currentPage}
              </p>
            </div>
          </TabsContent>
          
          {/* İmza Sekmesi */}
          <TabsContent value="signature" className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-center space-x-2 mb-2">
                <Button
                  variant={signatureMode === 'draw' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSignatureMode('draw')}
                >
                  <PenLine className="h-4 w-4 mr-2" />
                  İmza Çiz
                </Button>
                <Button
                  variant={signatureMode === 'type' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSignatureMode('type')}
                >
                  <FormInput className="h-4 w-4 mr-2" />
                  İmza Yaz
                </Button>
              </div>
              
              {signatureMode === 'draw' ? (
                <div className="space-y-3">
                  <div className="border rounded-md p-1 bg-white">
                    <canvas
                      ref={canvasRef}
                      width={300}
                      height={150}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      className="w-full cursor-crosshair"
                      style={{ touchAction: 'none' }}
                    />
                  </div>
                  
                  <div className="flex justify-between space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearCanvas}
                    >
                      Temizle
                    </Button>
                    <Button
                      onClick={handleAddSignature}
                      disabled={isProcessing}
                    >
                      İmza Ekle
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="typed-name">Adınız</Label>
                    <Input
                      id="typed-name"
                      value={typedName}
                      onChange={(e) => setTypedName(e.target.value)}
                      placeholder="İmzanız için adınızı girin"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signature-font">Yazı Tipi</Label>
                    <Select 
                      value={typedSignatureFont} 
                      onValueChange={setTypedSignatureFont}
                    >
                      <SelectTrigger id="signature-font">
                        <SelectValue placeholder="Yazı tipi seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="'Brush Script MT', cursive">El Yazısı</SelectItem>
                        <SelectItem value="'Dancing Script', cursive">Zarif El Yazısı</SelectItem>
                        <SelectItem value="'Times New Roman', serif">Klasik</SelectItem>
                        <SelectItem value="'Arial', sans-serif">Modern</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {typedName && (
                    <div className="border rounded-md p-4 mt-2 text-center bg-white">
                      <p 
                        className="text-2xl" 
                        style={{ fontFamily: typedSignatureFont }}
                      >
                        {typedName}
                      </p>
                    </div>
                  )}
                  
                  <Button
                    onClick={handleAddSignature}
                    disabled={isProcessing || !typedName}
                    className="w-full"
                  >
                    İmza Ekle
                  </Button>
                </div>
              )}
            </div>
            
            <div className="rounded-md border-2 border-dashed p-4 text-center text-sm text-muted-foreground mt-4">
              <p>İmzanız belgeye eklenecektir. İmza eklemek belgede kalıcı değişiklik yapar.</p>
              <p className="mt-1">Belgenin orijinalini saklamayı unutmayın.</p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default FormSigningTools;