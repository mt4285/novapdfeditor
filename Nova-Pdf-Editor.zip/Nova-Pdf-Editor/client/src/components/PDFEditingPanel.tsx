import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Italic, Bold, AlignCenter, AlignLeft, AlignRight, Type, ChevronLeft, ChevronRight, Image } from "lucide-react";
import ImageUploadButton from "./ImageUploadButton";

interface PDFEditingPanelProps {
  currentPage: number;
  totalPages: number;
  onPrevPage: () => void;
  onNextPage: () => void;
  onAddText: (text: string) => void;
  onAddImage?: (file: File) => void;
}

const PDFEditingPanel: React.FC<PDFEditingPanelProps> = ({
  currentPage,
  totalPages,
  onPrevPage,
  onNextPage,
  onAddText,
  onAddImage
}) => {
  const [text, setText] = useState("");
  const [fontSize, setFontSize] = useState(14);
  const [textColor, setTextColor] = useState("#000000");
  const [fontStyle, setFontStyle] = useState<"normal" | "italic" | "bold">("normal");
  const [alignment, setAlignment] = useState<"left" | "center" | "right">("left");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAddText(text);
      setText("");
    }
  };

  const colors = [
    { color: "#000000", name: "Siyah" },
    { color: "#FF0000", name: "Kırmızı" },
    { color: "#0000FF", name: "Mavi" },
    { color: "#008000", name: "Yeşil" },
    { color: "#800080", name: "Mor" },
  ];

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">PDF Düzenleme Paneli</h3>
      
      <div className="mb-4 flex items-center justify-between">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onPrevPage}
          disabled={currentPage <= 1}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Önceki
        </Button>
        
        <span className="font-medium">
          Sayfa {currentPage} / {totalPages}
        </span>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onNextPage}
          disabled={currentPage >= totalPages}
        >
          Sonraki
          <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="text-input">Eklenecek Metin</Label>
          <Textarea
            id="text-input"
            placeholder="Metni buraya yazın..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="min-h-[100px]"
          />
        </div>
        
        <div>
          <Label>Font Boyutu: {fontSize}px</Label>
          <Slider
            defaultValue={[fontSize]}
            min={8}
            max={36}
            step={1}
            onValueChange={(value) => setFontSize(value[0])}
            className="mt-2"
          />
        </div>
        
        <div>
          <Label>Yazı Rengi</Label>
          <div className="flex space-x-2 mt-2">
            {colors.map((c) => (
              <div 
                key={c.color}
                className={`w-8 h-8 rounded-full cursor-pointer transition ${textColor === c.color ? 'ring-2 ring-offset-2 ring-primary' : ''}`}
                style={{ backgroundColor: c.color }}
                onClick={() => setTextColor(c.color)}
                title={c.name}
              />
            ))}
            <Input
              type="color"
              value={textColor}
              onChange={(e) => setTextColor(e.target.value)}
              className="w-8 h-8 p-0 border-0"
              title="Özel renk seç"
            />
          </div>
        </div>
        
        <div>
          <Label>Yazı Stili</Label>
          <div className="flex space-x-2 mt-2">
            <Button 
              type="button"
              variant={fontStyle === "normal" ? "default" : "outline"} 
              size="sm"
              onClick={() => setFontStyle("normal")}
            >
              <Type className="h-4 w-4 mr-1" />
              Normal
            </Button>
            <Button 
              type="button"
              variant={fontStyle === "bold" ? "default" : "outline"} 
              size="sm"
              onClick={() => setFontStyle("bold")}
            >
              <Bold className="h-4 w-4 mr-1" />
              Kalın
            </Button>
            <Button 
              type="button"
              variant={fontStyle === "italic" ? "default" : "outline"} 
              size="sm"
              onClick={() => setFontStyle("italic")}
            >
              <Italic className="h-4 w-4 mr-1" />
              İtalik
            </Button>
          </div>
        </div>
        
        <div>
          <Label>Hizalama</Label>
          <div className="flex space-x-2 mt-2">
            <Button 
              type="button"
              variant={alignment === "left" ? "default" : "outline"} 
              size="sm"
              onClick={() => setAlignment("left")}
            >
              <AlignLeft className="h-4 w-4 mr-1" />
              Sola
            </Button>
            <Button 
              type="button"
              variant={alignment === "center" ? "default" : "outline"} 
              size="sm"
              onClick={() => setAlignment("center")}
            >
              <AlignCenter className="h-4 w-4 mr-1" />
              Ortala
            </Button>
            <Button 
              type="button"
              variant={alignment === "right" ? "default" : "outline"} 
              size="sm"
              onClick={() => setAlignment("right")}
            >
              <AlignRight className="h-4 w-4 mr-1" />
              Sağa
            </Button>
          </div>
        </div>
        
        <div className="pt-2">
          <Button type="submit" className="w-full">
            Metni PDF'e Ekle
          </Button>
        </div>
      </form>
      
      {/* Görüntü Ekleme Bölümü */}
      {onAddImage && (
        <div className="mt-4 border-t pt-4">
          <Label className="mb-2 block">Görüntü Ekle</Label>
          <div className="flex flex-col space-y-3">
            <ImageUploadButton onImageSelect={onAddImage} />
            <div className="text-sm text-gray-500">
              PDF'e eklemek istediğiniz görüntüyü (JPG, PNG vb.) seçin.
              Önce PDF'te bir konum seçmelisiniz.
            </div>
          </div>
        </div>
      )}
      
      <div className="mt-6 p-3 bg-gray-50 dark:bg-gray-800 rounded-md text-sm">
        <p className="text-gray-600 dark:text-gray-300 mb-2">
          <strong>Nasıl Kullanılır:</strong>
        </p>
        <ol className="list-decimal text-gray-600 dark:text-gray-300 pl-5 space-y-1">
          <li>PDF üzerinde metin veya görüntü eklemek istediğiniz yere tıklayın</li>
          <li>Eklemek istediğiniz metni yazın veya resim seçin</li>
          <li>Yazı tipi, boyutu ve rengi ayarlayın</li>
          <li>"Metni PDF'e Ekle" düğmesine basın veya görüntüyü ekleyin</li>
        </ol>
      </div>
    </Card>
  );
};

export default PDFEditingPanel;