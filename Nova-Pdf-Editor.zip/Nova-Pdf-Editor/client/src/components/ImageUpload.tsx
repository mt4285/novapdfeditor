import React, { useState, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Upload, Loader2, FileImage } from 'lucide-react';
import { Card } from "@/components/ui/card";

interface ImageUploadProps {
  onImagesSelected: (files: File[]) => void;
  isUploading?: boolean;
  selectedFiles?: File[];
  onReset?: () => void;
  maxImages?: number;
  title?: string;
  description?: string;
  acceptedFormats?: string;
}

const ImageUpload: React.FC<ImageUploadProps> = ({
  onImagesSelected,
  isUploading = false,
  selectedFiles = [],
  onReset,
  maxImages = 10,
  title = "Resim Yükle",
  description = "Resimlerinizi yükleyin, PDF'e dönüştürelim",
  acceptedFormats = ".jpg, .jpeg, .png, .gif, .bmp, .webp"
}) => {
  const { toast } = useToast();
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const validateFiles = (files: File[]): File[] => {
    // Sadece resim dosyaları kabul edilir
    const validImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp'];
    
    const validFiles = Array.from(files).filter(file => {
      if (!validImageTypes.includes(file.type)) {
        toast({
          title: "Desteklenmeyen dosya türü",
          description: `${file.name} desteklenen bir resim dosyası değil. Lütfen sadece JPG, PNG, GIF, BMP veya WEBP formatında dosyalar yükleyin.`,
          variant: "destructive",
        });
        return false;
      }
      return true;
    });
    
    // Maksimum dosya sayısı kontrolü
    if (selectedFiles.length + validFiles.length > maxImages) {
      toast({
        title: "Maksimum dosya sayısı aşıldı",
        description: `En fazla ${maxImages} resim yükleyebilirsiniz.`,
        variant: "destructive",
      });
      return validFiles.slice(0, maxImages - selectedFiles.length);
    }

    return validFiles;
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const validFiles = validateFiles(Array.from(e.dataTransfer.files));
      if (validFiles.length > 0) {
        onImagesSelected(validFiles);
      }
    }
  }, [onImagesSelected, maxImages, selectedFiles.length, toast]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const validFiles = validateFiles(Array.from(e.target.files));
      if (validFiles.length > 0) {
        onImagesSelected(validFiles);
      }
    }
  }, [onImagesSelected, maxImages, selectedFiles.length, toast]);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  return (
    <Card className={`p-6 ${isDragOver ? 'border-primary' : 'border-gray-200 dark:border-gray-800'}`}>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{title}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">{description}</p>
          </div>
          <FileImage className="h-8 w-8 text-gray-400 dark:text-gray-600" />
        </div>
        
        <div
          className={`border-2 border-dashed rounded-lg p-4 transition-colors ${
            isDragOver
              ? 'border-primary bg-primary/5'
              : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50'
          }`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <Upload className="h-10 w-10 text-gray-400 mb-2" />
            
            <p className="mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
              Resimleri buraya sürükleyin veya tıklayın
            </p>
            
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {acceptedFormats.replace(/\./g, '').toUpperCase()} formatları desteklenir
            </p>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => document.getElementById('file-upload')?.click()}
              className="mt-4"
              disabled={isUploading}
            >
              {isUploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Yükleniyor...
                </>
              ) : (
                'Resim Seç'
              )}
            </Button>
            
            <input
              id="file-upload"
              type="file"
              multiple
              accept={acceptedFormats}
              className="hidden"
              onChange={handleFileInputChange}
              disabled={isUploading}
            />
          </div>
        </div>
        
        {selectedFiles.length > 0 && (
          <div className="mt-4">
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Seçilen Resimler ({selectedFiles.length})
              </h4>
              
              {onReset && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onReset}
                  disabled={isUploading}
                  className="text-xs"
                >
                  Temizle
                </Button>
              )}
            </div>
            
            <div className="space-y-2 max-h-60 overflow-y-auto border rounded-md p-2">
              {selectedFiles.map((file, index) => (
                <div key={index} className="flex justify-between items-center text-sm p-2 border-b last:border-0">
                  <div className="flex items-center space-x-2 truncate">
                    <FileImage className="h-4 w-4 text-gray-400" />
                    <span className="truncate max-w-[200px]">{file.name}</span>
                  </div>
                  <span className="text-gray-500 text-xs">{formatFileSize(file.size)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default ImageUpload;