import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (kept from original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// PDF storage schema
export const pdfs = pgTable("pdfs", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalFilename: text("original_filename").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  createdAt: text("created_at").notNull(), // ISO string format
  updatedAt: text("updated_at").notNull(),  // ISO string format
});

export const insertPdfSchema = createInsertSchema(pdfs).omit({
  id: true,
});

// PDF edit history
export const pdfEdits = pgTable("pdf_edits", {
  id: serial("id").primaryKey(),
  pdfId: integer("pdf_id").notNull(),
  edits: text("edits").notNull(), // JSON string containing edit operations
  createdAt: text("created_at").notNull(), // ISO string format
});

export const insertPdfEditSchema = createInsertSchema(pdfEdits).omit({
  id: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPdf = z.infer<typeof insertPdfSchema>;
export type Pdf = typeof pdfs.$inferSelect;

export type InsertPdfEdit = z.infer<typeof insertPdfEditSchema>;
export type PdfEdit = typeof pdfEdits.$inferSelect;

// PDF operation types
export enum PdfOperationType {
  ADD_TEXT = 'ADD_TEXT',
  MODIFY_TEXT = 'MODIFY_TEXT',
  DELETE_TEXT = 'DELETE_TEXT',
  ADD_IMAGE = 'ADD_IMAGE',
  DELETE_PAGE = 'DELETE_PAGE',
  ADD_PAGE = 'ADD_PAGE',
  REORDER_PAGES = 'REORDER_PAGES',
  ROTATE_PAGE = 'ROTATE_PAGE',
  ADD_WATERMARK = 'ADD_WATERMARK',
  REMOVE_WATERMARK = 'REMOVE_WATERMARK',
  ADD_FORM_FIELD = 'ADD_FORM_FIELD',
  FILL_FORM_FIELD = 'FILL_FORM_FIELD',
  ADD_SIGNATURE = 'ADD_SIGNATURE',
}

export type PdfOperation = {
  type: PdfOperationType;
  pageNumber: number;
  content: string;
  position?: { x: number, y: number };
  fontSize?: number;
  fontColor?: string;
  elementId?: string;
  // Resim özellikleri
  imageData?: string; // base64 formatında resim verisi
  imageWidth?: number;
  imageHeight?: number;
  // Sayfa işlemleri için ek alanlar
  targetPageNumber?: number; // Sayfa sıralaması için hedef sayfa numarası
  pageRotation?: number; // Sayfa döndürme açısı (0, 90, 180, 270)
  // Filigran için ek alanlar
  watermarkText?: string; // Filigran metni
  watermarkOpacity?: number; // Filigran şeffaflığı
  watermarkRotation?: number; // Filigran döndürme açısı
  watermarkSize?: number; // Filigran büyüklüğü
  // Form alanları için ek bilgiler
  formFieldType?: 'text' | 'checkbox' | 'radio' | 'dropdown' | 'signature'; // Form alanı tipi
  formFieldName?: string; // Form alanı adı
  formFieldValue?: string; // Form alanına girilen değer
  // İmza için ek alanlar
  signatureData?: string; // base64 formatında imza verisi
  signatureWidth?: number;
  signatureHeight?: number;
};

export type PdfOperations = PdfOperation[];
