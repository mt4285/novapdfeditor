import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { promisify } from 'util';
import { v4 as uuidv4 } from 'uuid';
import { log } from './vite';

const execAsync = promisify(exec);
const mkdirAsync = promisify(fs.mkdir);
const unlinkAsync = promisify(fs.unlink);
const readFileAsync = promisify(fs.readFile);

// Geçici dosya yolları
const TMP_DIR = path.resolve('./tmp');
const ensureTmpDir = async () => {
  try {
    if (!fs.existsSync(TMP_DIR)) {
      await mkdirAsync(TMP_DIR, { recursive: true });
    }
  } catch (error) {
    console.error('Geçici klasör oluşturma hatası:', error);
    throw error;
  }
};

/**
 * Dosya uzantısından MIME türünü belirleyen yardımcı fonksiyon
 */
export function getMimeTypeFromExtension(extension: string): string {
  const types: Record<string, string> = {
    // Microsoft Office
    'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    
    // OpenOffice / LibreOffice
    'odt': 'application/vnd.oasis.opendocument.text',
    'ods': 'application/vnd.oasis.opendocument.spreadsheet',
    'odp': 'application/vnd.oasis.opendocument.presentation',
    
    // Diğer
    'rtf': 'application/rtf',
    'txt': 'text/plain',
    'html': 'text/html',
    'htm': 'text/html',
    'csv': 'text/csv',
    'pdf': 'application/pdf',
  };
  
  return types[extension.toLowerCase()] || 'application/octet-stream';
}

/**
 * MIME türünden dosya uzantısını belirleyen yardımcı fonksiyon
 */
export function getExtensionFromMimeType(mimeType: string): string {
  const types: Record<string, string> = {
    // Microsoft Office
    'application/msword': 'doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.ms-excel': 'xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-powerpoint': 'ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
    
    // OpenOffice / LibreOffice
    'application/vnd.oasis.opendocument.text': 'odt',
    'application/vnd.oasis.opendocument.spreadsheet': 'ods',
    'application/vnd.oasis.opendocument.presentation': 'odp',
    
    // Diğer
    'application/rtf': 'rtf',
    'text/plain': 'txt',
    'text/html': 'html',
    'text/csv': 'csv',
    'application/pdf': 'pdf',
  };
  
  return types[mimeType] || 'bin';
}

/**
 * Belge dosyasını PDF'e dönüştüren fonksiyon
 * @param inputBuffer Giriş dosyasının içeriği (Buffer)
 * @param mimeType Giriş dosyasının MIME türü
 * @returns PDF içeriği (Buffer)
 */
export async function convertDocumentToPdf(inputBuffer: Buffer, mimeType: string): Promise<Buffer> {
  try {
    await ensureTmpDir();
    
    // Benzersiz bir dosya adı oluştur
    const fileId = uuidv4();
    const extension = getExtensionFromMimeType(mimeType);
    const inputPath = path.join(TMP_DIR, `${fileId}.${extension}`);
    const outputPath = path.join(TMP_DIR, `${fileId}.pdf`);
    
    console.log(`Dönüştürme başlıyor: MIME türü=${mimeType}, Uzantı=${extension}`);
    console.log(`Dosya yolları: Giriş=${inputPath}, Çıkış=${outputPath}`);
    
    // Giriş dosyasını geçici dizine yaz
    try {
      fs.writeFileSync(inputPath, inputBuffer);
      console.log(`Geçici dosya yazıldı: ${inputPath}, Boyut: ${inputBuffer.length} bayt`);
    } catch (writeError) {
      console.error('Geçici dosya yazma hatası:', writeError);
      throw writeError;
    }
    
    try {
      // LibreOffice ile dönüştürme işlemi
      log(`Belge dönüştürülüyor: ${inputPath} -> ${outputPath}`);
      
      // LibreOffice komutunu çalıştır
      const libreOfficeCommand = `libreoffice --headless --convert-to pdf --outdir ${TMP_DIR} ${inputPath}`;
      console.log(`Çalıştırılacak komut: ${libreOfficeCommand}`);
      
      const { stdout, stderr } = await execAsync(libreOfficeCommand);
      
      console.log('LibreOffice çıktısı:', { stdout, stderr });
      
      // Hata kontrolü
      if (stderr && !stderr.includes('convert')) {
        console.error('LibreOffice dönüştürme hatası:', stderr);
        throw new Error(`LibreOffice dönüştürme hatası: ${stderr}`);
      }
      
      // Çıktı PDF dosyasını oku
      const pdfBuffer = await readFileAsync(outputPath);
      
      // Geçici dosyaları temizle
      await unlinkAsync(inputPath);
      await unlinkAsync(outputPath);
      
      return pdfBuffer;
    } catch (error) {
      // Geçici dosyaları hata durumunda da temizlemeye çalış
      try {
        if (fs.existsSync(inputPath)) await unlinkAsync(inputPath);
        if (fs.existsSync(outputPath)) await unlinkAsync(outputPath);
      } catch (cleanupError) {
        console.error('Geçici dosya temizleme hatası:', cleanupError);
      }
      
      throw error;
    }
  } catch (error) {
    console.error('Belge dönüştürme hatası:', error);
    throw error;
  }
}

/**
 * Desteklenen dosya uzantılarını döndüren fonksiyon
 */
export function getSupportedDocumentExtensions(): string[] {
  return [
    '.doc', '.docx',  // Word
    '.xls', '.xlsx',  // Excel
    '.ppt', '.pptx',  // PowerPoint
    '.odt', '.ods', '.odp',  // LibreOffice/OpenOffice
    '.rtf', '.txt', '.html', '.csv'  // Diğer
  ];
}

/**
 * Desteklenen MIME türlerini döndüren fonksiyon
 */
export function getSupportedDocumentMimeTypes(): string[] {
  return [
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
    'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.oasis.opendocument.text', 'application/vnd.oasis.opendocument.spreadsheet', 'application/vnd.oasis.opendocument.presentation',
    'application/rtf', 'text/plain', 'text/html', 'text/csv'
  ];
}