import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import * as fs from "fs";
import * as path from "path";
import { Readable } from "stream";
import { PDFDocument } from "pdf-lib";
import { insertPdfSchema, insertPdfEditSchema, PdfOperationType } from "@shared/schema";
import { z } from "zod";
import { 
  convertDocumentToPdf, 
  getExtensionFromMimeType, 
  getSupportedDocumentMimeTypes 
} from "./docConverter";
import { spawn as childProcessSpawn } from "child_process";
import express from "express";

// PDF yükleme için multer yapılandırması (Sadece PDF dosyaları)
const pdfUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
});

// Dönüştürme için multer yapılandırması (Tüm desteklenen dosya türleri)
const convertUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (_req, file, cb) => {
    // Desteklenen MIME türleri
    const supportedTypes = [
      // Microsoft Office
      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
      'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
      'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      // Diğer
      'application/rtf', 'text/plain', 'text/html', 'text/csv',
      // PDF
      'application/pdf'
    ];
    
    if (supportedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Desteklenmeyen dosya türü. Desteklenen türler: ${supportedTypes.join(', ')}`));
    }
  },
});

// OpenAI kullanımı geçici olarak devre dışı bırakıldı
// import { OpenAI } from "openai";
// const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function registerRoutes(app: Express): Promise<Server> {
  // Statik dosya sunumu
  app.use('/audio_notes', express.static(path.join(process.cwd(), 'audio_notes')));
  app.use('/signatures', express.static(path.join(process.cwd(), 'signatures')));
  app.use('/scans', express.static(path.join(process.cwd(), 'scans')));

  // PDF upload endpoint
  app.post("/api/pdf/upload", pdfUpload.single("pdf"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No PDF file uploaded" });
      }

      // Validate that the file is a valid PDF
      try {
        await PDFDocument.load(req.file.buffer);
      } catch (err) {
        return res.status(400).json({ message: "Invalid PDF file" });
      }

      // Save the PDF
      const pdf = await storage.savePdf(
        req.file.buffer,
        req.file.originalname,
        req.file.mimetype
      );

      return res.status(200).json(pdf);
    } catch (err) {
      console.error("Error uploading PDF:", err);
      return res.status(500).json({ message: "Failed to upload PDF" });
    }
  });

  // Get PDF metadata
  app.get("/api/pdf/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const pdf = await storage.getPdf(id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      return res.json(pdf);
    } catch (err) {
      console.error("Error getting PDF:", err);
      return res.status(500).json({ message: "Failed to get PDF" });
    }
  });

  // Stream PDF file
  app.get("/api/pdf/:id/file", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const pdf = await storage.getPdf(id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      const pdfBuffer = await storage.getPdfBuffer(id);
      if (!pdfBuffer) {
        return res.status(404).json({ message: "PDF file not found" });
      }

      // Set appropriate headers for PDF
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `inline; filename="${pdf.originalFilename}"`);
      res.setHeader("Content-Length", pdfBuffer.length);

      // Stream the PDF data
      const stream = Readable.from(pdfBuffer);
      stream.pipe(res);
    } catch (err) {
      console.error("Error streaming PDF:", err);
      return res.status(500).json({ message: "Failed to stream PDF" });
    }
  });

  // Save PDF edits
  app.post("/api/pdf/:id/edit", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const pdf = await storage.getPdf(id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      // Validate edit data
      const parsedBody = insertPdfEditSchema.parse({
        pdfId: id,
        edits: JSON.stringify(req.body.operations),
        createdAt: new Date().toISOString(),
      });

      // Save the edit
      const pdfEdit = await storage.savePdfEdit(parsedBody);
      return res.status(200).json(pdfEdit);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid edit data", errors: err.errors });
      }
      console.error("Error saving PDF edit:", err);
      return res.status(500).json({ message: "Failed to save PDF edit" });
    }
  });

  // Get PDF with edits applied
  app.get("/api/pdf/:id/edited", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const pdf = await storage.getPdf(id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      const pdfBuffer = await storage.getPdfBuffer(id);
      if (!pdfBuffer) {
        return res.status(404).json({ message: "PDF file not found" });
      }

      const edits = await storage.getPdfEdits(id);
      if (!edits || edits.length === 0) {
        // If no edits, return the original PDF
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", `attachment; filename="edited_${pdf.originalFilename}"`);
        res.setHeader("Content-Length", pdfBuffer.length);
        return res.send(pdfBuffer);
      }

      // Load the PDF
      const pdfDoc = await PDFDocument.load(pdfBuffer);
      
      // Here we would process all the edits and apply them to the PDF
      // This is a simplified placeholder for applying edits
      // In a real implementation, we would iterate through all edits and apply them
      
      // Save the modified PDF
      const modifiedPdfBytes = await pdfDoc.save();
      
      // Return the modified PDF
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="edited_${pdf.originalFilename}"`);
      res.setHeader("Content-Length", modifiedPdfBytes.length);
      res.send(Buffer.from(modifiedPdfBytes));
    } catch (err) {
      console.error("Error getting edited PDF:", err);
      return res.status(500).json({ message: "Failed to get edited PDF" });
    }
  });

  // Update PDF metadata
  app.post("/api/pdf/:id/metadata", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const pdf = await storage.getPdf(id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      const pdfBuffer = await storage.getPdfBuffer(id);
      if (!pdfBuffer) {
        return res.status(404).json({ message: "PDF file not found" });
      }

      const { metadata } = req.body;
      if (!metadata) {
        return res.status(400).json({ message: "No metadata provided" });
      }

      // Metadataları PDF dosyasına uygula
      const pdfDoc = await PDFDocument.load(pdfBuffer);
      
      // Metadataları güncelle (mevcut olanlar)
      if (metadata.title !== undefined) pdfDoc.setTitle(metadata.title);
      if (metadata.author !== undefined) pdfDoc.setAuthor(metadata.author);
      if (metadata.subject !== undefined) pdfDoc.setSubject(metadata.subject);
      if (metadata.keywords !== undefined) pdfDoc.setKeywords(metadata.keywords);
      if (metadata.creator !== undefined) pdfDoc.setCreator(metadata.creator);
      if (metadata.producer !== undefined) pdfDoc.setProducer(metadata.producer);
      
      // Güncelleme tarihi olarak şu anki zamanı ayarla
      pdfDoc.setModificationDate(new Date());
      
      // Güncellenmiş PDF'i kaydet
      const modifiedPdfBytes = await pdfDoc.save();
      
      // PDF dosyasını veritabanında güncelle
      const updatedBuffer = Buffer.from(modifiedPdfBytes);
      await storage.updatePdfBuffer(id, updatedBuffer);
      
      return res.status(200).json({ 
        message: "PDF metadata updated successfully",
        id
      });
    } catch (err) {
      console.error("Error updating PDF metadata:", err);
      return res.status(500).json({ message: "Failed to update PDF metadata" });
    }
  });

  // Delete PDF
  app.delete("/api/pdf/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid PDF ID" });
      }

      const wasDeleted = await storage.deletePdf(id);
      if (!wasDeleted) {
        return res.status(404).json({ message: "PDF not found" });
      }

      return res.status(204).end();
    } catch (err) {
      console.error("Error deleting PDF:", err);
      return res.status(500).json({ message: "Failed to delete PDF" });
    }
  });

  // Çeviri API endpointi - DEMO AMAÇLI MOCK VERİLER
  app.post("/api/translate", async (req: Request, res: Response) => {
    try {
      const { text, sourceLang, targetLang } = req.body;
      
      if (!text || !targetLang) {
        return res.status(400).json({ 
          message: "Metin ve hedef dil gereklidir" 
        });
      }

      // Demo çevirileri - birkaç basit kelime için çeviriler
      const translations: Record<string, Record<string, string>> = {
        "en": {
          "hello": "merhaba",
          "world": "dünya",
          "welcome": "hoş geldiniz",
          "pdf": "pdf",
          "editor": "düzenleyici",
          "document": "belge",
          "page": "sayfa",
          "file": "dosya"
        },
        "tr": {
          "merhaba": "hello",
          "dünya": "world",
          "hoş geldiniz": "welcome",
          "pdf": "pdf",
          "düzenleyici": "editor",
          "belge": "document",
          "sayfa": "page",
          "dosya": "file"
        }
      };
      
      // Basit bir simüle gecikme
      await new Promise(resolve => setTimeout(resolve, 500));
      
      let translatedText = text;
      
      // Çok basit demo çeviri - gerçek bir çeviri servisi değil
      if ((sourceLang === "en" && targetLang === "tr") || (sourceLang === "tr" && targetLang === "en")) {
        const words = text.split(/\s+/);
        translatedText = words.map((word: string) => {
          const cleanWord = word.toLowerCase().replace(/[.,!?;:()]/g, '');
          const punctuation = word.match(/[.,!?;:()]+/)?.[0] || '';
          
          if (translations[sourceLang] && translations[sourceLang][cleanWord]) {
            return translations[sourceLang][cleanWord] + punctuation;
          }
          return word;
        }).join(' ');
      } else {
        // Diğer dil çiftleri için demo mesajı
        translatedText = `[${text}] metni ${sourceLang} dilinden ${targetLang} diline çevrildi (Demo)`;
      }
      
      return res.status(200).json({ 
        translatedText,
        detectedLanguage: sourceLang
      });
    } catch (error) {
      console.error("Çeviri hatası:", error);
      return res.status(500).json({ message: "Çeviri işlemi sırasında bir hata oluştu" });
    }
  });
  
  // Sözlük API endpointi - DEMO AMAÇLI MOCK VERİLER
  app.post("/api/dictionary", async (req: Request, res: Response) => {
    try {
      const { word, sourceLang, targetLang } = req.body;
      
      if (!word || !sourceLang) {
        return res.status(400).json({ 
          message: "Kelime ve kaynak dil gereklidir" 
        });
      }
      
      // Demo sözlük veritabanı
      const dictionary = {
        "hello": {
          word: "hello",
          phonetic: "/həˈləʊ/",
          meanings: [
            {
              partOfSpeech: "noun",
              definitions: [
                {
                  definition: "An utterance of 'hello'; a greeting.",
                  example: "She gave me a warm hello."
                }
              ]
            },
            {
              partOfSpeech: "interjection",
              definitions: [
                {
                  definition: "A greeting used when meeting someone or acknowledging someone's arrival or presence.",
                  example: "Hello, John! How are you today?"
                }
              ]
            }
          ],
          translations: [
            { text: "merhaba", partOfSpeech: "ünlem" },
            { text: "selam", partOfSpeech: "ünlem" }
          ]
        },
        "world": {
          word: "world",
          phonetic: "/wɜːld/",
          meanings: [
            {
              partOfSpeech: "noun",
              definitions: [
                {
                  definition: "The earth, together with all of its countries and peoples.",
                  example: "He traveled around the world."
                }
              ]
            }
          ],
          translations: [
            { text: "dünya", partOfSpeech: "isim" }
          ]
        },
        "merhaba": {
          word: "merhaba",
          phonetic: "/meɾhaˈba/",
          meanings: [
            {
              partOfSpeech: "ünlem",
              definitions: [
                {
                  definition: "Selamlaşma, karşılaşma sözü.",
                  example: "Merhaba, nasılsın?"
                }
              ]
            }
          ],
          translations: [
            { text: "hello", partOfSpeech: "interjection" },
            { text: "hi", partOfSpeech: "interjection" }
          ]
        },
        "dünya": {
          word: "dünya",
          phonetic: "/dynˈja/",
          meanings: [
            {
              partOfSpeech: "isim",
              definitions: [
                {
                  definition: "Üzerinde yaşadığımız gezegen, yeryüzü.",
                  example: "Dünya Güneş'in etrafında döner."
                }
              ]
            }
          ],
          translations: [
            { text: "world", partOfSpeech: "noun" },
            { text: "earth", partOfSpeech: "noun" }
          ]
        }
      };
      
      // Basit bir simüle gecikme
      await new Promise(resolve => setTimeout(resolve, 700));
      
      const lookupWord = word.toLowerCase().trim();
      
      if (lookupWord in dictionary) {
        return res.status(200).json(dictionary[lookupWord as keyof typeof dictionary]);
      } else {
        return res.status(404).json({ 
          message: `"${word}" kelimesi sözlükte bulunamadı`
        });
      }
    } catch (error) {
      console.error("Sözlük hatası:", error);
      return res.status(500).json({ message: "Sözlük sorgusu sırasında bir hata oluştu" });
    }
  });
  
  // PDF Sıkıştırma endpoint'i

  // Office belgelerini PDF'e dönüştürmek için API
  app.post("/api/convert-to-pdf", convertUpload.single("file"), async (req: Request, res: Response) => {
    try {
      console.log("API çağrıldı: /api/convert-to-pdf");
      
      if (!req.file) {
        console.log("Hata: Dosya bulunamadı.");
        return res.status(400).send("Dosya bulunamadı.");
      }
      
      console.log(`Dosya alındı: ${req.file.originalname}, MIME: ${req.file.mimetype}, Boyut: ${req.file.size} bayt`);

      // Desteklenen MIME türleri
      const supportedTypes = [
        // Microsoft Office
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        // Diğer
        'application/rtf', 'text/plain', 'text/html', 'text/csv',
        // PDF
        'application/pdf'
      ];
      
      // Dosya türü kontrolü
      if (!supportedTypes.includes(req.file.mimetype)) {
        return res.status(400).send({
          error: "Desteklenmeyen dosya türü",
          message: `Desteklenen dosya türleri: ${supportedTypes.join(', ')}`
        });
      }

      let pdfBuffer: Buffer;
      
      // Eğer dosya zaten PDF ise dönüştürme yapma
      if (req.file.mimetype === 'application/pdf') {
        pdfBuffer = req.file.buffer;
      } else {
        try {
          // Python betiğini çağırarak Office belgelerini PDF'e dönüştür
          // Dosyayı base64'e dönüştür
          const fileBase64 = req.file.buffer.toString('base64');
          
          // Python betiğini çalıştır
          const process = childProcessSpawn('python3', [
            'doc_converter_all.py', 
            fileBase64, 
            req.file.mimetype, 
            req.file.originalname
          ]);
          
          // Sonucu topla
          let stdoutData = '';
          let stderrData = '';
          
          process.stdout.on('data', (data: Buffer) => {
            stdoutData += data.toString();
          });
          
          process.stderr.on('data', (data: Buffer) => {
            stderrData += data.toString();
            console.error('Python dönüştürme hatası:', data.toString());
          });
          
          // İşlem tamamlandığında sonucu işle
          const processingResult = await new Promise<Buffer>((resolve, reject) => {
            process.on('close', (code: number) => {
              if (code !== 0) {
                console.error(`Python betik hatası (${code}):`, stderrData);
                reject(new Error(`Dönüştürme işlemi başarısız oldu (${code}): ${stderrData}`));
                return;
              }
              
              try {
                // JSON çıktıyı ayrıştır
                const result = JSON.parse(stdoutData);
                
                if (!result.success) {
                  reject(new Error(`Python dönüştürme hatası: ${result.error}`));
                  return;
                }
                
                // Base64 PDF içeriğini buffer'a dönüştür
                const pdfData = Buffer.from(result.pdf_base64, 'base64');
                resolve(pdfData);
              } catch (error) {
                // Tip güvenliği için hata mesajını doğru şekilde çıkart
                const parseError = error as Error;
                console.error('JSON ayrıştırma hatası:', parseError);
                reject(new Error(`Sonuç ayrıştırılamadı: ${parseError.message || 'Bilinmeyen hata'}`));
              }
            });
          });
          
          pdfBuffer = processingResult;
          console.log(`Dönüştürme tamamlandı: ${req.file.originalname} (${pdfBuffer.length} bayt)`);
          
        } catch (error) {
          // Tip güvenliği için hata mesajını doğru şekilde çıkart
          const conversionError = error as Error;
          console.error("Dönüştürme hatası:", conversionError);
          return res.status(500).send({
            error: "Dönüştürme hatası",
            message: "Belge PDF'e dönüştürülürken bir hata oluştu: " + (conversionError.message || "Bilinmeyen hata")
          });
        }
      }
      
      // Öncelikle dosyayı veritabanına kaydet
      const pdf = await storage.savePdf(
        pdfBuffer,
        req.file.originalname.replace(/\.\w+$/, '.pdf'), // Uzantıyı PDF olarak değiştir
        'application/pdf'
      );
      
      // Başarılı yanıt döndür
      return res.status(200).json({
        id: pdf.id,
        filename: pdf.filename,
        originalFilename: pdf.originalFilename,
        contentType: pdf.contentType,
        createdAt: pdf.createdAt,
        size: pdfBuffer.length,
        message: "Belge başarıyla PDF'e dönüştürüldü."
      });
    } catch (err) {
      // Tip güvenliği için hata mesajını doğru şekilde çıkart
      const error = err as Error;
      console.error("API hatası:", error);
      return res.status(500).send({
        error: "Sunucu hatası",
        message: "Belge işlenirken bir hata oluştu: " + (error.message || "Bilinmeyen hata")
      });
    }
  });

  // Ses dosyası yükleme endpoint'i
  app.post("/api/upload-audio", convertUpload.single("audio"), async (req: Request, res: Response) => {
    try {
      console.log("Ses dosyası yükleme API çağrıldı.");
      
      if (!req.file) {
        return res.status(400).json({ message: "Ses dosyası bulunamadı" });
      }
      
      console.log(`Ses dosyası alındı: ${req.file.originalname}, Boyut: ${req.file.size} bayt`);
      
      // Ses dosyasını audio_notes klasörüne kaydet
      const audioNotesDir = path.join(process.cwd(), 'audio_notes');
      
      // Klasör yoksa oluştur
      if (!fs.existsSync(audioNotesDir)) {
        fs.mkdirSync(audioNotesDir, { recursive: true });
      }
      
      const filename = `${Date.now()}_${req.file.originalname}`;
      const filepath = path.join(audioNotesDir, filename);
      
      // Dosyayı kaydet
      fs.writeFileSync(filepath, req.file.buffer);
      
      console.log(`Ses dosyası kaydedildi: ${filepath}`);
      
      return res.status(200).json({
        message: "Ses kaydı alındı",
        filename: filename,
        size: req.file.size
      });
      
    } catch (error) {
      console.error("Ses dosyası yükleme hatası:", error);
      return res.status(500).json({
        error: "Ses dosyası yüklenirken hata oluştu",
        message: (error as Error).message || "Bilinmeyen hata"
      });
    }
  });

  // İmza yükleme endpoint'i
  app.post("/api/upload-signature", convertUpload.single("signature"), async (req: Request, res: Response) => {
    try {
      console.log("İmza yükleme API çağrıldı.");
      
      if (!req.file) {
        return res.status(400).json({ message: "İmza dosyası bulunamadı" });
      }
      
      console.log(`İmza dosyası alındı: ${req.file.originalname}, Boyut: ${req.file.size} bayt`);
      
      // İmza dosyasını signatures klasörüne kaydet
      const signaturesDir = path.join(process.cwd(), 'signatures');
      
      // Klasör yoksa oluştur
      if (!fs.existsSync(signaturesDir)) {
        fs.mkdirSync(signaturesDir, { recursive: true });
      }
      
      const filename = `${Date.now()}_${req.file.originalname}`;
      const filepath = path.join(signaturesDir, filename);
      
      // Dosyayı kaydet
      fs.writeFileSync(filepath, req.file.buffer);
      
      console.log(`İmza dosyası kaydedildi: ${filepath}`);
      
      return res.status(200).json({
        message: "İmza kaydedildi",
        filename: filename,
        size: req.file.size
      });
      
    } catch (error) {
      console.error("İmza yükleme hatası:", error);
      return res.status(500).json({
        error: "İmza yüklenirken hata oluştu",
        message: (error as Error).message || "Bilinmeyen hata"
      });
    }
  });

  // Belge tarama endpoint'i
  app.post("/api/upload-scan", convertUpload.single("scan"), async (req: Request, res: Response) => {
    try {
      console.log("Belge tarama API çağrıldı.");
      
      if (!req.file) {
        return res.status(400).json({ message: "Tarama dosyası bulunamadı" });
      }
      
      console.log(`Tarama dosyası alındı: ${req.file.originalname}, Boyut: ${req.file.size} bayt`);
      
      // Tarama dosyasını scans klasörüne kaydet
      const scansDir = path.join(process.cwd(), 'scans');
      
      // Klasör yoksa oluştur
      if (!fs.existsSync(scansDir)) {
        fs.mkdirSync(scansDir, { recursive: true });
      }
      
      const imageFilename = `${Date.now()}_${req.file.originalname}`;
      const imagePath = path.join(scansDir, imageFilename);
      
      // Görsel dosyayı kaydet
      fs.writeFileSync(imagePath, req.file.buffer);
      
      // Python ile PDF'e dönüştür
      const pdfFilename = imageFilename.replace(/\.(jpg|jpeg|png|webp)$/i, '.pdf');
      const pdfPath = path.join(scansDir, pdfFilename);
      
      try {
        // Python script çağır
        const pythonProcess = childProcessSpawn('python3', ['scan_to_pdf.py', imagePath, pdfPath]);
        
        let output = '';
        let error = '';
        
        pythonProcess.stdout.on('data', (data: Buffer) => {
          output += data.toString();
        });
        
        pythonProcess.stderr.on('data', (data: Buffer) => {
          error += data.toString();
        });
        
        await new Promise((resolve, reject) => {
          pythonProcess.on('close', (code: number) => {
            if (code === 0) {
              resolve(output);
            } else {
              reject(new Error(`Python çıkış kodu: ${code}, Hata: ${error}`));
            }
          });
        });
        
        console.log(`PDF oluşturuldu: ${pdfPath}`);
        
        return res.status(200).json({
          message: "Tarama tamamlandı",
          filename: pdfFilename,
          pdfUrl: `/scans/${pdfFilename}`,
          imageSize: req.file.size
        });
        
      } catch (pythonError) {
        console.error("Python PDF dönüştürme hatası:", pythonError);
        
        // Python hatası durumunda basit PDF oluştur
        return res.status(200).json({
          message: "Tarama kaydedildi (PDF dönüştürme beklemede)",
          filename: imageFilename,
          pdfUrl: `/scans/${imageFilename}`,
          imageSize: req.file.size
        });
      }
      
    } catch (error) {
      console.error("Tarama yükleme hatası:", error);
      return res.status(500).json({
        error: "Tarama yüklenirken hata oluştu",
        message: (error as Error).message || "Bilinmeyen hata"
      });
    }
  });

  app.post("/api/pdf/compress", pdfUpload.single("pdf"), async (req: Request, res: Response) => {
    try {
      console.log("PDF Sıkıştırma API çağrıldı.");
      console.log("req.file:", req.file ? "mevcut" : "yok");
      console.log("req.body:", req.body);
      
      if (!req.file) {
        return res.status(400).json({ error: "PDF dosyası gönderilmedi" });
      }
      
      const compressionLevel = req.body.compressionLevel || "medium"; // light, medium, high
      console.log("Sıkıştırma seviyesi:", compressionLevel);
      const pdfBuffer = req.file.buffer;
      
      // PDF boyutunu kontrol et
      const originalSizeKB = Math.round(pdfBuffer.length / 1024);
      
      try {
        // Python script'ini geçici dosyalar aracılığıyla kullanarak çağır
        const fs = await import('fs');
        const path = await import('path');
        const child_process = await import('child_process');
        const util = await import('util');
        const os = await import('os');
        
        // Geçici dosya oluştur
        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `input_${Date.now()}.pdf`);
        const outputPath = path.join(tempDir, `output_${Date.now()}.pdf`);
        
        // Giriş dosyasını oluştur
        fs.writeFileSync(inputPath, pdfBuffer);
        
        try {
          console.log("QPDF ile PDF sıkıştırma işlemi başlatılıyor...");
          
          // Python ile sıkıştırma yapalım
          const pdfBase64 = pdfBuffer.toString('base64');
          
          // Base64 verisi çok büyük olabilir, bu yüzden argüman olarak göndermeyeceğiz
          // Geçici dosya işlemlerini Python içinde yapacağız
          const exec = util.promisify(child_process.exec);
          
          try {
            // qpdf_compressor.py scriptini çağır
            const { stdout, stderr } = await exec(`python qpdf_compressor.py "${pdfBase64}" "${compressionLevel}"`);
            
            if (stderr) {
              console.log("QPDF Bilgi:", stderr);
            }
            
            // Sonucu JSON olarak parse et
            const result = JSON.parse(stdout);
            
            // Hata kontrolü
            if (result.error) {
              throw new Error(`PDF sıkıştırma hatası: ${result.error}`);
            }
            
            // Sıkıştırma istatistiklerini hesapla
            const originalSize = Math.round(result.original_size / 1024); // KB cinsinden
            const compressedSize = Math.round(result.compressed_size / 1024); // KB cinsinden
            
            // Tasarruf edilen boyutu hesapla
            const savedSize = originalSize - compressedSize;
            const percentSaved = Math.round((savedSize / originalSize) * 100);
            
            console.log(`QPDF sıkıştırma tamamlandı - Orijinal: ${originalSize}KB, Sıkıştırılmış: ${compressedSize}KB, Kazanç: %${percentSaved}`);
            
            // Tamamlanan sıkıştırma bilgilerini JSON olarak döndür
            return res.json({
              originalSize: originalSize,
              compressedSize: compressedSize,
              savedSize: savedSize,
              percentSaved: percentSaved,
              compressedPdf: result.compressed_pdf
            });
          } catch (pythonError) {
            console.error("QPDF Python scripti hatası:", pythonError);
            throw pythonError;
          }
        } catch (gsError) {
          console.error("Ghostscript hatası:", gsError);
          throw gsError;
        } finally {
          // Geçici dosyaları temizle
          try {
            if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
            if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
          } catch (cleanupError) {
            console.error("Geçici dosya temizleme hatası:", cleanupError);
          }
        }
        
      } catch (pythonError: any) {
        console.error("Python script çalıştırma hatası:", pythonError);
        
        // Python script çalışmazsa yedek olarak JavaScript sıkıştırmasını kullan
        console.log("Yedek JavaScript sıkıştırması kullanılıyor...");
        
        // PDF'i yükle ve sıkıştır
        const pdfDoc = await PDFDocument.load(pdfBuffer);
      
        // Sıkıştırma seviyesine göre PDFDocument seçeneklerini ayarla
        let compressedPdfBytes;
        
        // PDF sayfalarını al
        const pdfPages = pdfDoc.getPages();
        
        // Tüm font içeriğini kopyala - bu sayede fontlar korunur
        const copyFonts = true;
        
        // İçeriği korurken sıkıştırma seçenekleri
        const defaultOptions = {
          useObjectStreams: true,   // Stream nesnelerini sıkıştırır
          addDefaultPage: false,    // Varsayılan sayfa eklemeyi önler
          preserveOutputControl: true, // Çıktı kontrolünü korur
          objectsPerTick: 100       // Depolama optimizasyonu
        };
        
        // Sıkıştırma seviyesine göre PDF parametrelerini ayarlayalım
        switch (compressionLevel) {
          case "light":
            // Hafif sıkıştırma - en yüksek kalite
            console.log("Hafif sıkıştırma (içerik korunacak)");
            
            // PDF'i standart özelliklerle kaydet - minimum sıkıştırma
            compressedPdfBytes = await pdfDoc.save({
              ...defaultOptions
            });
            break;
          
          case "medium":
            // Orta seviye sıkıştırma - yüksek kalite
            console.log("Orta düzey sıkıştırma (içerik korunacak)");
            
            // Bellek kullanımını optimize et
            compressedPdfBytes = await pdfDoc.save({
              ...defaultOptions,
              updateFieldAppearances: false
            });
            break;
          
          case "high":
            // Yüksek sıkıştırma - iyi kalite
            console.log("Yüksek sıkıştırma (içerik korunacak)");
            
            try {
              // Kopya bir PDF oluştur - metadata temizleme için
              const newDoc = await PDFDocument.create();
              
              // Tüm sayfaları kopyala, ancak referans nesnelerinden kurtul
              for (let i = 0; i < pdfPages.length; i++) {
                const [copiedPage] = await newDoc.copyPages(pdfDoc, [i]);
                newDoc.addPage(copiedPage);
              }
              
              // Tam optimize edilmiş olarak kaydet
              compressedPdfBytes = await newDoc.save({
                ...defaultOptions,
                updateFieldAppearances: false
              });
            } catch (e) {
              console.log("Sayfa kopyalama sırasında hata:", e);
              // Hata durumunda, normal optimizasyonu kullan
              compressedPdfBytes = await pdfDoc.save(defaultOptions);
            }
            break;
          
          default:
            // Varsayılan - medium sıkıştırma
            compressedPdfBytes = await pdfDoc.save(defaultOptions);
        }
        
        // Sıkıştırılan buffer
        const compressedBuffer = Buffer.from(compressedPdfBytes);
        const compressedSizeKB = Math.round(compressedBuffer.length / 1024);
        
        // Gerçek tasarruf oranını hesapla
        const savedSizeKB = originalSizeKB - compressedSizeKB;
        const percentSaved = Math.round((savedSizeKB / originalSizeKB) * 100);
        
        console.log(`Sıkıştırma Tamamlandı - Orijinal: ${originalSizeKB}KB, Sıkıştırılmış: ${compressedSizeKB}KB, Kazanç: %${percentSaved}`);
        
        // İstatistik bilgilerini JSON olarak döndür
        return res.json({
          originalSize: originalSizeKB,
          compressedSize: compressedSizeKB,
          savedSize: savedSizeKB,
          percentSaved: percentSaved,
          compressionLevel: compressionLevel,
          fileName: req.file.originalname,
          compressedPdf: compressedBuffer.toString('base64')
        });
      }
    } catch (error: any) {
      console.error("PDF sıkıştırma hatası:", error);
      return res.status(500).json({ error: "PDF sıkıştırma işlemi sırasında bir hata oluştu" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}