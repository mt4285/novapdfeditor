import { pdfs, type Pdf, type InsertPdf, pdfEdits, type PdfEdit, type InsertPdfEdit, users, type User, type InsertUser } from "@shared/schema";
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

// Interface for storage operations
export interface IStorage {
  // User operations from original
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // PDF operations
  savePdf(pdfData: Buffer, originalFilename: string, contentType: string): Promise<Pdf>;
  getPdf(id: number): Promise<Pdf | undefined>;
  getPdfBuffer(id: number): Promise<Buffer | undefined>;
  updatePdfBuffer(id: number, buffer: Buffer): Promise<boolean>;
  savePdfEdit(pdfEdit: InsertPdfEdit): Promise<PdfEdit>;
  getPdfEdits(pdfId: number): Promise<PdfEdit[]>;
  deletePdf(id: number): Promise<boolean>;
}

// Temporary directory to store uploaded PDFs
const TEMP_DIR = path.join(process.cwd(), 'tmp');

// Create temp directory if it doesn't exist
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// Memory-based storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private pdfsData: Map<number, Pdf>;
  private pdfFiles: Map<number, Buffer>;
  private pdfEditsData: Map<number, PdfEdit[]>;
  
  private userCurrentId: number;
  private pdfCurrentId: number;
  private pdfEditCurrentId: number;

  constructor() {
    this.users = new Map();
    this.pdfsData = new Map();
    this.pdfFiles = new Map();
    this.pdfEditsData = new Map();
    
    this.userCurrentId = 1;
    this.pdfCurrentId = 1;
    this.pdfEditCurrentId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // PDF operations
  async savePdf(pdfData: Buffer, originalFilename: string, contentType: string): Promise<Pdf> {
    const id = this.pdfCurrentId++;
    const now = new Date().toISOString();
    const hash = crypto.createHash('md5').update(now + originalFilename).digest('hex');
    const filename = `${hash}.pdf`;
    
    // Save PDF data to memory
    this.pdfFiles.set(id, pdfData);
    
    // Create PDF metadata record
    const pdf: Pdf = {
      id,
      filename,
      originalFilename,
      contentType,
      size: pdfData.length,
      createdAt: now,
      updatedAt: now
    };
    
    this.pdfsData.set(id, pdf);
    return pdf;
  }

  async getPdf(id: number): Promise<Pdf | undefined> {
    return this.pdfsData.get(id);
  }

  async getPdfBuffer(id: number): Promise<Buffer | undefined> {
    return this.pdfFiles.get(id);
  }
  
  async updatePdfBuffer(id: number, buffer: Buffer): Promise<boolean> {
    if (!this.pdfsData.has(id)) {
      return false;
    }
    
    this.pdfFiles.set(id, buffer);
    
    // Güncelleme zamanını güncelle
    const pdf = this.pdfsData.get(id)!;
    pdf.updatedAt = new Date().toISOString();
    this.pdfsData.set(id, pdf);
    
    return true;
  }

  async savePdfEdit(pdfEdit: InsertPdfEdit): Promise<PdfEdit> {
    const id = this.pdfEditCurrentId++;
    const edit: PdfEdit = { ...pdfEdit, id };
    
    if (!this.pdfEditsData.has(pdfEdit.pdfId)) {
      this.pdfEditsData.set(pdfEdit.pdfId, []);
    }
    
    this.pdfEditsData.get(pdfEdit.pdfId)!.push(edit);
    
    // Update updatedAt time for the PDF
    const pdf = this.pdfsData.get(pdfEdit.pdfId);
    if (pdf) {
      pdf.updatedAt = new Date().toISOString();
      this.pdfsData.set(pdfEdit.pdfId, pdf);
    }
    
    return edit;
  }

  async getPdfEdits(pdfId: number): Promise<PdfEdit[]> {
    return this.pdfEditsData.get(pdfId) || [];
  }

  async deletePdf(id: number): Promise<boolean> {
    const wasDeleted = this.pdfsData.delete(id);
    this.pdfFiles.delete(id);
    this.pdfEditsData.delete(id);
    return wasDeleted;
  }
}

// Export singleton instance
export const storage = new MemStorage();
